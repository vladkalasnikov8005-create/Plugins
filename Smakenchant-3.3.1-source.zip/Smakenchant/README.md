# Smakenchant 3.3.1

Самостоятельный плагин кастомных зачарований для Paper 26.2 / Java 25.

## Сборка

```bash
./gradlew clean build
```

Готовый файл появится в `build/libs/Smakenchant.jar`.

## Установка

1. Поместить JAR в папку `plugins` сервера.
2. Перезапустить сервер.
3. Настроить `plugins/Smakenchant/config.yml`.
4. Для применения изменений выполнить `/smakenchant reload`.

## Команды

- `/smakenchant give <ench> [lvl] [player]`
- `/smakenchant enchant <ench> [lvl]`
- `/smakenchant remove <ench|all>`
- `/smakenchant reload`
- `/smakenchant debug`

## Несовместимые группы

На одном предмете не могут одновременно находиться:

- `slow` и `swift`;
- `eagle_eye`, `heavy_bolt` и `crooked_aim_curse`;
- `returning` и `empty_quiver_curse`;
- `soft_landing` и `bad_landing_curse`;
- `impulse` и `stumble_curse`;
- `jumper`, `gravity_curse` и `heavy_step_curse`;
- `shadow` и `loud_armor_curse`;
- `blood_transfusion` и `prickly`.

При наложении одного зачарования противоположное автоматически снимается. Старые конфликтующие предметы очищаются при входе игрока.
