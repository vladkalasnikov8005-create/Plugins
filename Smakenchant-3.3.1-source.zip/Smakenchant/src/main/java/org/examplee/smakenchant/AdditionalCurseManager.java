package org.examplee.smakenchant;

import org.bukkit.*;import org.bukkit.attribute.*;import org.bukkit.entity.*;import org.bukkit.event.*;import org.bukkit.event.block.BlockBreakEvent;import org.bukkit.event.entity.*;import org.bukkit.event.player.*;import org.bukkit.inventory.ItemStack;import org.bukkit.potion.*;import org.bukkit.scheduler.BukkitTask;
import java.util.*;import java.util.concurrent.ThreadLocalRandom;

/** Дополнительные проклятия предметов, брони и передвижения. */
public final class AdditionalCurseManager implements Listener{
 private final Smakenchant plugin;private final CustomEnchantStore store;private final CustomEnchantment stringCurse,heavyPick,dust,suffocation,loudArmor,weakShield,badLanding,stumble,heavyStep;
 private final NamespacedKey heavyPickKey;private BukkitTask task;private final int[] pct={10,20,30};
 public AdditionalCurseManager(Smakenchant p,CustomEnchantStore s,CustomEnchantment stringCurse,CustomEnchantment heavyPick,CustomEnchantment dust,CustomEnchantment suffocation,CustomEnchantment loudArmor,CustomEnchantment weakShield,CustomEnchantment badLanding,CustomEnchantment stumble,CustomEnchantment heavyStep){plugin=p;store=s;this.stringCurse=stringCurse;this.heavyPick=heavyPick;this.dust=dust;this.suffocation=suffocation;this.loudArmor=loudArmor;this.weakShield=weakShield;this.badLanding=badLanding;this.stumble=stumble;this.heavyStep=heavyStep;heavyPickKey=new NamespacedKey(p,"heavy_pick_speed");}
 public void loadConfig(org.bukkit.configuration.ConfigurationSection r){for(var x:List.of(Map.entry("heavy-string-curse",stringCurse),Map.entry("heavy-pickaxe-curse",heavyPick),Map.entry("dust-curse",dust),Map.entry("suffocation-curse",suffocation),Map.entry("loud-armor-curse",loudArmor),Map.entry("weak-shield-curse",weakShield),Map.entry("bad-landing-curse",badLanding),Map.entry("stumble-curse",stumble),Map.entry("heavy-step-curse",heavyStep))){var c=r.getConfigurationSection(x.getKey());if(c!=null)x.getValue().tableChance(c.getDouble("table-chance-level-1",.04),c.getDouble("table-chance-level-2",.02),c.getDouble("table-chance-level-3",.01)).tableWeight(c.getInt("weight",3)).anvilCostPerLevel(c.getInt("anvil-cost-per-level",2));}start();}
 private void start(){if(task!=null)task.cancel();task=Bukkit.getScheduler().runTaskTimer(plugin,()->{for(Player p:Bukkit.getOnlinePlayers())tick(p);},10,10);}
 public void stop(){if(task!=null)task.cancel();for(Player p:Bukkit.getOnlinePlayers())clear(p);}
 private int armor(Player p,CustomEnchantment e){int l=0;for(ItemStack x:p.getInventory().getArmorContents())l=Math.max(l,store.getLevel(x,e));return l;}private int boots(Player p,CustomEnchantment e){return store.getLevel(p.getInventory().getBoots(),e);}private int at(int l){return pct[Math.min(l,3)-1];}
 private void tick(Player p){AttributeInstance speed=p.getAttribute(Attribute.MOVEMENT_SPEED);if(speed!=null)speed.removeModifier(heavyPickKey);ItemStack hand=p.getInventory().getItemInMainHand();int hp=store.getLevel(hand,heavyPick);if(hp>0&&speed!=null)speed.addTransientModifier(new AttributeModifier(heavyPickKey,-at(hp)/100.0,AttributeModifier.Operation.ADD_SCALAR));
  int su=armor(p,suffocation);if(su>0&&p.isInWater()&&p.getRemainingAir()>0)p.setRemainingAir(Math.max(0,p.getRemainingAir()-su*4));
  int la=armor(p,loudArmor);if(la>0){double r=12+la*8;for(Entity x:p.getNearbyEntities(r,r,r))if(x instanceof Mob m&&m.getTarget()==null)m.setTarget(p);}
  int st=boots(p,stumble);if(st>0&&p.isSprinting()&&p.isOnGround()&&ThreadLocalRandom.current().nextInt(100)<st*2){p.setVelocity(p.getVelocity().multiply(.25));p.setSprinting(false);p.sendMessage("§8Вы споткнулись...");}
 }
 @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void launch(ProjectileLaunchEvent e){if(!(e.getEntity().getShooter() instanceof Player p))return;ItemStack w=p.getInventory().getItemInMainHand();int l=store.getLevel(w,stringCurse);if(l>0)p.setCooldown(w,10*l);}
 @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void breakBlock(BlockBreakEvent e){int l=store.getLevel(e.getPlayer().getInventory().getItemInMainHand(),dust);if(l>0&&ThreadLocalRandom.current().nextInt(100)<at(l)){e.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS,20*l,0,false,true,true));e.getPlayer().getWorld().spawnParticle(Particle.ASH,e.getPlayer().getEyeLocation(),15,.3,.3,.3,.02);}}
 @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void fall(EntityDamageEvent e){if(!(e.getEntity() instanceof Player p)||e.getCause()!=EntityDamageEvent.DamageCause.FALL)return;int l=boots(p,badLanding);if(l>0)e.setDamage(e.getDamage()*(1+l*.25));}
 @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void shield(PlayerItemDamageEvent e){if(e.getItem().getType()!=Material.SHIELD)return;int l=store.getLevel(e.getItem(),weakShield);if(l>0)e.getPlayer().setCooldown(e.getItem(),40*l);}
 @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void jump(com.destroystokyo.paper.event.player.PlayerJumpEvent e){Player p=e.getPlayer();int l=boots(p,heavyStep);if(l>0)p.setExhaustion(Math.min(40f,p.getExhaustion()+.5f*l));}
 private void clear(Player p){AttributeInstance a=p.getAttribute(Attribute.MOVEMENT_SPEED);if(a!=null)a.removeModifier(heavyPickKey);}
 @EventHandler public void quit(PlayerQuitEvent e){clear(e.getPlayer());}
}
