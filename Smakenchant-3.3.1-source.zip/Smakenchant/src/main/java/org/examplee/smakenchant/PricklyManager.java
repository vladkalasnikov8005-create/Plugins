package org.examplee.smakenchant;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Function;

/**
 * Проклятие «Колючий».
 * <p>
 * Использование/атака с шансом {@code chance} (по умолчанию 15%) наносит владельцу
 * полсердца урона. Если инструмент используется НЕ по назначению (например, лопатой
 * ломают камень) — шанс повышается до {@code chance-misuse} (30%).
 */
public class PricklyManager implements Listener {

    private final Smakenchant plugin;
    private final CustomEnchantStore store;
    private final CustomEnchantment enchant;
    private final BlockCategories categories;

    private boolean enabled = true;
    private double chance = 0.15;
    private double chanceMisuse = 0.30;
    private double selfDamage = 1.0;      // 1.0 = полсердца
    private double perLevelBonus = 0.02;  // +2% к шансу за каждый уровень сверх первого
    private boolean bypassArmor = true;
    private boolean neverKill = true;     // не добивать игрока собственным инструментом
    private boolean onBlockBreak = true;
    private boolean onAttack = true;
    private boolean particles = true;
    private boolean message = true;
    private String messageText = "§4§oКолючий инструмент впивается в руку...";
    private String sound = "entity.player.attack.crit";
    private float soundVolume = 0.7f;
    private float soundPitch = 0.7f;

    /** Пометка «это наш собственный урон» — чтобы не зациклиться и погасить броню. */
    private final Map<UUID, Long> selfDamageMark = new HashMap<>();
    private static final long SELF_MARK_TTL_MS = 500;

    public PricklyManager(Smakenchant plugin, CustomEnchantStore store, CustomEnchantment enchant, BlockCategories categories) {
        this.plugin = plugin;
        this.store = store;
        this.enchant = enchant;
        this.categories = categories;
    }

    public CustomEnchantment enchant() { return enchant; }

    // =====================================================================
    //  КОНФИГ
    // =====================================================================

    public void loadConfig(ConfigurationSection root) {
        ConfigurationSection s = root == null ? null : root.getConfigurationSection("prickly");
        if (s == null) s = new YamlConfiguration();

        enabled = s.getBoolean("enabled", true);
        chance = clamp01(s.getDouble("chance", 0.15));
        chanceMisuse = clamp01(s.getDouble("chance-misuse", 0.30));
        selfDamage = Math.max(0.0, s.getDouble("self-damage", 1.0));
        perLevelBonus = s.getDouble("chance-per-extra-level", 0.02);
        bypassArmor = s.getBoolean("bypass-armor", true);
        neverKill = s.getBoolean("never-kill", true);
        onBlockBreak = s.getBoolean("on-block-break", true);
        onAttack = s.getBoolean("on-attack", true);
        particles = s.getBoolean("particles", true);
        message = s.getBoolean("message", true);
        messageText = s.getString("message-text", "§4§oКолючий инструмент впивается в руку...");
        sound = s.getString("sound", "entity.player.attack.crit");
        soundVolume = (float) s.getDouble("sound-volume", 0.7);
        soundPitch = (float) s.getDouble("sound-pitch", 0.7);

        if (chanceMisuse < chance) chanceMisuse = chance;

        enchant.tableChance(clamp01(s.getDouble("table-chance-level-1", 0.05)))
                .tableWeight(s.getInt("weight", 4))
                .anvilCostPerLevel(s.getInt("anvil-cost-per-level", 2));

        plugin.getLogger().info("[Колючий] enabled=" + enabled + " шанс=" + pct(chance)
                + " не-по-назначению=" + pct(chanceMisuse) + " урон=" + selfDamage + " (полсердца)");
    }

    private static double clamp01(double d) { return Math.max(0.0, Math.min(1.0, d)); }

    private static String pct(double d) { return Math.round(d * 100.0) + "%"; }

    // =====================================================================
    //  ЛОМАНИЕ БЛОКОВ
    // =====================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent e) {
        if (!enabled || !onBlockBreak) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

        ItemStack tool = p.getInventory().getItemInMainHand();
        int level = store.getLevel(tool, enchant);
        if (level <= 0) return;

        boolean proper = categories.isProperUse(tool.getType(), e.getBlock());
        double ch = (proper ? chance : chanceMisuse) + (level - 1) * perLevelBonus;
        ch = Math.min(chanceMisuse, ch);

        if (ThreadLocalRandom.current().nextDouble() < ch) prick(p, !proper);
    }

    // =====================================================================
    //  АТАКА
    // =====================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!enabled || !onAttack) return;
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity victim)) return;
        if (victim.getUniqueId().equals(p.getUniqueId())) return; // не наказываем за наше же самоповреждение
        if (e.getFinalDamage() <= 0.0) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

        ItemStack weapon = p.getInventory().getItemInMainHand();
        if (weapon == null || !SmakenchantUtil.isMeleeWeapon(weapon.getType())) return;
        int level = store.getLevel(weapon, enchant);
        if (level <= 0) return;

        double ch = Math.min(chanceMisuse, chance + (level - 1) * perLevelBonus);
        if (ThreadLocalRandom.current().nextDouble() < ch) prick(p, false);
    }

    // =====================================================================
    //  САМОПОВРЕЖДЕНИЕ
    // =====================================================================

    public void prick(Player p, boolean misuse) {
        if (p == null || !p.isOnline() || p.isDead() || selfDamage <= 0.0) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

        UUID id = p.getUniqueId();
        selfDamageMark.put(id, System.currentTimeMillis());

        Location loc = p.getLocation();
        SmakenchantUtil.playSound(p.getWorld(), loc, sound, soundVolume, soundPitch, Sound.ENTITY_PLAYER_ATTACK_CRIT);
        if (particles) {
            try {
                p.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, loc.clone().add(0, 1.0, 0), 4, 0.2, 0.25, 0.2, 0.0);
                p.getWorld().spawnParticle(Particle.ITEM, loc.clone().add(0, 1.0, 0), 6, 0.25, 0.25, 0.25, 0.05,
                        new ItemStack(misuse ? Material.IRON_NUGGET : Material.CACTUS));
            } catch (Throwable ignored) {}
        }
        if (message && messageText != null && !messageText.isEmpty()) p.sendMessage(messageText);

        Bukkit.getScheduler().runTask(plugin, () -> dealSelfDamage(p, selfDamage));
    }

    @SuppressWarnings("deprecation")
    private void dealSelfDamage(Player p, double amount) {
        if (p == null || !p.isOnline() || p.isDead()) return;
        double health = p.getHealth();
        if (neverKill && health <= amount + 0.5) {
            amount = health - 1.0; // оставляем минимум полсердца
            if (amount <= 0.0) return;
        }
        try {
            if (bypassArmor) {
                p.setHealth(Math.max(neverKill ? 1.0 : 0.0, health - amount));
            } else {
                p.damage(amount);
            }
            p.setNoDamageTicks(0); // следующий реальный урон должен пройти нормально
        } catch (Throwable ignored) {}
    }

    /** Гасим модификаторы брони на нашем собственном уроне (если bypass-armor). */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onSelfDamage(EntityDamageEvent e) {
        if (!enabled || !bypassArmor) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (!isSelfDamage(p.getUniqueId())) return;
        try {
            for (EntityDamageEvent.DamageModifier m : EntityDamageEvent.DamageModifier.values()) {
                if (m == EntityDamageEvent.DamageModifier.BASE) continue;
                e.setDamage(m, 0.0);
            }
        } catch (Throwable ignored) {}
    }

    public boolean isSelfDamage(UUID id) {
        Long mark = selfDamageMark.get(id);
        return mark != null && System.currentTimeMillis() - mark <= SELF_MARK_TTL_MS;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        selfDamageMark.remove(e.getPlayer().getUniqueId());
    }
}
