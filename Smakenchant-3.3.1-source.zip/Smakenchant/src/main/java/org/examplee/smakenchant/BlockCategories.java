package org.examplee.smakenchant;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Категории блоков из конфига — нужны проклятию «Колючий», чтобы понять,
 * используется ли инструмент по назначению (лопата по камню = не по назначению).
 * <p>
 * В списке категории поддерживаются:
 * <ul>
 *   <li>точные имена материалов: {@code STONE}, {@code DIRT};</li>
 *   <li>регулярки: {@code "regex:^.*_ORE$"};</li>
 *   <li>ванильные теги: {@code "#mineable/pickaxe"}, {@code "#base_stone_overworld"}.</li>
 * </ul>
 */
public final class BlockCategories {

    private final Map<String, List<String>> patterns = new LinkedHashMap<>();
    private final Map<String, List<String>> toolProperCategories = new LinkedHashMap<>();

    public static final String CAT_STONE = "stone";
    public static final String CAT_DIRT = "dirt";
    public static final String CAT_WOOD = "wood";
    public static final String CAT_PLANT = "plant";
    public static final String CAT_LEAVES = "leaves";
    public static final String CAT_WOOL = "wool";
    public static final String CAT_WEB = "web";

    public void load(ConfigurationSection root) {
        patterns.clear();
        toolProperCategories.clear();

        ConfigurationSection cats = root == null ? null : root.getConfigurationSection("block-categories");
        if (cats == null) cats = new YamlConfiguration();
        for (String name : cats.getKeys(false)) {
            List<String> list = new ArrayList<>();
            for (Object o : cats.getList(name, List.of())) list.add(String.valueOf(o));
            patterns.put(name.toLowerCase(Locale.ROOT), list);
        }

        ConfigurationSection proper = root == null ? null : root.getConfigurationSection("prickly.proper-use");
        if (proper == null) proper = new YamlConfiguration();
        for (String tool : proper.getKeys(false)) {
            List<String> list = new ArrayList<>();
            for (Object o : proper.getList(tool, List.of())) list.add(String.valueOf(o).toLowerCase(Locale.ROOT));
            toolProperCategories.put(tool.toLowerCase(Locale.ROOT), list);
        }
    }

    public boolean inCategory(Block block, String category) {
        if (block == null || category == null) return false;
        List<String> pats = patterns.get(category.toLowerCase(Locale.ROOT));
        return SmakenchantUtil.matchesCategory(block, pats);
    }

    public boolean inAnyCategory(Block block, List<String> categories) {
        if (block == null || categories == null) return false;
        for (String c : categories) if (inCategory(block, c)) return true;
        return false;
    }

    /** Ключ инструмента для proper-use ("pickaxe", "shovel", ...). */
    public static String toolKey(Material m) {
        if (m == null) return null;
        if (SmakenchantUtil.PICKAXES.contains(m)) return "pickaxe";
        if (SmakenchantUtil.SHOVELS.contains(m)) return "shovel";
        if (SmakenchantUtil.AXES.contains(m)) return "axe";
        if (SmakenchantUtil.HOES.contains(m)) return "hoe";
        if (SmakenchantUtil.SWORDS.contains(m)) return "sword";
        String n = m.name();
        if (n.equals("SHEARS")) return "shears";
        return null;
    }

    /**
     * Используется ли инструмент по назначению на этом блоке.
     * Для «не-инструментов» (меч по камню, лопата по дереву и т.п.) — false.
     */
    public boolean isProperUse(Material tool, Block block) {
        String key = toolKey(tool);
        if (key == null) return false;
        List<String> cats = toolProperCategories.get(key);
        if (cats == null || cats.isEmpty()) {
            // дефолты на случай пустого конфига
            cats = defaultProper(key);
        }
        return inAnyCategory(block, cats);
    }

    private static List<String> defaultProper(String toolKey) {
        return switch (toolKey) {
            case "pickaxe" -> List.of(CAT_STONE);
            case "shovel" -> List.of(CAT_DIRT);
            case "axe" -> List.of(CAT_WOOD);
            case "hoe" -> List.of(CAT_PLANT, CAT_LEAVES);
            case "shears" -> List.of(CAT_PLANT, CAT_LEAVES, CAT_WOOL, CAT_WEB);
            case "sword" -> List.of(CAT_WEB);
            default -> List.of();
        };
    }
}
