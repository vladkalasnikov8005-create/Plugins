package org.examplee.smakenchant;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.Arrays;
import java.util.List;

/**
 * Скорость ломания для «Медленного» и «Шустрого».
 * Paper 26.2 предоставляет нативный атрибут {@link Attribute#BLOCK_BREAK_SPEED}, поэтому
 * блоки не приходится отменять/ломать искусственно: дроп, опыт, регионы и анимация работают ванильно.
 */
public final class MiningSpeedManager implements Listener {
    private final Smakenchant plugin;
    private final CustomEnchantStore store;
    private final CustomEnchantment slow, swift;
    private final NamespacedKey key;
    private int[] slowPercents={10,15,20}, swiftPercents={10,15,20,25};
    private boolean enabled=true;
    private BukkitTask task;

    public MiningSpeedManager(Smakenchant plugin, CustomEnchantStore store, CustomEnchantment slow, CustomEnchantment swift) {
        this.plugin=plugin; this.store=store; this.slow=slow; this.swift=swift;
        this.key=new NamespacedKey(plugin,"custom_block_break_speed");
    }
    public CustomEnchantment slow(){return slow;} public CustomEnchantment swift(){return swift;}

    public void loadConfig(ConfigurationSection root){
        ConfigurationSection sl=section(root,"slow-curse"), sw=section(root,"swift");
        enabled=sl.getBoolean("mining.enabled",true)||sw.getBoolean("mining.enabled",true);
        slowPercents=ints(sl,"mining.slow-percents",slowPercents);
        swiftPercents=ints(sw,"mining.speed-percents",swiftPercents);
        slow.tableChance(sl.getDouble("table-chance-level-1",.05),sl.getDouble("table-chance-level-2",.02),sl.getDouble("table-chance-level-3",.01))
                .tableWeight(sl.getInt("weight",4)).anvilCostPerLevel(sl.getInt("anvil-cost-per-level",2));
        swift.tableChance(sw.getDouble("table-chance-level-1",.06),sw.getDouble("table-chance-level-2",.03),sw.getDouble("table-chance-level-3",.015),sw.getDouble("table-chance-level-4",.008))
                .tableWeight(sw.getInt("weight",5)).anvilCostPerLevel(sw.getInt("anvil-cost-per-level",4));
        start();
        plugin.getLogger().info("[Ломание] Медленный="+Arrays.toString(slowPercents)+"%, Шустрый="+Arrays.toString(swiftPercents)+"%");
    }
    private static ConfigurationSection section(ConfigurationSection r,String p){ConfigurationSection s=r==null?null:r.getConfigurationSection(p);return s==null?new YamlConfiguration():s;}
    private static int[] ints(ConfigurationSection s,String p,int[] d){List<Integer> l=s.getIntegerList(p);if(l.isEmpty())return d.clone();return l.stream().mapToInt(Integer::intValue).toArray();}
    private static int pct(int[] a,int l){return l<=0?0:a[Math.min(l,a.length)-1];}

    private void start(){if(task!=null)task.cancel();task=Bukkit.getScheduler().runTaskTimer(plugin,()->{for(Player p:Bukkit.getOnlinePlayers())sync(p);},1,5);}
    public void stop(){if(task!=null)task.cancel();for(Player p:Bukkit.getOnlinePlayers())clear(p);}
    private void clear(Player p){AttributeInstance a=p.getAttribute(Attribute.BLOCK_BREAK_SPEED);if(a!=null)a.removeModifier(key);}
    private void sync(Player p){
        AttributeInstance a=p.getAttribute(Attribute.BLOCK_BREAK_SPEED);if(a==null)return;a.removeModifier(key);
        if(!enabled||p.getGameMode()==GameMode.CREATIVE||p.getGameMode()==GameMode.SPECTATOR)return;
        ItemStack hand=p.getInventory().getItemInMainHand();if(hand==null||!SmakenchantUtil.isToolOrWeapon(hand.getType()))return;
        int sl=store.getLevel(hand,slow),sw=store.getLevel(hand,swift);
        double scalar=-pct(slowPercents,sl)/100.0+pct(swiftPercents,sw)/100.0;
        if(Math.abs(scalar)<.001)return;
        a.addTransientModifier(new AttributeModifier(key,scalar,AttributeModifier.Operation.ADD_SCALAR));
    }
    public double miningModifier(ItemStack hand){int sl=store.getLevel(hand,slow),sw=store.getLevel(hand,swift);return 1.0-pct(slowPercents,sl)/100.0+pct(swiftPercents,sw)/100.0;}
    public List<String> debug(Player p){return List.of("enabled="+enabled,"BLOCK_BREAK_SPEED="+(p.getAttribute(Attribute.BLOCK_BREAK_SPEED)==null?"n/a":p.getAttribute(Attribute.BLOCK_BREAK_SPEED).getValue()),"модификатор предмета="+miningModifier(p.getInventory().getItemInMainHand()));}
    @EventHandler public void onQuit(PlayerQuitEvent e){clear(e.getPlayer());}
}
