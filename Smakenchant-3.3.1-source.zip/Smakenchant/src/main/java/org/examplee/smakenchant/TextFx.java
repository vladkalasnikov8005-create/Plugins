package org.examplee.smakenchant;

import org.bukkit.ChatColor;

/**
 * Утилиты оформления текста (градиент, римские цифры, очистка lore).
 */
public final class TextFx {

    // ============== ГРАДИЕНТ ==============
    private static final int GRAD_R1 = 201, GRAD_G1 = 168, GRAD_B1 = 232;
    private static final int GRAD_R2 = 184, GRAD_G2 = 176, GRAD_B2 = 192;

    private TextFx() {}

    /** Фиолетово-серый градиент (как было у «Многоуровневого прыжка»). */
    public static String gradient(String text) {
        return gradient(text, GRAD_R1, GRAD_G1, GRAD_B1, GRAD_R2, GRAD_G2, GRAD_B2);
    }

    public static String gradient(String text, int r1, int g1, int b1, int r2, int g2, int b2) {
        if (text == null || text.isEmpty()) return "";
        text = ChatColor.stripColor(text);
        int len = text.length();
        StringBuilder sb = new StringBuilder(len * 8);
        for (int i = 0; i < len; i++) {
            char ch = text.charAt(i);
            double t = len <= 1 ? 0 : (double) i / (len - 1);
            int r = (int) Math.round(r1 + (r2 - r1) * t);
            int g = (int) Math.round(g1 + (g2 - g1) * t);
            int b = (int) Math.round(b1 + (b2 - b1) * t);
            String hex = String.format("%02x%02x%02x", r, g, b);
            sb.append("§x");
            for (char c : hex.toCharArray()) sb.append('§').append(c);
            sb.append(ch);
        }
        return sb.toString();
    }

    /** Тёмно-красный градиент для проклятий. */
    public static String curseGradient(String text) {
        return gradient(text, 196, 64, 64, 120, 40, 48);
    }

    /** Отдельная палитра для каждой секции предметов. */
    public static String paletteGradient(String text, String palette, boolean curse) {
        if (curse) return switch (palette) {
            case "ranged" -> gradient(text, 176, 72, 210, 92, 38, 130);
            case "armor" -> gradient(text, 80, 120, 190, 38, 55, 105);
            case "boots" -> gradient(text, 120, 110, 80, 65, 50, 35);
            case "tools" -> gradient(text, 190, 105, 55, 105, 48, 28);
            case "shield" -> gradient(text, 145, 85, 120, 72, 38, 68);
            default -> curseGradient(text);
        };
        return switch (palette) {
            case "ranged" -> gradient(text, 95, 210, 235, 70, 115, 220);
            case "armor" -> gradient(text, 125, 175, 255, 110, 110, 220);
            case "boots" -> gradient(text, 100, 230, 165, 60, 150, 120);
            case "tools" -> gradient(text, 255, 195, 75, 215, 120, 50);
            case "shield" -> gradient(text, 190, 165, 235, 110, 105, 180);
            default -> gradient(text);
        };
    }

    private static final String[] ROMAN = {"0", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    public static String roman(int level) {
        return level >= 0 && level < ROMAN.length ? ROMAN[level] : String.valueOf(level);
    }

    /**
     * Формирует строку lore для зачарования.
     *
     * @param curse true = проклятие (красный градиент), false = обычное зачарование
     * @param style "gradient" | "legacy" | "plain"
     */
    public static String loreLine(String displayName, int level, boolean curse, String style) {
        String raw = displayName + " " + roman(level);
        if (style == null) style = "gradient";
        return switch (style.toLowerCase(java.util.Locale.ROOT)) {
            case "plain" -> raw;
            case "legacy" -> (curse ? "§4§o" : "§d") + raw;
            default -> curse ? curseGradient(raw) : gradient(raw);
        };
    }
}
