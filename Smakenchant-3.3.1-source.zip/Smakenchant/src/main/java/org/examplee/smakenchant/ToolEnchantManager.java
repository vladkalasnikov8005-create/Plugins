package org.examplee.smakenchant;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Item;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.inventory.ItemStack;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Переплавка I–V и Опытный шахтёр I–III. */
public final class ToolEnchantManager implements Listener {
    private final CustomEnchantStore store;private final CustomEnchantment smelt,xp;
    private final int[] chances={10,25,50,75,100}, xpBonus={25,50,100};
    private static final Map<Material,Material> ORES=Map.ofEntries(
            Map.entry(Material.IRON_ORE,Material.IRON_INGOT),Map.entry(Material.DEEPSLATE_IRON_ORE,Material.IRON_INGOT),
            Map.entry(Material.GOLD_ORE,Material.GOLD_INGOT),Map.entry(Material.DEEPSLATE_GOLD_ORE,Material.GOLD_INGOT),Map.entry(Material.NETHER_GOLD_ORE,Material.GOLD_INGOT),
            Map.entry(Material.COPPER_ORE,Material.COPPER_INGOT),Map.entry(Material.DEEPSLATE_COPPER_ORE,Material.COPPER_INGOT),Map.entry(Material.ANCIENT_DEBRIS,Material.NETHERITE_SCRAP));
    public ToolEnchantManager(CustomEnchantStore s,CustomEnchantment smelt,CustomEnchantment xp){store=s;this.smelt=smelt;this.xp=xp;}
    public void loadConfig(ConfigurationSection r){cfg(r,"auto-smelt",smelt,5);cfg(r,"experienced-miner",xp,3);}
    private void cfg(ConfigurationSection r,String p,CustomEnchantment e,int levels){ConfigurationSection s=r.getConfigurationSection(p);if(s==null)return;double[]c=new double[levels];for(int i=0;i<levels;i++)c[i]=s.getDouble("table-chance-level-"+(i+1),Math.max(.005,.05/(i+1)));e.tableChance(c).tableWeight(s.getInt("weight",3)).anvilCostPerLevel(s.getInt("anvil-cost-per-level",3));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void onDrops(BlockDropItemEvent e){
        ItemStack tool=e.getPlayer().getInventory().getItemInMainHand();int l=store.getLevel(tool,smelt);if(l<=0||ThreadLocalRandom.current().nextInt(100)>=chances[Math.min(l,5)-1])return;
        Material result=ORES.get(e.getBlockState().getType());if(result==null)return;
        // Шёлковое касание сохраняет блок и имеет приоритет.
        if(tool.containsEnchantment(org.bukkit.enchantments.Enchantment.SILK_TOUCH))return;
        int amount=0;for(Item item:e.getItems())amount+=item.getItemStack().getAmount();if(amount<=0)amount=1;
        for(Item item:new ArrayList<>(e.getItems()))item.remove();e.getItems().clear();
        e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(),new ItemStack(result,amount));
    }
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void onBreak(BlockBreakEvent e){int l=store.getLevel(e.getPlayer().getInventory().getItemInMainHand(),xp);if(l>0&&e.getExpToDrop()>0)e.setExpToDrop((int)Math.ceil(e.getExpToDrop()*(1+xpBonus[Math.min(l,3)-1]/100.0)));}
}
