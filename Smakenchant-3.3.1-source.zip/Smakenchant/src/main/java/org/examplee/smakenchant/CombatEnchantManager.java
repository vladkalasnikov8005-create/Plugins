package org.examplee.smakenchant;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Атаки «Медленного»/«Шустрого» и «Переливание крови». */
public final class CombatEnchantManager implements Listener {
    private final Smakenchant plugin;
    private final CustomEnchantStore store;
    private final CustomEnchantment slow, swift, blood;
    private final NamespacedKey attackSpeedKey;
    private final Map<UUID, Double> bloodRemainder = new HashMap<>();
    private BukkitTask task;
    private int[] slowPct = {10, 15, 20};
    private int[] swiftPct = {10, 15, 20, 25};
    private boolean enabled = true;
    private boolean bloodEnabled = true;
    private double damagePerHalfHeart = 3.0;

    public CombatEnchantManager(Smakenchant plugin, CustomEnchantStore store,
                                CustomEnchantment slow, CustomEnchantment swift, CustomEnchantment blood) {
        this.plugin = plugin; this.store = store; this.slow = slow; this.swift = swift; this.blood = blood;
        this.attackSpeedKey = new NamespacedKey(plugin, "custom_attack_speed");
    }

    public void loadConfig(ConfigurationSection root) {
        ConfigurationSection sl = section(root, "slow-curse");
        ConfigurationSection sw = section(root, "swift");
        ConfigurationSection bl = section(root, "blood-transfusion");
        enabled = sl.getBoolean("combat.enabled", true) || sw.getBoolean("combat.enabled", true);
        slowPct = ints(sl, "combat.slow-percents", new int[]{10,15,20});
        swiftPct = ints(sw, "combat.speed-percents", new int[]{10,15,20,25});
        bloodEnabled = bl.getBoolean("enabled", true);
        damagePerHalfHeart = Math.max(0.1, bl.getDouble("damage-per-half-heart", 3.0));
        blood.tableChance(bl.getDouble("table-chance-level-1", 0.025), bl.getDouble("table-chance-level-2", 0.008))
                .tableWeight(bl.getInt("weight", 2)).anvilCostPerLevel(bl.getInt("anvil-cost-per-level", 6));
        startTask();
    }

    private static ConfigurationSection section(ConfigurationSection r, String p) {
        ConfigurationSection s = r == null ? null : r.getConfigurationSection(p);
        return s == null ? new YamlConfiguration() : s;
    }
    private static int[] ints(ConfigurationSection s, String p, int[] d) {
        java.util.List<Integer> v = s.getIntegerList(p); if (v.isEmpty()) return d;
        int[] a = new int[v.size()]; for(int i=0;i<a.length;i++) a[i]=v.get(i); return a;
    }
    private static int pct(int[] a, int l) { return l <= 0 ? 0 : a[Math.min(l,a.length)-1]; }

    private void startTask() {
        if (task != null) task.cancel();
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) sync(p);
        }, 1L, 5L);
    }
    public void stop() { if(task != null) task.cancel(); for(Player p:Bukkit.getOnlinePlayers()) clear(p); }

    private void sync(Player p) {
        AttributeInstance a = p.getAttribute(Attribute.ATTACK_SPEED); if(a == null) return;
        a.removeModifier(attackSpeedKey);
        if (!enabled || p.getGameMode()==GameMode.CREATIVE || p.getGameMode()==GameMode.SPECTATOR) return;
        ItemStack hand = p.getInventory().getItemInMainHand();
        int sl = store.getLevel(hand, slow), sw = store.getLevel(hand, swift);
        double scalar = -pct(slowPct,sl)/100.0 + pct(swiftPct,sw)/100.0;
        if (Math.abs(scalar) < 0.001) return;
        a.addTransientModifier(new AttributeModifier(attackSpeedKey, scalar, AttributeModifier.Operation.ADD_SCALAR));
    }
    private void clear(Player p) { AttributeInstance a=p.getAttribute(Attribute.ATTACK_SPEED); if(a!=null) a.removeModifier(attackSpeedKey); }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!bloodEnabled || !(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity)) return;
        ItemStack hand=p.getInventory().getItemInMainHand(); int level=store.getLevel(hand,blood);
        if(level<=0 || !SmakenchantUtil.MELEE_WEAPONS.contains(hand.getType()) || e.getFinalDamage()<=0) return;
        double pool=bloodRemainder.getOrDefault(p.getUniqueId(),0.0)+e.getFinalDamage();
        int units=(int)Math.floor(pool/damagePerHalfHeart); pool-=units*damagePerHalfHeart;
        bloodRemainder.put(p.getUniqueId(),pool);
        if(units<=0) return;
        double heal=units*level; // 1 health point = half a heart, per level
        Bukkit.getScheduler().runTask(plugin,()->{
            if(!p.isOnline()||p.isDead()) return;
            double max=p.getAttribute(Attribute.MAX_HEALTH)!=null?p.getAttribute(Attribute.MAX_HEALTH).getValue():20.0;
            double actual=Math.min(heal,max-p.getHealth()); if(actual<=0)return;
            EntityRegainHealthEvent ev=new EntityRegainHealthEvent(p,actual,EntityRegainHealthEvent.RegainReason.CUSTOM);
            Bukkit.getPluginManager().callEvent(ev); if(ev.isCancelled())return;
            p.setHealth(Math.min(max,p.getHealth()+ev.getAmount()));
            p.getWorld().spawnParticle(Particle.HEART,p.getLocation().add(0,1.2,0),Math.max(1,units),0.25,0.25,0.25,0);
            SmakenchantUtil.playSound(p.getWorld(),p.getLocation(),"entity.experience_orb.pickup",0.45f,1.6f,Sound.ENTITY_EXPERIENCE_ORB_PICKUP);
        });
    }

    @EventHandler public void onQuit(PlayerQuitEvent e){bloodRemainder.remove(e.getPlayer().getUniqueId());}
}
