package org.examplee.smakenchant;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Материалы, категории блоков, звуки и прочие мелочи.
 */
public final class SmakenchantUtil {

    private SmakenchantUtil() {}

    // ============== НАБОРЫ ПРЕДМЕТОВ ==============

    public static final Set<Material> SWORDS = EnumSet.of(
            Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD,
            Material.GOLDEN_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD);

    public static final Set<Material> AXES = EnumSet.of(
            Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE,
            Material.GOLDEN_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE);

    public static final Set<Material> PICKAXES = EnumSet.of(
            Material.WOODEN_PICKAXE, Material.STONE_PICKAXE, Material.IRON_PICKAXE,
            Material.GOLDEN_PICKAXE, Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE);

    public static final Set<Material> SHOVELS = EnumSet.of(
            Material.WOODEN_SHOVEL, Material.STONE_SHOVEL, Material.IRON_SHOVEL,
            Material.GOLDEN_SHOVEL, Material.DIAMOND_SHOVEL, Material.NETHERITE_SHOVEL);

    public static final Set<Material> HOES = EnumSet.of(
            Material.WOODEN_HOE, Material.STONE_HOE, Material.IRON_HOE,
            Material.GOLDEN_HOE, Material.DIAMOND_HOE, Material.NETHERITE_HOE);

    /** Топоры + мечи + булавы + трезубцы («копья») — всё, чем нормально бьют в ближнем бою. */
    public static final Set<Material> MELEE_WEAPONS;

    /** Инструменты, которые вообще умеют ломать блоки. */
    public static final Set<Material> DIGGING_TOOLS;

    /** Всё, что имеет прочность и является инструментом/оружием/бронёй. */
    public static final Set<Material> ARMOR = EnumSet.of(
            Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS,
            Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS,
            Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS,
            Material.GOLDEN_HELMET, Material.GOLDEN_CHESTPLATE, Material.GOLDEN_LEGGINGS, Material.GOLDEN_BOOTS,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
            Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS,
            Material.TURTLE_HELMET);

    public static final Set<Material> BOOTS = EnumSet.of(
            Material.LEATHER_BOOTS, Material.CHAINMAIL_BOOTS, Material.IRON_BOOTS,
            Material.GOLDEN_BOOTS, Material.DIAMOND_BOOTS, Material.NETHERITE_BOOTS);

    static {
        EnumSet<Material> melee = EnumSet.copyOf(SWORDS);
        melee.addAll(AXES);
        addIfExists(melee, "MACE");
        addIfExists(melee, "TRIDENT");
        addIfExists(melee, "SPEAR"); // на будущее, если появится в новых версиях
        MELEE_WEAPONS = melee;

        EnumSet<Material> dig = EnumSet.copyOf(PICKAXES);
        dig.addAll(SHOVELS);
        dig.addAll(AXES);
        dig.addAll(HOES);
        DIGGING_TOOLS = dig;
    }

    private static void addIfExists(Set<Material> set, String name) {
        try {
            Material m = Material.matchMaterial(name);
            if (m != null) set.add(m);
        } catch (Throwable ignored) {}
    }

    public static boolean isMeleeWeapon(Material m) { return MELEE_WEAPONS.contains(m); }

    public static boolean isDiggingTool(Material m) { return DIGGING_TOOLS.contains(m); }

    public static boolean isToolOrWeapon(Material m) { return isDiggingTool(m) || isMeleeWeapon(m); }

    public static boolean isArmor(Material m) { return ARMOR.contains(m); }

    /** «Подходит для всего» — любой предмет с прочностью (инструмент, оружие, броня, элитра, щит...). */
    public static boolean isDamageableTool(Material m) {
        if (m == null || !m.isItem()) return false;
        if (isToolOrWeapon(m) || isArmor(m)) return true;
        if (m == Material.ELYTRA || m == Material.SHIELD || m == Material.FISHING_ROD
                || m == Material.FLINT_AND_STEEL || m == Material.SHEARS
                || m == Material.BOW || m == Material.CROSSBOW
                || m == Material.CARROT_ON_A_STICK || m == Material.WARPED_FUNGUS_ON_A_STICK
                || m == Material.BRUSH || m == Material.SPYGLASS) return true;
        // крайние случаи новых версий: короткое максимальное повреждение > 0
        try {
            ItemStack probe = new ItemStack(m);
            if (probe.getItemMeta() instanceof Damageable d) {
                return d.getMaxDamage() > 0;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    // ============== ПРОЧНОСТЬ ==============

    public static int getDamage(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0;
        ItemMeta meta = stack.getItemMeta();
        return meta instanceof Damageable d ? d.getDamage() : 0;
    }

    public static int getMaxDamage(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0;
        ItemMeta meta = stack.getItemMeta();
        return meta instanceof Damageable d ? Math.max(0, d.getMaxDamage()) : 0;
    }

    public static boolean hasDurability(ItemStack stack) {
        return getMaxDamage(stack) > 0;
    }

    /**
     * Прямо списывает прочность мимо ванильного {@code PlayerItemDamageEvent}
     * (используется для брони, где событие вызывается не на всех ядрах).
     *
     * @return true, если предмет сломался/исчез
     */
    public static boolean applyRawDurabilityLoss(ItemStack stack, int amount) {
        if (stack == null || amount <= 0) return false;
        if (!(stack.getItemMeta() instanceof Damageable d)) return false;
        int max = d.getMaxDamage();
        if (max <= 0) return false;
        int newDamage = d.getDamage() + amount;
        if (newDamage >= max) return true; // предмет должен сломаться — ломает ванилла
        d.setDamage(newDamage);
        stack.setItemMeta(d);
        return false;
    }

    // ============== КАТЕГОРИИ БЛОКОВ ==============

    /**
     * Проверяет блок по списку паттернов из конфига.
     * Поддерживаются: точные имена ("STONE"), regex ("regex:^.*_ORE$") и теги ("#mineable/pickaxe").
     */
    public static boolean matchesCategory(Block block, List<String> patterns) {
        if (block == null || patterns == null || patterns.isEmpty()) return false;
        String name = block.getType().name();
        for (String raw : patterns) {
            if (raw == null) continue;
            String p = raw.trim();
            if (p.isEmpty()) continue;
            if (p.startsWith("#")) {
                try {
                    org.bukkit.Tag<Material> tag = org.bukkit.Bukkit.getTag(
                            org.bukkit.Tag.REGISTRY_BLOCKS,
                            NamespacedKey.minecraft(p.substring(1).toLowerCase(Locale.ROOT)), Material.class);
                    if (tag != null && tag.isTagged(block.getType())) return true;
                } catch (Throwable ignored) {}
                continue;
            }
            if (p.startsWith("regex:")) {
                try {
                    if (Pattern.compile(p.substring(6), Pattern.CASE_INSENSITIVE).matcher(name).find()) return true;
                } catch (Throwable ignored) {}
                continue;
            }
            if (p.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    // ============== ЗВУКИ ==============

    /**
     * Надёжный резолв звука. В новых версиях {@link Sound} — интерфейс, а не enum,
     * поэтому {@code Sound.valueOf()} больше не работает: идём через Registry.
     */
    public static Sound resolveSound(String name, Sound fallback) {
        if (name == null || name.isBlank()) return fallback;
        String key = name.trim().toLowerCase(Locale.ROOT).replace('_', '.');
        try {
            Sound s = Registry.SOUNDS.get(NamespacedKey.minecraft(key));
            if (s != null) return s;
        } catch (Throwable ignored) {}
        // вторая попытка: имя enum-константы (старые конфиги)
        try {
            Sound s = Registry.SOUNDS.get(NamespacedKey.minecraft(name.trim().toLowerCase(Locale.ROOT)));
            if (s != null) return s;
        } catch (Throwable ignored) {}
        return fallback;
    }

    public static void playSound(World w, org.bukkit.Location loc, String name, float vol, float pitch, Sound fallback) {
        try {
            w.playSound(loc, resolveSound(name, fallback), vol, pitch);
        } catch (Throwable ignored) {}
    }
}
