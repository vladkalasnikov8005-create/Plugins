package org.examplee.smakenchant;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Проклятие тяжести и Ледяное касание. */
public final class GravityAndFrostManager implements Listener {
    private final Smakenchant plugin; private final CustomEnchantStore store;
    private final CustomEnchantment gravity, frost;
    private final NamespacedKey gravityKey;
    private BukkitTask task;
    private int[] gravitySlow={5,10,15};
    private double[] frostChance={.15,.25,.35};
    private int[] frostSeconds={1,2,3};
    private int[] frostAmplifier={0,0,1};
    private int[] frozenTicks={20,40,60};

    public GravityAndFrostManager(Smakenchant plugin,CustomEnchantStore store,CustomEnchantment gravity,CustomEnchantment frost){
        this.plugin=plugin;this.store=store;this.gravity=gravity;this.frost=frost;
        gravityKey=new NamespacedKey(plugin,"gravity_speed");
    }
    public void loadConfig(ConfigurationSection root){
        ConfigurationSection g=sec(root,"gravity-curse"),f=sec(root,"frost-touch");
        gravitySlow=ints(g,"movement-slow-percents",gravitySlow);
        frostChance=doubles(f,"chance",frostChance);frostSeconds=ints(f,"slowness-seconds",frostSeconds);
        frostAmplifier=ints(f,"slowness-amplifier",frostAmplifier);frozenTicks=ints(f,"frozen-ticks",frozenTicks);
        gravity.tableChance(g.getDouble("table-chance-level-1",.04),g.getDouble("table-chance-level-2",.02),g.getDouble("table-chance-level-3",.01))
                .tableWeight(g.getInt("weight",3)).anvilCostPerLevel(g.getInt("anvil-cost-per-level",2));
        frost.tableChance(f.getDouble("table-chance-level-1",.04),f.getDouble("table-chance-level-2",.02),f.getDouble("table-chance-level-3",.01))
                .tableWeight(f.getInt("weight",3)).anvilCostPerLevel(f.getInt("anvil-cost-per-level",4));
        start();
    }
    private static ConfigurationSection sec(ConfigurationSection r,String p){ConfigurationSection s=r==null?null:r.getConfigurationSection(p);return s==null?new YamlConfiguration():s;}
    private static int[] ints(ConfigurationSection s,String p,int[] d){List<Integer> l=s.getIntegerList(p);return l.isEmpty()?d:l.stream().mapToInt(Integer::intValue).toArray();}
    private static double[] doubles(ConfigurationSection s,String p,double[] d){List<Double> l=s.getDoubleList(p);if(l.isEmpty())return d;double[]a=new double[l.size()];for(int i=0;i<a.length;i++)a[i]=l.get(i);return a;}
    private static int at(int[]a,int l){return a[Math.min(Math.max(l,1),a.length)-1];}private static double at(double[]a,int l){return a[Math.min(Math.max(l,1),a.length)-1];}
    private void start(){if(task!=null)task.cancel();task=Bukkit.getScheduler().runTaskTimer(plugin,()->{for(Player p:Bukkit.getOnlinePlayers())syncGravity(p);},1,10);}
    public void stop(){if(task!=null)task.cancel();for(Player p:Bukkit.getOnlinePlayers())clear(p);}
    private void clear(Player p){AttributeInstance a=p.getAttribute(Attribute.MOVEMENT_SPEED);if(a!=null)a.removeModifier(gravityKey);}
    private void syncGravity(Player p){
        AttributeInstance a=p.getAttribute(Attribute.MOVEMENT_SPEED);if(a==null)return;a.removeModifier(gravityKey);
        int level=0;for(ItemStack armor:p.getInventory().getArmorContents())level=Math.max(level,store.getLevel(armor,gravity));
        if(level<=0)return;double scalar=-at(gravitySlow,level)/100.0;
        a.addTransientModifier(new AttributeModifier(gravityKey,scalar,AttributeModifier.Operation.ADD_SCALAR));
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onAttack(EntityDamageByEntityEvent e){
        if(!(e.getDamager() instanceof Player p)||!(e.getEntity() instanceof LivingEntity victim)||e.getFinalDamage()<=0)return;
        ItemStack hand=p.getInventory().getItemInMainHand();int level=store.getLevel(hand,frost);if(level<=0)return;
        if(ThreadLocalRandom.current().nextDouble()>=at(frostChance,level))return;
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,at(frostSeconds,level)*20,at(frostAmplifier,level),false,true,true));
        victim.setFreezeTicks(Math.max(victim.getFreezeTicks(),at(frozenTicks,level)));
        victim.getWorld().spawnParticle(Particle.SNOWFLAKE,victim.getLocation().add(0,1,0),12,0.3,0.5,0.3,.02);
        SmakenchantUtil.playSound(victim.getWorld(),victim.getLocation(),"block.glass.break",.6f,1.5f,Sound.BLOCK_GLASS_BREAK);
    }
    @EventHandler public void onQuit(PlayerQuitEvent e){clear(e.getPlayer());}
}
