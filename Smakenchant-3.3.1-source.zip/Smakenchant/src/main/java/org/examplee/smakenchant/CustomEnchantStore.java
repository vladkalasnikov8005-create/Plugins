package org.examplee.smakenchant;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Хранилище кастомных зачарований в PersistentDataContainer предмета.
 * <p>
 * Ключ PDC: {@code smakenchant:<id>} (для «Многоуровневого прыжка» — старый
 * {@code smakenchant:multi_jump}, то есть существующие предметы продолжат работать).
 */
public final class CustomEnchantStore {

    private final Plugin plugin;
    private final Map<CustomEnchantment, NamespacedKey> keys = new LinkedHashMap<>();
    private String loreStyle = "gradient";

    public CustomEnchantStore(Plugin plugin) {
        this.plugin = plugin;
    }

    public void register(CustomEnchantment ench) {
        keys.put(ench, new NamespacedKey(plugin, ench.id()));
    }

    public void setLoreStyle(String style) { this.loreStyle = style == null ? "gradient" : style; }

    public Collection<CustomEnchantment> registered() { return keys.keySet(); }

    public NamespacedKey keyOf(CustomEnchantment ench) { return keys.get(ench); }

    // ============== ЧТЕНИЕ ==============

    public int getLevel(ItemStack stack, CustomEnchantment ench) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) return 0;
        NamespacedKey key = keys.get(ench);
        if (key == null) return 0;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return 0;
        // книги с зачарованиями:StoredEnchants хранят PDC в том же ItemMeta
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        Integer lvl = pdc.get(key, PersistentDataType.INTEGER);
        return lvl == null ? 0 : ench.clampLevel(lvl);
    }

    public boolean has(ItemStack stack, CustomEnchantment ench) {
        return getLevel(stack, ench) > 0;
    }

    /** Все кастомные зачарования предмета (id -> уровень). */
    public Map<CustomEnchantment, Integer> getAll(ItemStack stack) {
        Map<CustomEnchantment, Integer> out = new LinkedHashMap<>();
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) return out;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return out;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        for (Map.Entry<CustomEnchantment, NamespacedKey> e : keys.entrySet()) {
            Integer lvl = pdc.get(e.getValue(), PersistentDataType.INTEGER);
            if (lvl != null && lvl > 0) out.put(e.getKey(), Math.min(lvl, e.getKey().maxLevel()));
        }
        return out;
    }

    /** Есть ли на предмете хоть одно кастомное зачарование. */
    public boolean hasAny(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) return false;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return false;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        for (NamespacedKey k : keys.values()) if (pdc.has(k, PersistentDataType.INTEGER)) return true;
        return false;
    }

    // ============== ЗАПИСЬ ==============

    /**
     * Накладывает (level > 0) или снимает (level = 0) зачарование с предмета.
     * Обновляет PDC, lore и блеск зачарования.
     *
     * @return тот же stack (изменённый на месте)
     */
    public ItemStack apply(ItemStack stack, CustomEnchantment ench, int level) {
        if (stack == null || stack.getType().isAir()) return stack;
        NamespacedKey key = keys.get(ench);
        if (key == null) return stack;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;

        List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        // вычищаем старые строки этого зачарования (на любом уровне)
        lore.removeIf(line -> lineBelongsTo(line, ench.displayName()));

        level = ench.clampLevel(level);
        if (level > 0) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, level);
            lore.add(0, ench.loreLine(level, loreStyle));
            try { meta.setEnchantmentGlintOverride(true); } catch (Throwable ignored) {}
        } else {
            meta.getPersistentDataContainer().remove(key);
            if (!hasAnyMeta(meta) && meta.getEnchants().isEmpty()
                    && !(meta instanceof EnchantmentStorageMeta esm && !esm.getStoredEnchants().isEmpty())) {
                try { meta.setEnchantmentGlintOverride(null); } catch (Throwable ignored) {}
            }
        }

        meta.setLore(lore.isEmpty() ? null : lore);
        stack.setItemMeta(meta);
        return stack;
    }

    private boolean hasAnyMeta(ItemMeta meta) {
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        for (NamespacedKey k : keys.values()) if (pdc.has(k, PersistentDataType.INTEGER)) return true;
        return false;
    }

    private static boolean lineBelongsTo(String loreLine, String displayName) {
        if (loreLine == null) return false;
        String plain = ChatColor.stripColor(loreLine);
        return plain != null && plain.startsWith(displayName);
    }

    /** Снимает все кастомные зачарования (для отладки/команд). */
    public void clearAll(ItemStack stack) {
        for (CustomEnchantment e : keys.keySet()) apply(stack, e, 0);
    }
}
