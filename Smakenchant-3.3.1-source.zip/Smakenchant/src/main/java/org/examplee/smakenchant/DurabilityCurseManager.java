package org.examplee.smakenchant;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Проклятие «Сделано в Китае».
 * <p>
 * Каждое использование предмета (в тот момент, когда ванилла собирается снять прочность)
 * дополнительно списывает случайное количество прочности — от {@code min-durability}
 * до {@code max-durability} за уровень.
 * <p>
 * Инструменты/оружие/броня обрабатываются через {@link PlayerItemDamageEvent}.
 * Если ядро не вызывает это событие для брони (такое бывает), плагин сам это замечает
 * и переключается на прямой режим для брони — см. {@code armor-via-item-damage-event}.
 */
public class DurabilityCurseManager implements Listener {

    private final Smakenchant plugin;
    private final CustomEnchantStore store;
    private final CustomEnchantment enchant;
    private final NamespacedKey flagKey;

    private boolean enabled = true;
    private int minDrain = 1;
    private int maxDrain = 10;
    private double chance = 1.0;
    private boolean scaleByLevel = true;
    private boolean affectArmor = true;
    private boolean affectTools = true;
    private Boolean armorViaEvent = null;   // null = определить автоматически
    private boolean respectUnbreaking = true;
    private boolean particles = true;
    private String sound = "entity.item.break";
    private float soundVolume = 0.5f;
    private float soundPitch = 1.6f;

    /** Сработал ли PlayerItemDamageEvent для брони хоть раз (для авто-определения). */
    private boolean armorEventSeen = false;

    public DurabilityCurseManager(Smakenchant plugin, CustomEnchantStore store, CustomEnchantment enchant) {
        this.plugin = plugin;
        this.store = store;
        this.enchant = enchant;
        this.flagKey = new NamespacedKey(plugin, "mic_pending");
    }

    public CustomEnchantment enchant() { return enchant; }

    // =====================================================================
    //  КОНФИГ
    // =====================================================================

    public void loadConfig(ConfigurationSection root) {
        ConfigurationSection s = root == null ? null : root.getConfigurationSection("made-in-china");
        if (s == null) s = new YamlConfiguration();

        enabled = s.getBoolean("enabled", true);
        minDrain = Math.max(0, s.getInt("min-durability", 1));
        maxDrain = Math.max(minDrain, s.getInt("max-durability", 10));
        chance = clamp01(s.getDouble("chance", 1.0));
        scaleByLevel = s.getBoolean("scale-per-level", true);
        affectArmor = s.getBoolean("affect-armor", true);
        affectTools = s.getBoolean("affect-tools", true);
        respectUnbreaking = s.getBoolean("respect-unbreaking", true);
        particles = s.getBoolean("particles", true);
        sound = s.getString("sound", "entity.item.break");
        soundVolume = (float) s.getDouble("sound-volume", 0.5);
        soundPitch = (float) s.getDouble("sound-pitch", 1.6);

        String av = s.getString("armor-via-item-damage-event", "auto");
        armorViaEvent = switch (av.toLowerCase(java.util.Locale.ROOT)) {
            case "true", "yes", "on" -> Boolean.TRUE;
            case "false", "no", "off" -> Boolean.FALSE;
            default -> null;
        };

        enchant.tableChance(
                        clamp01(s.getDouble("table-chance-level-1", 0.05)),
                        clamp01(s.getDouble("table-chance-level-2", 0.02)))
                .tableWeight(s.getInt("weight", 4))
                .anvilCostPerLevel(s.getInt("anvil-cost-per-level", 2));

        plugin.getLogger().info("[Сделано в Китае] enabled=" + enabled + " прочность=" + minDrain + ".." + maxDrain
                + " шанс=" + chance + " броня=" + affectArmor + " инструменты=" + affectTools
                + " armor-via-event=" + (armorViaEvent == null ? "auto" : armorViaEvent));
    }

    private static double clamp01(double d) { return Math.max(0.0, Math.min(1.0, d)); }

    /** Сколько дополнительной прочности снимет проклятие этого уровня. */
    private int rollDrain(int level) {
        if (level <= 0 || minDrain <= 0) return 0;
        int lo = minDrain;
        int hi = scaleByLevel ? maxDrain * level : maxDrain;
        if (hi < lo) hi = lo;
        return ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }

    private boolean shouldSkip(ItemStack item) {
        return respectUnbreaking && unbreakingSaved(item);
    }

    /** Ванильная «Прочность» может полностью отменить потерю — тогда и проклятие молчит. */
    private boolean unbreakingSaved(ItemStack item) {
        try {
            int unb = item.getEnchantmentLevel(Enchantment.UNBREAKING);
            if (unb <= 0) return false;
            double keep = (double) unb / (unb + 1.0); // шанс не потерять прочность
            return ThreadLocalRandom.current().nextDouble() < keep;
        } catch (Throwable t) {
            return false;
        }
    }

    // =====================================================================
    //  ОСНОВНОЙ ПУТЬ: PlayerItemDamageEvent (инструменты, оружие, броня)
    // =====================================================================

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemDamage(PlayerItemDamageEvent e) {
        if (!enabled) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType().isAir()) return;

        boolean armor = SmakenchantUtil.isArmor(item.getType());
        if (armor) {
            armorEventSeen = true;
            clearPending(e.getPlayer());
            if (!affectArmor) return;
        } else {
            if (!affectTools) return;
        }

        int level = store.getLevel(item, enchant);
        if (level <= 0) return;
        if (shouldSkip(item)) return;
        if (chance < 1.0 && ThreadLocalRandom.current().nextDouble() >= chance) return;

        int extra = rollDrain(level);
        if (extra <= 0) return;

        e.setDamage(e.getDamage() + extra);
        feedback(e.getPlayer());
    }

    // =====================================================================
    //  СТРАХОВКА ДЛЯ БРОНИ
    // =====================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent e) {
        if (!enabled || !affectArmor) return;
        if (!(e.getEntity() instanceof Player p)) return;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (e.getFinalDamage() <= 0.0) return;
        if (!hasCursedArmor(p)) return;

        boolean useEvent = armorViaEvent != null ? armorViaEvent : armorEventSeen;
        if (useEvent) {
            // помечаем: если через 2 тика событие так и не пришло — сработает страховка
            markPending(p);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!armorViaEventFalse() && !armorEventSeen) applyArmorCurseDirectly(p);
                clearPending(p);
            }, 2L);
        } else {
            Bukkit.getScheduler().runTaskLater(plugin, () -> applyArmorCurseDirectly(p), 1L);
        }
    }

    private boolean armorViaEventFalse() { return Boolean.FALSE.equals(armorViaEvent); }

    private boolean hasCursedArmor(Player p) {
        for (ItemStack piece : p.getInventory().getArmorContents()) {
            if (piece != null && store.getLevel(piece, enchant) > 0) return true;
        }
        return false;
    }

    private void markPending(Player p) {
        try {
            p.getPersistentDataContainer().set(flagKey, PersistentDataType.LONG, System.nanoTime());
        } catch (Throwable ignored) {}
    }

    private void clearPending(Player p) {
        try {
            if (p.getPersistentDataContainer().has(flagKey, PersistentDataType.LONG))
                p.getPersistentDataContainer().remove(flagKey);
        } catch (Throwable ignored) {}
    }

    private boolean isPending(Player p) {
        try {
            return p.getPersistentDataContainer().has(flagKey, PersistentDataType.LONG);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Прямое списание прочности с брони (если ядро не зовёт PlayerItemDamageEvent). */
    private void applyArmorCurseDirectly(Player p) {
        if (!enabled || !affectArmor || !p.isOnline() || p.isDead()) return;
        if (armorEventSeen && armorViaEvent == null) return; // событие всё-таки работает
        PlayerInventory inv = p.getInventory();
        ItemStack[] armor = inv.getArmorContents();
        boolean changed = false;
        boolean broke = false;

        for (int i = 0; i < armor.length; i++) {
            ItemStack piece = armor[i];
            if (piece == null || piece.getType().isAir()) continue;
            int level = store.getLevel(piece, enchant);
            if (level <= 0) continue;
            if (shouldSkip(piece)) continue;
            if (chance < 1.0 && ThreadLocalRandom.current().nextDouble() >= chance) continue;
            int extra = rollDrain(level);
            if (extra <= 0) continue;

            ItemStack copy = piece.clone();
            if (SmakenchantUtil.applyRawDurabilityLoss(copy, extra)) {
                armor[i] = null;
                broke = true;
                changed = true;
                try {
                    p.getWorld().spawnParticle(Particle.ITEM, p.getLocation().add(0, 1, 0),
                            14, 0.3, 0.4, 0.3, 0.05, copy);
                } catch (Throwable ignored) {}
            } else {
                armor[i] = copy;
                changed = true;
            }
        }

        if (changed) {
            inv.setArmorContents(armor);
            p.updateInventory();
            feedback(p);
            if (broke) {
                SmakenchantUtil.playSound(p.getWorld(), p.getLocation(), sound, soundVolume, soundPitch, Sound.ENTITY_ITEM_BREAK);
            }
        }
    }

    private void feedback(Player p) {
        if (p == null || !particles) return;
        try {
            p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 4, 0.2, 0.2, 0.2, 0.0);
        } catch (Throwable ignored) {}
    }

    public boolean isArmorEventWorking() { return armorEventSeen; }

    public String statusLine() {
        String av = armorViaEvent == null ? ("auto → " + (armorEventSeen ? "event" : "direct"))
                : (armorViaEvent ? "event" : "direct");
        return "enabled=" + enabled + ", прочность=" + minDrain + ".." + maxDrain + ", броня-режим=" + av;
    }

    /** Диагностика: вызывается из /smakenchant debug. */
    public void debug(Player p) {
        p.sendMessage("§7[Китай] pending=" + isPending(p) + ", armorEventSeen=" + armorEventSeen);
    }
}
