package org.examplee.smakenchant;

import org.bukkit.*;import org.bukkit.attribute.*;import org.bukkit.configuration.ConfigurationSection;import org.bukkit.entity.*;import org.bukkit.event.*;import org.bukkit.event.entity.*;import org.bukkit.event.player.PlayerQuitEvent;import org.bukkit.inventory.ItemStack;import org.bukkit.potion.*;import org.bukkit.scheduler.BukkitTask;
import java.util.*;

/** Каменная кожа, Песчаник, Тень, Мягкое приземление, Прыгун и Импульс. */
public final class ArmorEnchantManager implements Listener{
 private final Smakenchant p;private final CustomEnchantStore s;private final CustomEnchantment stone,sand,shadow,soft,jumper,impulse;private BukkitTask task;
 private final NamespacedKey sandKey,jumpKey,impulseKey;private final Map<UUID,Long> impulseUntil=new HashMap<>();
 public ArmorEnchantManager(Smakenchant p,CustomEnchantStore s,CustomEnchantment stone,CustomEnchantment sand,CustomEnchantment shadow,CustomEnchantment soft,CustomEnchantment jumper,CustomEnchantment impulse){this.p=p;this.s=s;this.stone=stone;this.sand=sand;this.shadow=shadow;this.soft=soft;this.jumper=jumper;this.impulse=impulse;sandKey=new NamespacedKey(p,"sand_speed");jumpKey=new NamespacedKey(p,"jump_power");impulseKey=new NamespacedKey(p,"landing_impulse");}
 public void loadConfig(ConfigurationSection r){for(var x:List.of(Map.entry("stone-skin",stone),Map.entry("sandwalker",sand),Map.entry("shadow",shadow),Map.entry("soft-landing",soft),Map.entry("jumper",jumper),Map.entry("impulse",impulse)))cfg(r,x.getKey(),x.getValue());start();}
 private void cfg(ConfigurationSection r,String path,CustomEnchantment e){ConfigurationSection c=r.getConfigurationSection(path);if(c==null)return;e.tableChance(c.getDouble("table-chance-level-1",.04),c.getDouble("table-chance-level-2",.02),c.getDouble("table-chance-level-3",.01)).tableWeight(c.getInt("weight",3)).anvilCostPerLevel(c.getInt("anvil-cost-per-level",3));}
 private void start(){if(task!=null)task.cancel();task=Bukkit.getScheduler().runTaskTimer(p,()->{for(Player x:Bukkit.getOnlinePlayers())sync(x);},1,10);}
 public void stop(){if(task!=null)task.cancel();for(Player x:Bukkit.getOnlinePlayers())clear(x);}
 private int armor(Player p,CustomEnchantment e){int l=0;for(ItemStack x:p.getInventory().getArmorContents())l=Math.max(l,s.getLevel(x,e));return l;}private int boots(Player p,CustomEnchantment e){return s.getLevel(p.getInventory().getBoots(),e);}
 private void sync(Player x){AttributeInstance speed=x.getAttribute(Attribute.MOVEMENT_SPEED),jump=x.getAttribute(Attribute.JUMP_STRENGTH);if(speed!=null){speed.removeModifier(sandKey);speed.removeModifier(impulseKey);}if(jump!=null)jump.removeModifier(jumpKey);
  int sa=boots(x,sand);Material under=x.getLocation().subtract(0,1,0).getBlock().getType();if(sa>0&&(under==Material.SAND||under==Material.RED_SAND||under==Material.SANDSTONE||under==Material.RED_SANDSTONE)&&speed!=null)speed.addTransientModifier(new AttributeModifier(sandKey,.1*sa,AttributeModifier.Operation.ADD_SCALAR));
  int ju=boots(x,jumper);if(ju>0&&jump!=null)jump.addTransientModifier(new AttributeModifier(jumpKey,.1*ju,AttributeModifier.Operation.ADD_SCALAR));
  if(impulseUntil.getOrDefault(x.getUniqueId(),0L)>System.currentTimeMillis()&&speed!=null){int im=boots(x,impulse);if(im>0)speed.addTransientModifier(new AttributeModifier(impulseKey,.1*im,AttributeModifier.Operation.ADD_SCALAR));}
  int sh=armor(x,shadow);if(sh>0&&x.getLocation().getBlock().getLightLevel()<=Math.max(2,8-sh*2))x.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY,15,0,false,false,false));
 }
 @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void onHurt(EntityDamageEvent e){if(!(e.getEntity() instanceof Player x)||e.getCause()==EntityDamageEvent.DamageCause.FALL)return;int l=armor(x,stone);if(l>0){x.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,40+l*20,l-1,false,true,true));x.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,40+l*20,0,false,true,true));}}
 @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void onFall(EntityDamageEvent e){if(!(e.getEntity() instanceof Player x)||e.getCause()!=EntityDamageEvent.DamageCause.FALL)return;int l=boots(x,soft);if(l>0){e.setDamage(e.getDamage()*(1-l*.25));for(Entity n:x.getNearbyEntities(2+l,2,2+l))if(n instanceof LivingEntity le&&!le.equals(x))le.setVelocity(le.getLocation().toVector().subtract(x.getLocation().toVector()).normalize().multiply(.25*l).setY(.2));}int im=boots(x,impulse);if(im>0)impulseUntil.put(x.getUniqueId(),System.currentTimeMillis()+1000L*(1+im));}
 private void clear(Player x){for(var a:List.of(x.getAttribute(Attribute.MOVEMENT_SPEED),x.getAttribute(Attribute.JUMP_STRENGTH)))if(a!=null){a.removeModifier(sandKey);a.removeModifier(jumpKey);a.removeModifier(impulseKey);}}
 @EventHandler public void quit(PlayerQuitEvent e){impulseUntil.remove(e.getPlayer().getUniqueId());clear(e.getPlayer());}
}
