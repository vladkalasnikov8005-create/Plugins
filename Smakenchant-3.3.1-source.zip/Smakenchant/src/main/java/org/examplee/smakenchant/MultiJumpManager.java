package org.examplee.smakenchant;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Многоуровневый прыжок (двойной / тройной).
 *
 * <h2>Что починено</h2>
 * <ol>
 *   <li><b>«Даёт полёт навсегда».</b> Раньше {@code allowFlight} включался в воздухе, а
 *       выключался только если игрок после этого ещё раз пошевелится. Смерть/респаун, смена
 *       игрового режима, выход из игры в воздухе, {@code /smakenchant reload} с
 *       {@code enabled: false} — всё это оставляло флаг включённым навсегда.
 *       Теперь:
 *       <ul>
 *         <li>режим {@code velocity} (по умолчанию) вообще не трогает {@code allowFlight};</li>
 *         <li>в режиме {@code flight-toggle} флаг считается чистой функцией
 *             «ботинки надеты + остались прыжки + игрок в воздухе»;</li>
 *         <li>раз в {@code safety-reset-period} тиков проходит страховочная проверка и
 *             принудительно снимает {@code allowFlight} со всех, кому он не положен;</li>
 *         <li>сброс на join / respawn / death / teleport / смена мира / смена режима /
 *             quit / reload / onDisable.</li>
 *       </ul></li>
 *   <li><b>«Замедляет по X на втором прыжке».</b> Причина — включённый {@code allowFlight}
 *       переводит клиента в физику полёта: другое горизонтальное трение, другой разгон,
 *       сбрасывается спринт. В режиме {@code velocity} {@code allowFlight} не включается,
 *       поэтому обычная физика бега сохраняется полностью. Плюс горизонтальная составляющая
 *       скорости теперь явно сохраняется ({@code preserve-horizontal-speed}), а в
 *       flight-toggle режиме {@code allowFlight} выключается сразу в момент прыжка.</li>
 *   <li><b>Ложные срабатывания</b> (вода, лестницы, отдача, поршни, «сам прыгнул дважды»):
 *       анти-дребезг {@code jump-cooldown-ticks} + {@code jump-grace-ticks} + порог импульса
 *       {@code jump-velocity-threshold} + проверки на воду/лазабельные блоки/транспорт/полёт.</li>
 * </ol>
 */
public class MultiJumpManager implements Listener {

    public enum Mode {
        /** Paper PlayerInputEvent: видим нажатие И отпускание пробела, без allowFlight. */
        INPUT,
        /** Экспериментальный детект вертикального импульса. */
        VELOCITY,
        /** Старый запасной способ через allowFlight. */
        FLIGHT_TOGGLE
    }

    private final Smakenchant plugin;
    private final CustomEnchantStore store;
    private final CustomEnchantment enchant;

    // ---- конфиг ----
    private boolean enabled = true;
    private Mode mode = Mode.INPUT;
    private double jumpPower = 0.5;
    private double forwardBoost = 0.0;
    private boolean preserveHorizontal = true;
    private boolean allowWhileSprinting = true;
    private boolean grantOnFall = true;
    private double jumpVelocityThreshold = 0.28;
    private int jumpCooldownTicks = 3;
    private int graceTicks = 4;
    private boolean disableWithElytra = true;
    private int safetyResetPeriod = 20;
    private String soundName = "entity.breeze.jump";
    private float soundVolume = 0.6f;
    private float soundPitch = 1.4f;
    private Particle particle = Particle.CLOUD;
    private int particleCount = 10;
    private double[] fallReduction = {0.0, 0.4, 0.7};
    private double[] tableChances = {0.08, 0.03};
    private final Set<String> disabledWorlds = new HashSet<>();

    // ---- состояние ----
    private final Map<UUID, Integer> airJumpsLeft = new HashMap<>();
    /** Сколько ДОПОЛНИТЕЛЬНЫХ прыжков уже потрачено после последнего прыжка с земли. */
    private final Map<UUID, Integer> airJumpsUsed = new HashMap<>();
    /** Тик первого (обычного) прыжка — защищает от ложного повторного «приземления» в первые тики. */
    private final Map<UUID, Long> groundJumpTick = new HashMap<>();
    private final Map<UUID, Integer> airTicks = new HashMap<>();
    private final Map<UUID, Long> lastAirJumpTick = new HashMap<>();
    /** Последняя нормальная X/Z скорость до нажатия второго пробела. */
    private final Map<UUID, Vector> lastHorizontalVelocity = new HashMap<>();
    private final Set<UUID> jumpGuard = new HashSet<>();
    /** Текущее состояние кнопки: новый прыжок только по фронту false -> true. */
    private final Set<UUID> jumpHeld = new HashSet<>();
    private final Set<UUID> pendingGroundJump = new HashSet<>();
    private BukkitTask safetyTask;
    private long tickCounter = 0;

    public MultiJumpManager(Smakenchant plugin, CustomEnchantStore store, CustomEnchantment enchant) {
        this.plugin = plugin;
        this.store = store;
        this.enchant = enchant;
    }

    public CustomEnchantment enchant() { return enchant; }

    public int maxLevel() { return enchant.maxLevel(); }

    public boolean isEnabled() { return enabled; }

    public Mode mode() { return mode; }

    // =====================================================================
    //  КОНФИГ
    // =====================================================================

    public void loadConfig(ConfigurationSection root) {
        ConfigurationSection s = root == null ? null : root.getConfigurationSection("multi-jump");
        if (s == null) s = new YamlConfiguration();

        enabled = s.getBoolean("enabled", true);
        String m = s.getString("mode", "input");
        mode = switch (m.toLowerCase(Locale.ROOT)) {
            case "flight-toggle", "flight", "toggle" -> Mode.FLIGHT_TOGGLE;
            case "velocity" -> Mode.VELOCITY;
            default -> Mode.INPUT;
        };

        jumpPower = s.getDouble("jump-power", 0.5);
        forwardBoost = s.getDouble("forward-boost", 0.0);
        preserveHorizontal = s.getBoolean("preserve-horizontal-speed", true);
        allowWhileSprinting = s.getBoolean("allow-while-sprinting", true);
        grantOnFall = s.getBoolean("grant-jumps-when-falling-off", true);
        jumpVelocityThreshold = s.getDouble("jump-velocity-threshold", 0.28);
        jumpCooldownTicks = Math.max(1, s.getInt("jump-cooldown-ticks", 3));
        graceTicks = Math.max(1, s.getInt("jump-grace-ticks", 4));
        disableWithElytra = s.getBoolean("disable-when-wearing-elytra", true);
        safetyResetPeriod = Math.max(5, s.getInt("safety-reset-period", 20));
        soundName = s.getString("sound", "entity.breeze.jump");
        soundVolume = (float) s.getDouble("sound-volume", 0.6);
        soundPitch = (float) s.getDouble("sound-pitch", 1.4);
        particleCount = Math.max(0, s.getInt("particle-count", 10));
        particle = parseParticle(s.getString("particle", "CLOUD"));

        // шансы на столе зачарований
        List<?> ch = s.getList("table-chance", null);
        if (ch != null && !ch.isEmpty()) {
            int n = Math.min(ch.size(), enchant.maxLevel());
            tableChances = new double[n];
            for (int i = 0; i < n; i++) tableChances[i] = toDouble(ch.get(i), 0.0);
        } else {
            // обратная совместимость со старым конфигом (chance-level-1 / chance-level-2)
            tableChances = new double[]{
                    s.getDouble("chance-level-1", 0.08),
                    s.getDouble("chance-level-2", 0.03)
            };
        }
        enchant.tableChance(tableChances)
                .tableWeight(s.getInt("weight", 4))
                .anvilCostPerLevel(s.getInt("anvil-cost-per-level", 3));

        // снижение урона от падения по уровням
        List<?> fr = s.getList("fall-damage-reduction", null);
        if (fr != null && !fr.isEmpty()) {
            fallReduction = new double[fr.size() + 1];
            for (int i = 0; i < fr.size(); i++) fallReduction[i + 1] = toDouble(fr.get(i), 0.0);
        } else {
            fallReduction = new double[]{0.0, 0.4, 0.7};
        }

        disabledWorlds.clear();
        for (String w : s.getStringList("disabled-worlds")) disabledWorlds.add(w.toLowerCase(Locale.ROOT));

        resyncAll();
        plugin.getLogger().info("[MultiJump] mode=" + mode + " enabled=" + enabled
                + " power=" + jumpPower + " threshold=" + jumpVelocityThreshold
                + " cooldown=" + jumpCooldownTicks + "t safetyReset=" + safetyResetPeriod + "t");
    }

    private static Particle parseParticle(String name) {
        if (name != null) {
            try { return Particle.valueOf(name.trim().toUpperCase(Locale.ROOT)); } catch (Throwable ignored) {}
        }
        return Particle.CLOUD;
    }

    private static double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        try { return Double.parseDouble(String.valueOf(o)); } catch (Throwable t) { return def; }
    }

    public void startTasks() {
        stopTasks();
        safetyTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            tickCounter++;
            if (tickCounter % safetyResetPeriod == 0) safetySweep();
        }, 1L, 1L);
    }

    public void stopTasks() {
        if (safetyTask != null) { safetyTask.cancel(); safetyTask = null; }
    }

    // =====================================================================
    //  УРОВЕНЬ / ПРАВО НА ПРЫЖОК
    // =====================================================================

    public int getLevel(Player p) {
        return p == null ? 0 : getLevel(p.getInventory().getBoots());
    }

    public int getLevel(ItemStack boots) {
        if (boots == null || !SmakenchantUtil.BOOTS.contains(boots.getType())) return 0;
        return store.getLevel(boots, enchant);
    }

    /** Есть ли у игрока право на мульти-прыжок прямо сейчас. */
    public boolean isActive(Player p) {
        if (!enabled || p == null || !p.isOnline()) return false;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;
        if (p.isDead()) return false;
        if (disabledWorlds.contains(p.getWorld().getName().toLowerCase(Locale.ROOT))) return false;
        if (p.isGliding()) return false;
        if (p.isInsideVehicle()) return false;
        if (disableWithElytra) {
            ItemStack chest = p.getInventory().getChestplate();
            if (chest != null && chest.getType() == Material.ELYTRA) return false;
        }
        return getLevel(p) > 0;
    }

    // =====================================================================
    //  СОСТОЯНИЕ / СБРОСЫ
    // =====================================================================

    public void clearState(UUID id) {
        airJumpsLeft.remove(id);
        airJumpsUsed.remove(id);
        groundJumpTick.remove(id);
        airTicks.remove(id);
        lastAirJumpTick.remove(id);
        lastHorizontalVelocity.remove(id);
        jumpGuard.remove(id);
        jumpHeld.remove(id);
        pendingGroundJump.remove(id);
    }

    public void reset(Player p) {
        if (p == null) return;
        clearState(p.getUniqueId());
        safeAllowFlight(p, false);
    }

    private void safeAllowFlight(Player p, boolean value) {
        try {
            GameMode gm = p.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return; // там свой режим
            if (p.getAllowFlight() != value) {
                p.setAllowFlight(value);
                if (!value && p.isFlying()) p.setFlying(false);
            }
        } catch (Throwable ignored) {}
    }

    /**
     * ЕДИНСТВЕННАЯ точка, решающая, должен ли игрок иметь {@code allowFlight}.
     * Чистая функция от состояния — никаких «залипаний».
     */
    private boolean shouldAllowFlight(Player p) {
        if (mode != Mode.FLIGHT_TOGGLE) return false; // velocity-режим полёт не использует
        if (!enabled) return false;
        if (p == null || !p.isOnline() || p.isDead()) return false;
        if (!isActive(p)) return false;
        if (p.isOnGround()) return false;
        return airJumpsLeft.getOrDefault(p.getUniqueId(), 0) > 0;
    }

    private void syncFlight(Player p) {
        boolean want = shouldAllowFlight(p);
        if (p.getAllowFlight() != want) safeAllowFlight(p, want);
    }

    /** Страховочная проверка: снимаем allowFlight со всех, кому он не положен. */
    private void safetySweep() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            GameMode gm = p.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) continue;
            if (!p.getAllowFlight()) continue;
            if (!shouldAllowFlight(p)) safeAllowFlight(p, false);
        }
    }

    /** Полный пересчёт (после reload / отключения). */
    public void resyncAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!enabled || !isActive(p)) {
                clearState(p.getUniqueId());
                safeAllowFlight(p, false);
            } else {
                syncFlight(p);
            }
        }
    }

    /** Сброс при заходе/перезагрузке плагина. */
    public void onPlayerReady(Player p) {
        clearState(p.getUniqueId());
        airTicks.put(p.getUniqueId(), p.isOnGround() ? 0 : 1);
        safeAllowFlight(p, false);
    }

    // =====================================================================
    //  СОБЫТИЯ ЖИЗНЕННОГО ЦИКЛА
    // =====================================================================

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        // ВАЖНО: снять полёт ДО сохранения playerdata, иначе «полёт навсегда» переедет в файл игрока
        if (p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) safeAllowFlight(p, false);
        clearState(p.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        clearState(p.getUniqueId());
        safeAllowFlight(p, false);
        // локация респаун применяется после события — перестрахуемся на следующий тик
        Bukkit.getScheduler().runTask(plugin, () -> { safeAllowFlight(p, false); airTicks.put(p.getUniqueId(), 0); });
        Bukkit.getScheduler().runTaskLater(plugin, () -> safeAllowFlight(p, false), 2L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        clearState(p.getUniqueId());
        safeAllowFlight(p, false);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onGameMode(PlayerGameModeChangeEvent e) {
        Player p = e.getPlayer();
        clearState(p.getUniqueId());
        Bukkit.getScheduler().runTask(plugin, () -> safeAllowFlight(p, false));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        clearState(p.getUniqueId());
        airTicks.put(p.getUniqueId(), 0);
        Bukkit.getScheduler().runTask(plugin, () -> { safeAllowFlight(p, false); syncFlight(p); });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        clearState(p.getUniqueId());
        Bukkit.getScheduler().runTask(plugin, () -> { safeAllowFlight(p, false); syncFlight(p); });
    }

    // =====================================================================
    //  ПРЫЖОК С ЗЕМЛИ (Paper PlayerJumpEvent)
    // =====================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGroundJump(com.destroystokyo.paper.event.player.PlayerJumpEvent e) {
        if (!enabled) return;
        Player p = e.getPlayer();
        if (!isActive(p)) return;
        UUID id = p.getUniqueId();
        // Первый пробел — ОБЫЧНЫЙ ванильный прыжок. Здесь мы только открываем новый
        // цикл и выдаём ровно level дополнительных нажатий в воздухе:
        // I = один дополнительный (итого 2), II = два дополнительных (итого 3).
        airJumpsLeft.put(id, getLevel(p));
        airJumpsUsed.put(id, 0);
        groundJumpTick.put(id, tickCounter);
        airTicks.put(id, 0);
        pendingGroundJump.add(id); // чтобы onMove не выдал прыжки второй раз
        syncFlight(p);
    }

    // =====================================================================
    //  ДВИЖЕНИЕ: учёт воздуха + (в режиме velocity) детект самого прыжка
    // =====================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!enabled) return;
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (p.isDead()) return;

        UUID id = p.getUniqueId();
        Location to = e.getTo();
        if (to == null) return;

        // === НА ЗЕМЛЕ ===
        if (p.isOnGround()) {
            // Paper/клиент иногда ещё 1–2 тика считает игрока стоящим на земле уже
            // после PlayerJumpEvent. Не сбрасываем в это окно новый цикл прыжков.
            long sinceGroundJump = tickCounter - groundJumpTick.getOrDefault(id, Long.MIN_VALUE / 2);
            if (sinceGroundJump <= 3 && pendingGroundJump.contains(id)) return;
            airTicks.put(id, 0);
            airJumpsLeft.remove(id);
            airJumpsUsed.remove(id);
            groundJumpTick.remove(id);
            jumpGuard.remove(id);
            pendingGroundJump.remove(id);
            if (p.getAllowFlight()) safeAllowFlight(p, false);
            return;
        }

        // === В ВОЗДУХЕ ===
        if (!isActive(p)) {
            // сняли ботинки / надели элитру / выключили плагин / другой мир — чистим за собой
            clearState(id);
            airTicks.put(id, 0);
            if (p.getAllowFlight()) safeAllowFlight(p, false);
            return;
        }

        int air = airTicks.getOrDefault(id, 0) + 1;
        airTicks.put(id, air);
        // Запоминаем X/Z ДО второго пробела. После PlayerToggleFlightEvent клиент
        // иногда уже отдаёт урезанную скорость, поэтому одного p.getVelocity() там мало.
        if (!jumpGuard.contains(id) && !p.isFlying()) {
            Vector now = p.getVelocity();
            lastHorizontalVelocity.put(id, new Vector(now.getX(), 0.0, now.getZ()));
        }

        if (air == 1) {
            // только что оторвались от земли
            boolean jumped = pendingGroundJump.remove(id);
            int grant = getLevel(p);
            if (!jumped && !grantOnFall) grant = 0; // упал с обрыва — прыжки не выдаём
            // Инициализируем только один раз за воздушный цикл. Это исключает баг,
            // когда краткий isOnGround повторно выдавал полный набор прыжков.
            airJumpsLeft.putIfAbsent(id, grant);
            airJumpsUsed.putIfAbsent(id, 0);
            syncFlight(p);
            return;
        }

        int left = airJumpsLeft.getOrDefault(id, 0);
        if (left <= 0) {
            syncFlight(p);
            return;
        }

        if (mode == Mode.VELOCITY) {
            if (riseOf(e, p) >= jumpVelocityThreshold && canAirJumpNow(p, id)) {
                performAirJump(p, left);
            }
        } else {
            syncFlight(p); // держим allowFlight, пока остались прыжки
        }
    }

    /** Вертикальный прирост за событие: максимум из дельты позиции и текущей скорости. */
    private double riseOf(PlayerMoveEvent e, Player p) {
        double dy = e.getTo().getY() - e.getFrom().getY();
        double vy = 0.0;
        try {
            Vector v = p.getVelocity();
            if (v != null) vy = v.getY();
        } catch (Throwable ignored) {}
        return Math.max(dy, vy);
    }

    /** Анти-дребезг + защита от «прыжка» в воде, на лестнице, в транспорте и т.п. */
    private boolean canAirJumpNow(Player p, UUID id) {
        if (jumpGuard.contains(id)) return false;
        if (pendingGroundJump.contains(id)) return false; // это ещё прыжок с земли
        Long last = lastAirJumpTick.get(id);
        if (last != null && (tickCounter - last) < jumpCooldownTicks) return false;
        if (p.isFlying() || p.isGliding() || p.isInsideVehicle() || p.isSwimming() || p.isDead()) return false;
        if (!allowWhileSprinting && p.isSprinting()) return false;

        Location loc = p.getLocation();
        Material at = loc.getBlock().getType();
        Material below = loc.clone().subtract(0, 1, 0).getBlock().getType();
        if (isFluid(at) || isFluid(below)) return false;
        if (isClimbable(at) || isClimbable(below)) return false;
        return true;
    }

    private static boolean isFluid(Material m) {
        return m == Material.WATER || m == Material.LAVA || m == Material.BUBBLE_COLUMN;
    }

    private static boolean isClimbable(Material m) {
        String n = m.name();
        return n.equals("LADDER") || n.equals("VINE") || n.equals("SCAFFOLDING")
                || n.equals("WEEPING_VINES") || n.equals("TWISTING_VINES")
                || n.endsWith("_VINE") || n.endsWith("_VINES");
    }

    // =====================================================================
    //  INPUT: точное нажатие/отпускание пробела (основной способ Paper 26.2)
    // =====================================================================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInput(org.bukkit.event.player.PlayerInputEvent e) {
        if (!enabled || mode != Mode.INPUT) return;
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        boolean pressed = e.getInput().isJump();
        if (!pressed) {
            jumpHeld.remove(id); // пробел отпущен — разрешаем следующее отдельное нажатие
            return;
        }
        if (!jumpHeld.add(id)) return; // кнопка всё ещё удерживается: НИ ОДНОГО нового прыжка
        if (p.isOnGround() || !isActive(p)) return; // первый пробел остаётся ванильным
        int used = airJumpsUsed.getOrDefault(id, 0);
        int limit = getLevel(p);
        int left = airJumpsLeft.getOrDefault(id, limit - used);
        if (used >= limit || left <= 0 || !canAirJumpNow(p, id)) return;
        performAirJump(p, left, p.getVelocity().clone(), e.getInput().isSprint() || p.isSprinting());
    }

    // =====================================================================
    //  FLIGHT-TOGGLE (старый запасной способ)
    // =====================================================================

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        if (!enabled || mode != Mode.FLIGHT_TOGGLE) return;
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (!e.isFlying()) return;   // игрок ВЫКЛЮЧАЕТ полёт — не наше
        if (p.isOnGround()) return;  // на земле это не прыжок
        if (!isActive(p)) return;    // нет ботинок — пусть решает другой плагин

        e.setCancelled(true);        // в реальный полёт не переходим НИКОГДА

        UUID id = p.getUniqueId();
        int left = airJumpsLeft.getOrDefault(id, 0);
        int used = airJumpsUsed.getOrDefault(id, 0);
        int hardLimit = getLevel(p);
        if (left <= 0 || used >= hardLimit || !canAirJumpNow(p, id)) {
            safeAllowFlight(p, false); // прыжков нет — сразу убираем флаг
            return;
        }
        // Сохраняем скорость ДО отмены полёта. Клиент успевает на короткий момент
        // применить трение полёта, поэтому после события горизонталь нужно вернуть.
        Vector live = p.getVelocity().clone();
        Vector remembered = lastHorizontalVelocity.get(id);
        Vector beforeFlight = live;
        if (remembered != null) {
            // Берём более быструю из двух горизонталей: live уже может быть замедлена
            // кратким клиентским переходом в flight physics.
            double rememberedSq = remembered.getX()*remembered.getX()+remembered.getZ()*remembered.getZ();
            double liveSq = live.getX()*live.getX()+live.getZ()*live.getZ();
            if (rememberedSq > liveSq) beforeFlight = new Vector(remembered.getX(), live.getY(), remembered.getZ());
        }
        boolean wasSprinting = p.isSprinting();
        performAirJump(p, left, beforeFlight, wasSprinting);
    }

    // =====================================================================
    //  САМ ПРЫЖОК В ВОЗДУХЕ
    // =====================================================================

    private void performAirJump(Player p, int left) {
        performAirJump(p, left, p.getVelocity().clone(), p.isSprinting());
    }

    private void performAirJump(Player p, int left, Vector horizontalBeforeFlight, boolean wasSprinting) {
        UUID id = p.getUniqueId();

        int used = airJumpsUsed.getOrDefault(id, 0);
        int hardLimit = getLevel(p);
        if (used >= hardLimit || left <= 0) {
            airJumpsLeft.put(id, 0);
            safeAllowFlight(p, false);
            return;
        }
        jumpGuard.add(id);
        lastAirJumpTick.put(id, tickCounter);
        airJumpsUsed.put(id, used + 1);
        airJumpsLeft.put(id, Math.max(0, hardLimit - (used + 1)));

        // --- импульс: вертикаль задаём, горизонталь СОХРАНЯЕМ ---
        Vector vel = p.getVelocity();
        if (vel == null) vel = new Vector();
        if (preserveHorizontal && horizontalBeforeFlight != null) {
            // Берём X/Z именно ДО PlayerToggleFlightEvent: так краткий переход клиента
            // в flight physics не успевает обрезать скорость бега.
            vel.setX(horizontalBeforeFlight.getX());
            vel.setZ(horizontalBeforeFlight.getZ());
        } else if (!preserveHorizontal) {
            vel.setX(0);
            vel.setZ(0);
        }
        vel.setY(jumpPower);
        if (forwardBoost > 0.001) {
            Vector dir = p.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() > 1.0E-4) vel.add(dir.normalize().multiply(forwardBoost));
        }
        p.setVelocity(vel);

        // --- сброс «полётного» состояния ---
        // Именно это убирает торможение по X: allowFlight выключается СРАЗУ,
        // клиент возвращается к обычной физике прыжка вместо физики полёта.
        safeAllowFlight(p, false);
        try { p.resetFlyingTicks(); } catch (Throwable ignored) {}
        if (wasSprinting && !p.isSprinting()) p.setSprinting(true);

        // На следующем серверном тике клиент иногда присылает уже приторможенную X/Z.
        // Возвращаем исходную горизонтальную скорость, но только если она действительно
        // стала меньше; Y оставляем текущим, чтобы не создавать второй импульс вверх.
        if (preserveHorizontal && horizontalBeforeFlight != null) {
            final double oldX = horizontalBeforeFlight.getX();
            final double oldZ = horizontalBeforeFlight.getZ();
            final double oldHorizontalSq = oldX * oldX + oldZ * oldZ;
            // Клиент может прислать торможение не только в следующий, но и через 2 тика.
            // Три короткие проверки не дают ему «съесть» скорость бега.
            for (long delay = 1; delay <= 3; delay++) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!p.isOnline() || p.isDead() || p.isOnGround()) return;
                    Vector current = p.getVelocity();
                    double currentSq = current.getX() * current.getX() + current.getZ() * current.getZ();
                    if (currentSq + 1.0E-4 < oldHorizontalSq) {
                        current.setX(oldX);
                        current.setZ(oldZ);
                        p.setVelocity(current);
                    }
                    if (wasSprinting && !p.isSprinting()) p.setSprinting(true);
                }, delay);
            }
        }

        // --- звук и частицы ---
        World w = p.getWorld();
        Location loc = p.getLocation();
        SmakenchantUtil.playSound(w, loc, soundName, soundVolume, soundPitch, Sound.ENTITY_BREEZE_JUMP);
        if (particleCount > 0) {
            try {
                w.spawnParticle(particle, loc.clone().add(0, 0.2, 0), particleCount, 0.25, 0.15, 0.25, 0.03);
            } catch (Throwable ignored) {}
        }

        // --- разблокировка следующего прыжка ---
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            jumpGuard.remove(id);
            if (p == null || !p.isOnline()) { clearState(id); return; }
            if (p.isOnGround() || !isActive(p)) {
                clearState(id);
                safeAllowFlight(p, false);
                return;
            }
            syncFlight(p); // в flight-toggle возвращаем возможность нажать пробел снова
        }, graceTicks);
    }

    // =====================================================================
    //  УРОН ОТ ПАДЕНИЯ
    // =====================================================================

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        int lvl = getLevel(p);
        if (lvl <= 0) return;
        double reduce = lvl < fallReduction.length ? fallReduction[lvl] : 0.0;
        if (reduce <= 0.0) return;
        e.setDamage(Math.max(0.0, e.getDamage() * (1.0 - reduce)));
    }

    // =====================================================================
    //  СЛУЖЕБНОЕ
    // =====================================================================

    public NamespacedKey pdcKey() {
        return new NamespacedKey(plugin, enchant.id());
    }

    public List<String> debugInfo(Player p) {
        List<String> out = new ArrayList<>();
        UUID id = p.getUniqueId();
        out.add("mode=" + mode + ", enabled=" + enabled);
        out.add("level=" + getLevel(p) + ", active=" + isActive(p));
        out.add("airJumpsLeft=" + airJumpsLeft.getOrDefault(id, -1) + ", used="
                + airJumpsUsed.getOrDefault(id, -1) + "/" + getLevel(p) + ", airTicks=" + airTicks.getOrDefault(id, -1));
        out.add("allowFlight=" + p.getAllowFlight() + ", flying=" + p.isFlying() + ", shouldAllow=" + shouldAllowFlight(p));
        out.add("guard=" + jumpGuard.contains(id) + ", lastJumpTick=" + lastAirJumpTick.get(id));
        return out;
    }
}
