package org.examplee.smakenchant;

import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Все выбранные зачарования лука/арбалета. */
public final class ProjectileEnchantManager implements Listener {
    private final Smakenchant plugin; private final CustomEnchantStore store;
    private final CustomEnchantment shard,chain,eagle,returning,mark,heavy;
    private final Map<String,NamespacedKey> keys=new HashMap<>();
    private final NamespacedKey originX,originY,originZ;
    private final Map<UUID,Marked> marks=new HashMap<>(); private final Set<UUID> guard=new HashSet<>();
    private record Marked(UUID owner,int level,long until){}
    private int[] eaglePct={10,20,30}, returnPct={25,50,75}, heavySlow={15,25,35};
    /** Бонус урона Тяжёлого болта за каждый пройденный блок, максимум 30 блоков. */
    private double[] heavyDamagePerBlock={.01,.015,.02};
    private double[] shardRadius={2,3,4}, shardPct={.25,.35,.50}; private int[] chainTargets={1,2,3}, markBonus={10,20,30};

    public ProjectileEnchantManager(Smakenchant p,CustomEnchantStore s,CustomEnchantment shard,CustomEnchantment chain,CustomEnchantment eagle,CustomEnchantment returning,CustomEnchantment mark,CustomEnchantment heavy){
        plugin=p;store=s;this.shard=shard;this.chain=chain;this.eagle=eagle;this.returning=returning;this.mark=mark;this.heavy=heavy;
        for(CustomEnchantment e:List.of(shard,chain,eagle,returning,mark,heavy))keys.put(e.id(),new NamespacedKey(p,"shot_"+e.id()));
        originX=new NamespacedKey(p,"shot_origin_x");originY=new NamespacedKey(p,"shot_origin_y");originZ=new NamespacedKey(p,"shot_origin_z");
    }
    public void loadConfig(ConfigurationSection root){
        configure(root,"shard-arrow",shard);configure(root,"chain-lightning",chain);configure(root,"eagle-eye",eagle);configure(root,"returning",returning);configure(root,"hunter-mark",mark);configure(root,"heavy-bolt",heavy);
    }
    private void configure(ConfigurationSection r,String path,CustomEnchantment e){ConfigurationSection s=r.getConfigurationSection(path);if(s==null)return;e.tableChance(s.getDouble("table-chance-level-1",.04),s.getDouble("table-chance-level-2",.02),s.getDouble("table-chance-level-3",.01)).tableWeight(s.getInt("weight",3)).anvilCostPerLevel(s.getInt("anvil-cost-per-level",4));}

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void onLaunch(ProjectileLaunchEvent e){
        Projectile pr=e.getEntity(); ProjectileSource source=pr.getShooter(); if(!(source instanceof Player p))return;
        ItemStack weapon=p.getInventory().getItemInMainHand(); if(weapon==null||!(weapon.getType()==Material.BOW||weapon.getType()==Material.CROSSBOW))return;
        for(CustomEnchantment ce:List.of(shard,chain,eagle,returning,mark,heavy)){int l=store.getLevel(weapon,ce);if(l>0)pr.getPersistentDataContainer().set(keys.get(ce.id()),PersistentDataType.INTEGER,l);}
        Location start=pr.getLocation();pr.getPersistentDataContainer().set(originX,PersistentDataType.DOUBLE,start.getX());pr.getPersistentDataContainer().set(originY,PersistentDataType.DOUBLE,start.getY());pr.getPersistentDataContainer().set(originZ,PersistentDataType.DOUBLE,start.getZ());
        int eg=level(pr,eagle), hv=level(pr,heavy);Vector v=pr.getVelocity();double mul=1.0+(eg>0?at(eaglePct,eg)/100.0:0)-(hv>0?at(heavySlow,hv)/100.0:0);pr.setVelocity(v.multiply(Math.max(.2,mul)));
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void onHit(ProjectileHitEvent e){
        Projectile pr=e.getEntity();int ret=level(pr,returning);if(ret<=0)return;if(!(pr.getShooter() instanceof Player p))return;
        if(ThreadLocalRandom.current().nextInt(100)>=at(returnPct,ret))return;
        Bukkit.getScheduler().runTask(plugin,()->{if(!pr.isValid())return;ItemStack arrow=new ItemStack(pr instanceof SpectralArrow?Material.SPECTRAL_ARROW:Material.ARROW);p.getInventory().addItem(arrow).values().forEach(x->p.getWorld().dropItemNaturally(p.getLocation(),x));pr.remove();p.playSound(p.getLocation(),Sound.ENTITY_ITEM_PICKUP,.5f,1.5f);});
    }
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true) public void onDamage(EntityDamageByEntityEvent e){
        if(!(e.getEntity() instanceof LivingEntity victim))return;
        // Охотничья метка усиливает следующий удар владельца.
        Marked mk=marks.get(victim.getUniqueId());
        UUID attacker=null;
        if(e.getDamager() instanceof Player ap)attacker=ap.getUniqueId();
        else if(e.getDamager() instanceof Projectile shot&&shot.getShooter() instanceof Player ap)attacker=ap.getUniqueId();
        if(mk!=null&&(System.currentTimeMillis()>mk.until||attacker==null||!attacker.equals(mk.owner))) {if(System.currentTimeMillis()>mk.until)marks.remove(victim.getUniqueId());}
        else if(mk!=null){e.setDamage(e.getDamage()*(1+at(markBonus,mk.level)/100.0));marks.remove(victim.getUniqueId());victim.getWorld().spawnParticle(Particle.CRIT,victim.getLocation().add(0,1,0),10,.3,.4,.3,.1);}
        if(!(e.getDamager() instanceof Projectile pr)||guard.contains(victim.getUniqueId()))return;if(!(pr.getShooter() instanceof Player owner))return;
        int hv=level(pr,heavy);
        if(hv>0){Double x=pr.getPersistentDataContainer().get(originX,PersistentDataType.DOUBLE),y=pr.getPersistentDataContainer().get(originY,PersistentDataType.DOUBLE),z=pr.getPersistentDataContainer().get(originZ,PersistentDataType.DOUBLE);if(x!=null&&y!=null&&z!=null){double distance=Math.min(30.0,pr.getLocation().distance(new Location(pr.getWorld(),x,y,z)));e.setDamage(e.getDamage()*(1.0+distance*at(heavyDamagePerBlock,hv)));}}
        double base=e.getFinalDamage();int sh=level(pr,shard),ch=level(pr,chain),ma=level(pr,mark);
        if(ma>0)marks.put(victim.getUniqueId(),new Marked(owner.getUniqueId(),ma,System.currentTimeMillis()+5000));
        Bukkit.getScheduler().runTask(plugin,()->{
            if(sh>0)for(Entity near:victim.getNearbyEntities(at(shardRadius,sh),at(shardRadius,sh),at(shardRadius,sh)))if(near instanceof LivingEntity le&&!le.equals(owner)&&!le.equals(victim))deal(le,owner,base*at(shardPct,sh));
            if(ch>0){List<LivingEntity> list=new ArrayList<>();for(Entity near:victim.getNearbyEntities(6,6,6))if(near instanceof LivingEntity le&&!le.equals(owner)&&!le.equals(victim))list.add(le);list.sort(Comparator.comparingDouble(x->x.getLocation().distanceSquared(victim.getLocation())));Location from=victim.getLocation().add(0,1,0);for(int i=0;i<Math.min(at(chainTargets,ch),list.size());i++){LivingEntity le=list.get(i);drawLightning(from,le.getLocation().add(0,1,0));deal(le,owner,base*.50);from=le.getLocation().add(0,1,0);}}
        });
    }
    private void deal(LivingEntity v,Player owner,double damage){guard.add(v.getUniqueId());try{v.damage(damage,owner);}finally{Bukkit.getScheduler().runTask(plugin,()->guard.remove(v.getUniqueId()));}}
    private void drawLightning(Location a,Location b){Vector d=b.toVector().subtract(a.toVector());for(int i=0;i<=12;i++){Location x=a.clone().add(d.clone().multiply(i/12.0));x.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,x,2,.05,.05,.05,0);}}
    private int level(Projectile p,CustomEnchantment e){Integer v=p.getPersistentDataContainer().get(keys.get(e.id()),PersistentDataType.INTEGER);return v==null?0:v;}
    private static int at(int[]a,int l){return a[Math.min(l,a.length)-1];}private static double at(double[]a,int l){return a[Math.min(l,a.length)-1];}
}
