package org.examplee.smakenchant;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Описание одного кастомного зачарования (хранится в PDC предмета, а не в реестре Minecraft).
 */
public final class CustomEnchantment {

    private final String id;             // "multi_jump", "made_in_china", ...
    private final String displayName;    // "Многоуровневый прыжок"
    private final boolean curse;
    private final int maxLevel;
    private final Set<Material> appliesTo;
    private final boolean allDamageable; // «подходит для всего»
    private final List<String> aliases = new ArrayList<>();

    // шансы на столе зачарований (индекс = уровень - 1)
    private double[] tableChance = new double[0];
    private int tableWeight = 4;
    private int anvilCostPerLevel = 3;
    private int[] levelValues = new int[0]; // произвольные числа по уровням (например % скорости)

    public CustomEnchantment(String id, String displayName, boolean curse, int maxLevel,
                             Set<Material> appliesTo, boolean allDamageable, List<String> aliases) {
        this.id = id;
        this.displayName = displayName;
        this.curse = curse;
        this.maxLevel = Math.max(1, maxLevel);
        this.appliesTo = appliesTo == null ? EnumSet.noneOf(Material.class) : appliesTo;
        this.allDamageable = allDamageable;
        if (aliases != null) for (String a : aliases) this.aliases.add(a.toLowerCase(Locale.ROOT));
    }

    public CustomEnchantment tableChance(double... perLevel) {
        this.tableChance = perLevel == null ? new double[0] : perLevel.clone();
        return this;
    }

    public CustomEnchantment tableWeight(int w) { this.tableWeight = Math.max(0, w); return this; }

    public CustomEnchantment anvilCostPerLevel(int c) { this.anvilCostPerLevel = Math.max(0, c); return this; }

    public CustomEnchantment levelValues(int... values) { this.levelValues = values == null ? new int[0] : values.clone(); return this; }

    public String id() { return id; }

    public String displayName() { return displayName; }

    public boolean isCurse() { return curse; }

    public int maxLevel() { return maxLevel; }

    public int tableWeight() { return tableWeight; }

    public int anvilCostPerLevel() { return anvilCostPerLevel; }

    public List<String> aliases() { return aliases; }

    /** Шанс получить уровень {@code level} (1-based) на столе зачарований. */
    public double chanceForLevel(int level) {
        int idx = level - 1;
        return idx >= 0 && idx < tableChance.length ? tableChance[idx] : 0.0;
    }

    /** Числовое значение уровня из level-values (например % ускорения). 0 если не задано. */
    public int valueForLevel(int level) {
        int idx = level - 1;
        return idx >= 0 && idx < levelValues.length ? levelValues[idx] : 0;
    }

    public int clampLevel(int level) {
        return Math.max(0, Math.min(maxLevel, level));
    }

    /** Подходит ли зачарование этому материалу. */
    public boolean appliesTo(Material mat) {
        if (mat == null || mat.isAir()) return false;
        if (mat == Material.ENCHANTED_BOOK) return true; // книга принимает всё
        if (allDamageable) return SmakenchantUtil.isDamageableTool(mat);
        return appliesTo.contains(mat);
    }

    public boolean appliesTo(ItemStack stack) {
        return stack != null && appliesTo(stack.getType());
    }

    public String loreLine(int level, String style) {
        String raw = displayName + " " + TextFx.roman(level);
        if ("plain".equalsIgnoreCase(style)) return raw;
        if ("legacy".equalsIgnoreCase(style)) return (curse ? "§4§o" : "§d") + raw;
        return TextFx.paletteGradient(raw, palette(), curse);
    }

    /** Секция предмета определяет собственный градиент lore. */
    public String palette() {
        if (appliesTo.contains(Material.BOW) || appliesTo.contains(Material.CROSSBOW)) return "ranged";
        if (appliesTo.size() == 1 && appliesTo.contains(Material.SHIELD)) return "shield";
        boolean onlyBoots = !appliesTo.isEmpty() && appliesTo.stream().allMatch(SmakenchantUtil.BOOTS::contains);
        if (onlyBoots) return "boots";
        boolean anyArmor = appliesTo.stream().anyMatch(SmakenchantUtil.ARMOR::contains);
        if (anyArmor) return "armor";
        boolean anyTool = appliesTo.stream().anyMatch(SmakenchantUtil.DIGGING_TOOLS::contains);
        if (anyTool) return "tools";
        return "melee";
    }

    @Override
    public String toString() { return id; }
}
