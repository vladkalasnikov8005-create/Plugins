package org.examplee.smakenchant;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.view.AnvilView;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Smakenchant — кастомные зачарования для Paper 26.2. */
@SuppressWarnings({"deprecation","removal"})
public final class Smakenchant extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private CustomEnchantStore store;
    private final Map<String,CustomEnchantment> custom=new LinkedHashMap<>();
    private final Map<Enchantment,OverrideCfg> overrides=new HashMap<>();
    private BlockCategories categories;
    private MultiJumpManager multiJump;
    private DurabilityCurseManager china;
    private PricklyManager prickly;
    private MiningSpeedManager mining;
    private CombatEnchantManager combat;
    private GravityAndFrostManager gravityAndFrost;
    private ProjectileEnchantManager projectiles;
    private ToolEnchantManager toolsManager;
    private ArmorEnchantManager armorManager;
    private CurseEffectsManager curseEffects;
    private AdditionalCurseManager additionalCurses;

    private CustomEnchantment mj,madeChina,thorny,slow,swift,blood,gravity,frost;
    private CustomEnchantment heavyString,heavyPickaxe,dustCurse,suffocationCurse,loudArmorCurse,weakShieldCurse,badLandingCurse,stumbleCurse,heavyStepCurse;
    private CustomEnchantment dullness,pacifist,rust,crookedAim,loudShot,emptyQuiver;
    private CustomEnchantment shardArrow,chainLightning,eagleEye,returning,hunterMark,heavyBolt,autoSmelt,experiencedMiner;
    private CustomEnchantment stoneSkin,sandwalker,shadow,softLanding,jumper,impulse;
    private static final class OverrideCfg { boolean enabled; int vanillaMax,newMax,cost; }

    @Override public void onEnable(){
        saveDefaultConfig();
        store=new CustomEnchantStore(this);
        registerEnchantments();
        categories=new BlockCategories();
        multiJump=new MultiJumpManager(this,store,mj);
        china=new DurabilityCurseManager(this,store,madeChina);
        prickly=new PricklyManager(this,store,thorny,categories);
        mining=new MiningSpeedManager(this,store,slow,swift);
        combat=new CombatEnchantManager(this,store,slow,swift,blood);
        gravityAndFrost=new GravityAndFrostManager(this,store,gravity,frost);
        projectiles=new ProjectileEnchantManager(this,store,shardArrow,chainLightning,eagleEye,returning,hunterMark,heavyBolt);
        toolsManager=new ToolEnchantManager(store,autoSmelt,experiencedMiner);
        armorManager=new ArmorEnchantManager(this,store,stoneSkin,sandwalker,shadow,softLanding,jumper,impulse);
        curseEffects=new CurseEffectsManager(this,store,dullness,pacifist,rust,crookedAim,loudShot,emptyQuiver);
        additionalCurses=new AdditionalCurseManager(this,store,heavyString,heavyPickaxe,dustCurse,suffocationCurse,loudArmorCurse,weakShieldCurse,badLandingCurse,stumbleCurse,heavyStepCurse);
        PluginManager pm=getServer().getPluginManager();
        for(Listener l:List.of(this,multiJump,china,prickly,mining,combat,gravityAndFrost,projectiles,toolsManager,armorManager,curseEffects,additionalCurses))pm.registerEvents(l,this);
        Objects.requireNonNull(getCommand("smakenchant")).setExecutor(this);
        Objects.requireNonNull(getCommand("smakenchant")).setTabCompleter(this);
        reloadAll();
        for(Player p:Bukkit.getOnlinePlayers()) multiJump.onPlayerReady(p);
        multiJump.startTasks();
        getLogger().info("Smakenchant v2.0 включен: 6 кастомных зачарований, Paper 26.2");
    }

    @Override public void onDisable(){
        if(multiJump!=null){multiJump.stopTasks();for(Player p:Bukkit.getOnlinePlayers())multiJump.reset(p);}
        if(mining!=null)mining.stop(); if(combat!=null)combat.stop(); if(gravityAndFrost!=null)gravityAndFrost.stop(); if(armorManager!=null)armorManager.stop(); if(additionalCurses!=null)additionalCurses.stop();
        Bukkit.getScheduler().cancelTasks(this);
    }

    private void registerEnchantments(){
        mj=reg(new CustomEnchantment("multi_jump","Многоуровневый прыжок",false,2,SmakenchantUtil.BOOTS,false,List.of("multijump","mj","прыжок")));
        madeChina=reg(new CustomEnchantment("made_in_china","Сделано в Китае",true,2,Set.of(),true,List.of("china","madeinchina","китай")));
        // Колючий / Медленный / Шустрый идут на инструменты и оружие
        Set<Material> tools=new HashSet<>(SmakenchantUtil.DIGGING_TOOLS);tools.addAll(SmakenchantUtil.MELEE_WEAPONS);
        thorny=reg(new CustomEnchantment("prickly","Колючий",true,3,tools,false,List.of("thorny","колючий")));
        slow=reg(new CustomEnchantment("slow","Медленный",true,3,tools,false,List.of("slowly","медленный")));
        swift=reg(new CustomEnchantment("swift","Шустрый",false,4,tools,false,List.of("quick","fast","шустрый")));
        blood=reg(new CustomEnchantment("blood_transfusion","Переливание крови",false,2,SmakenchantUtil.MELEE_WEAPONS,false,List.of("blood","lifesteal","кровь")));
        gravity=reg(new CustomEnchantment("gravity_curse","Проклятие тяжести",true,3,SmakenchantUtil.ARMOR,false,List.of("gravity","тяжесть")));
        frost=reg(new CustomEnchantment("frost_touch","Ледяное касание",false,3,SmakenchantUtil.MELEE_WEAPONS,false,List.of("frost","ice","лёд","лед")));
        Set<Material> ranged=Set.of(Material.BOW,Material.CROSSBOW);
        shardArrow=reg(new CustomEnchantment("shard_arrow","Осколочная стрела",false,3,ranged,false,List.of("shard")));
        chainLightning=reg(new CustomEnchantment("chain_lightning","Цепная молния",false,3,ranged,false,List.of("chain")));
        eagleEye=reg(new CustomEnchantment("eagle_eye","Орлиный глаз",false,3,ranged,false,List.of("eagle")));
        returning=reg(new CustomEnchantment("returning","Возврат",false,3,ranged,false,List.of("return")));
        hunterMark=reg(new CustomEnchantment("hunter_mark","Охотничья метка",false,3,ranged,false,List.of("mark")));
        heavyBolt=reg(new CustomEnchantment("heavy_bolt","Тяжёлый болт",false,3,ranged,false,List.of("heavy")));
        autoSmelt=reg(new CustomEnchantment("auto_smelt","Переплавка",false,5,SmakenchantUtil.PICKAXES,false,List.of("smelt")));
        experiencedMiner=reg(new CustomEnchantment("experienced_miner","Опытный шахтёр",false,3,SmakenchantUtil.PICKAXES,false,List.of("xpminer")));
        stoneSkin=reg(new CustomEnchantment("stone_skin","Каменная кожа",false,3,SmakenchantUtil.ARMOR,false,List.of("stone")));
        shadow=reg(new CustomEnchantment("shadow","Тень",false,3,SmakenchantUtil.ARMOR,false,List.of("shade")));
        sandwalker=reg(new CustomEnchantment("sandwalker","Песчаник",false,3,SmakenchantUtil.BOOTS,false,List.of("sand")));
        softLanding=reg(new CustomEnchantment("soft_landing","Мягкое приземление",false,3,SmakenchantUtil.BOOTS,false,List.of("soft")));
        jumper=reg(new CustomEnchantment("jumper","Прыгун",false,3,SmakenchantUtil.BOOTS,false,List.of("jump")));
        impulse=reg(new CustomEnchantment("impulse","Импульс",false,3,SmakenchantUtil.BOOTS,false,List.of("landing_impulse")));
        Set<Material> allWeapons=new HashSet<>(tools);allWeapons.addAll(ranged);
        dullness=reg(new CustomEnchantment("dullness_curse","Проклятие тупости",true,3,allWeapons,false,List.of("dullness","тупость")));
        pacifist=reg(new CustomEnchantment("pacifist_curse","Проклятие пацифиста",true,3,allWeapons,false,List.of("pacifist","пацифист")));
        rust=reg(new CustomEnchantment("rust_curse","Проклятие ржавчины",true,3,Set.of(),true,List.of("rust","ржавчина")));
        crookedAim=reg(new CustomEnchantment("crooked_aim_curse","Проклятие кривого прицела",true,3,ranged,false,List.of("crooked","кривой_прицел")));
        loudShot=reg(new CustomEnchantment("loud_shot_curse","Проклятие громкого выстрела",true,3,ranged,false,List.of("loudshot","громкий_выстрел")));
        emptyQuiver=reg(new CustomEnchantment("empty_quiver_curse","Проклятие пустого колчана",true,3,ranged,false,List.of("emptyquiver","пустой_колчан")));
        heavyString=reg(new CustomEnchantment("heavy_string_curse","Проклятие тяжёлой тетивы",true,3,ranged,false,List.of("heavystring","тяжёлая_тетива")));
        heavyPickaxe=reg(new CustomEnchantment("heavy_pickaxe_curse","Проклятие тяжёлой кирки",true,3,SmakenchantUtil.PICKAXES,false,List.of("heavypick","тяжёлая_кирка")));
        dustCurse=reg(new CustomEnchantment("dust_curse","Проклятие пыли",true,3,SmakenchantUtil.DIGGING_TOOLS,false,List.of("dust","пыль")));
        suffocationCurse=reg(new CustomEnchantment("suffocation_curse","Проклятие удушья",true,3,SmakenchantUtil.ARMOR,false,List.of("suffocation","удушье")));
        loudArmorCurse=reg(new CustomEnchantment("loud_armor_curse","Проклятие громкой брони",true,3,SmakenchantUtil.ARMOR,false,List.of("loudarmor","громкая_броня")));
        weakShieldCurse=reg(new CustomEnchantment("weak_shield_curse","Проклятие слабого щита",true,3,Set.of(Material.SHIELD),false,List.of("weakshield","слабый_щит")));
        badLandingCurse=reg(new CustomEnchantment("bad_landing_curse","Проклятие неудачного приземления",true,3,SmakenchantUtil.BOOTS,false,List.of("badlanding","неудачное_приземление")));
        stumbleCurse=reg(new CustomEnchantment("stumble_curse","Проклятие спотыкания",true,3,SmakenchantUtil.BOOTS,false,List.of("stumble","спотыкание")));
        heavyStepCurse=reg(new CustomEnchantment("heavy_step_curse","Проклятие тяжёлого шага",true,3,SmakenchantUtil.BOOTS,false,List.of("heavystep","тяжёлый_шаг")));
    }
    private CustomEnchantment reg(CustomEnchantment e){custom.put(e.id(),e);store.register(e);return e;}

    private void reloadAll(){
        reloadConfig(); store.setLoreStyle(getConfig().getString("general.lore-style","gradient"));
        categories.load(getConfig()); loadOverrides();
        multiJump.loadConfig(getConfig()); china.loadConfig(getConfig()); prickly.loadConfig(getConfig());
        mining.loadConfig(getConfig()); combat.loadConfig(getConfig()); gravityAndFrost.loadConfig(getConfig());
        projectiles.loadConfig(getConfig()); toolsManager.loadConfig(getConfig()); armorManager.loadConfig(getConfig()); curseEffects.loadConfig(getConfig()); additionalCurses.loadConfig(getConfig());
        multiJump.resyncAll();
    }

    private void loadOverrides(){
        overrides.clear();ConfigurationSection sec=getConfig().getConfigurationSection("overrides");if(sec==null)return;
        for(String n:sec.getKeys(false)){
            Enchantment e=resolveVanilla(n);if(e==null){getLogger().warning("Не найден энчант: "+n);continue;}
            OverrideCfg c=new OverrideCfg();c.enabled=sec.getBoolean(n+".enabled",false);c.vanillaMax=sec.getInt(n+".vanilla-max",e.getMaxLevel());
            c.newMax=Math.max(c.vanillaMax,sec.getInt(n+".new-max",e.getMaxLevel()));c.cost=sec.getInt(n+".cost-per-extra-level",5);overrides.put(e,c);
        }
    }
    private Enchantment resolveVanilla(String n){try{return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(n.toLowerCase(Locale.ROOT)));}catch(Throwable t){return null;}}

    // -------- старые багнутые книги --------
    private boolean fixBugBook(ItemStack s){
        if(s==null||s.getType()!=Material.ENCHANTED_BOOK||!(s.getItemMeta() instanceof EnchantmentStorageMeta m))return false;
        Map<Enchantment,Integer> bad=new HashMap<>(m.getEnchants());boolean changed=false;
        for(var en:bad.entrySet()){if(m.getStoredEnchantLevel(en.getKey())<en.getValue())m.addStoredEnchant(en.getKey(),en.getValue(),true);m.removeEnchant(en.getKey());changed=true;}
        if(changed)s.setItemMeta(m);return changed;
    }
    private void fixInventory(Player p){boolean changed=false;for(ItemStack item:p.getInventory().getContents()){changed|=fixBugBook(item);changed|=removeLegacyConflicts(item);}if(changed)p.updateInventory();}

    /** Чистит уже существующие предметы старых версий, если на них оказалась конфликтующая пара. */
    private boolean removeLegacyConflicts(ItemStack item){
        if(item==null||item.getType().isAir())return false;
        boolean changed=false;
        for(CustomEnchantment current:custom.values()){
            int currentLevel=store.getLevel(item,current);if(currentLevel<=0)continue;
            for(String otherId:customConflicts(current.id())){
                CustomEnchantment other=custom.get(otherId);if(other==null)continue;
                int otherLevel=store.getLevel(item,other);if(otherLevel<=0)continue;
                // Оставляем более высокий уровень; при равенстве — первый зарегистрированный.
                if(otherLevel>currentLevel){store.apply(item,current,0);changed=true;break;}
                else{store.apply(item,other,0);changed=true;}
            }
        }
        return changed;
    }
    @EventHandler public void onJoin(PlayerJoinEvent e){multiJump.onPlayerReady(e.getPlayer());Bukkit.getScheduler().runTaskLater(this,()->fixInventory(e.getPlayer()),5);}
    @EventHandler public void onOpen(org.bukkit.event.inventory.InventoryOpenEvent e){if(e.getPlayer() instanceof Player p)Bukkit.getScheduler().runTaskLater(this,()->fixInventory(p),1);}

    // -------- стол зачарований --------
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onEnchant(EnchantItemEvent e){
        ItemStack item=e.getItem();if(item==null)return;
        List<CustomEnchantment> eligible=new ArrayList<>();
        for(CustomEnchantment ce:custom.values())if(ce.appliesTo(item)&&store.getLevel(item,ce)==0)eligible.add(ce);
        if(eligible.isEmpty())return;
        ThreadLocalRandom r=ThreadLocalRandom.current();
        // не более одного кастомного энчанта за одно зачарование
        Collections.shuffle(eligible,r);
        for(CustomEnchantment ce:eligible){
            int chosen=0;for(int lvl=ce.maxLevel();lvl>=1;lvl--)if(r.nextDouble()<ce.chanceForLevel(lvl)){chosen=lvl;break;}
            if(chosen>0){int level=chosen;Bukkit.getScheduler().runTask(this,()->applyCustom(item,ce,level));break;}
        }
    }

    // -------- наковальня: custom + ваниль выше лимита --------
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onAnvil(PrepareAnvilEvent e){
        ItemStack left=e.getInventory().getItem(0),right=e.getInventory().getItem(1),result=e.getResult();
        if(left==null||result==null)return;ItemStack work=result.clone();int extra=applyCustomAnvil(work,left,right)+applyVanillaOvercap(work,left,right);
        // Книга может содержать несколько чар, но на предмет переносим только совместимые.
        // Например: с книги «Тягун II + Эффективность III» на трезубец попадёт только Тягун.
        sanitizeVanillaCompatibility(work,left);
        e.setResult(work);if(extra>0){int base=Math.max(1,e.getView().getRepairCost());int cost=Math.min(39,base+extra);e.getView().setRepairCost(cost);e.getInventory().setRepairCost(cost);}
    }

    /**
     * Удаляет с результата ванильные чары, которые пришли с правого предмета/книги и
     * не предназначены для типа предмета слева. Чары, уже находившиеся на левом
     * предмете (включая старые админские предметы), не трогаются.
     */
    private void sanitizeVanillaCompatibility(ItemStack result,ItemStack left){
        if(result==null||result.getType()==Material.ENCHANTED_BOOK)return;
        Map<Enchantment,Integer> leftEnchants=enchants(left);
        ItemMeta meta=result.getItemMeta();if(meta==null)return;
        boolean changed=false;
        for(Enchantment enchantment:new HashSet<>(result.getEnchantments().keySet())){
            if(enchantment.canEnchantItem(result))continue;
            // Не удаляем уже существовавший нестандартный энчант с базового предмета.
            if(leftEnchants.containsKey(enchantment))continue;
            meta.removeEnchant(enchantment);changed=true;
        }
        if(changed)result.setItemMeta(meta);
    }
    private int applyCustomAnvil(ItemStack out,ItemStack left,ItemStack right){
        int cost=0;boolean book=out.getType()==Material.ENCHANTED_BOOK;
        for(CustomEnchantment ce:custom.values()){
            int l=store.getLevel(left,ce),r=store.getLevel(right,ce);if(l<=0&&r<=0)continue;
            if(!book&&!ce.appliesTo(out))continue;int target=l==r&&l>0?Math.min(ce.maxLevel(),l+1):Math.max(l,r);
            if(target>store.getLevel(out,ce)){applyCustom(out,ce,target);cost+=ce.anvilCostPerLevel()*Math.max(1,target-l);}
        }return cost;
    }
    private int applyVanillaOvercap(ItemStack out,ItemStack left,ItemStack right){
        Map<Enchantment,Integer> l=enchants(left),r=enchants(right);int cost=0;
        for(var en:r.entrySet()){
            Enchantment ec=en.getKey();OverrideCfg c=overrides.get(ec);if(c==null||!c.enabled)continue;
            int a=l.getOrDefault(ec,0),b=en.getValue(),target=a==b&&a>0?Math.min(c.newMax,a+1):Math.min(c.newMax,Math.max(a,b));
            // Не переносим с книги неподходящие чары даже через систему повышенных лимитов.
            if(out.getType()!=Material.ENCHANTED_BOOK&&!ec.canEnchantItem(out)&&a<=0)continue;
            if(target>enchants(out).getOrDefault(ec,0)){setVanilla(out,ec,target);if(target>c.vanillaMax)cost+=(target-c.vanillaMax)*c.cost;}
        }return cost;
    }
    private Map<Enchantment,Integer> enchants(ItemStack s){if(s==null)return Map.of();if(s.getItemMeta() instanceof EnchantmentStorageMeta m)return m.getStoredEnchants();return s.getEnchantments();}
    private void setVanilla(ItemStack s,Enchantment e,int lvl){ItemMeta m=s.getItemMeta();if(m instanceof EnchantmentStorageMeta em){em.removeStoredEnchant(e);em.addStoredEnchant(e,lvl,true);s.setItemMeta(em);}else if(m!=null){m.removeEnchant(e);m.addEnchant(e,lvl,true);s.setItemMeta(m);}}
    /**
     * Накладывает кастомный энчант и гарантированно снимает все противоположные.
     * Так конфликт нельзя обойти столом, книгой, наковальней или админ-командой.
     */
    private void applyCustom(ItemStack item,CustomEnchantment ce,int level){
        if(level>0){
            for(String conflictId:customConflicts(ce.id())){
                CustomEnchantment conflict=custom.get(conflictId);
                if(conflict!=null)store.apply(item,conflict,0);
            }
        }
        store.apply(item,ce,level);
    }

    /** Симметричные группы взаимоисключающих зачарований. */
    private Set<String> customConflicts(String id){
        List<Set<String>> groups=List.of(
                Set.of("slow","swift"),
                // точность/скорость против тяжёлого или кривого снаряда
                Set.of("eagle_eye","heavy_bolt","crooked_aim_curse"),
                // экономия стрел против их дополнительного расходования
                Set.of("returning","empty_quiver_curse"),
                // безопасное падение против усиленного урона от падения
                Set.of("soft_landing","bad_landing_curse"),
                // ускорение после приземления против спотыкания
                Set.of("impulse","stumble_curse"),
                // лёгкий высокий прыжок против тяжёлых ног
                Set.of("jumper","gravity_curse","heavy_step_curse"),
                // скрытная броня против брони, привлекающей мобов
                Set.of("shadow","loud_armor_curse"),
                // лечение от атаки против самоповреждения оружием
                Set.of("blood_transfusion","prickly")
        );
        for(Set<String> group:groups){
            if(group.contains(id)){Set<String> out=new HashSet<>(group);out.remove(id);return out;}
        }
        return Set.of();
    }

    // -------- команды --------
    private CustomEnchantment findCustom(String raw){String n=raw.toLowerCase(Locale.ROOT).replace('-','_');CustomEnchantment e=custom.get(n);if(e!=null)return e;for(CustomEnchantment c:custom.values())if(c.aliases().contains(n))return c;return null;}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(args.length==0){help(sender);return true;}
        if(!sender.hasPermission("smakenchant.admin")){sender.sendMessage("§cНет прав.");return true;}
        switch(args[0].toLowerCase(Locale.ROOT)){
            case "reload"->{reloadAll();sender.sendMessage("§a[Smakenchant] Конфиг перезагружен.");return true;}
            case "debug"->{if(!(sender instanceof Player p)){sender.sendMessage("§cТолько игрок.");return true;}sender.sendMessage("§d=== Smakenchant debug ===");multiJump.debugInfo(p).forEach(x->p.sendMessage("§7MJ: "+x));mining.debug(p).forEach(x->p.sendMessage("§7Speed: "+x));china.debug(p);return true;}
            case "give"->{return commandGive(sender,args);}
            case "enchant"->{return commandEnchant(sender,args);}
            case "remove"->{if(!(sender instanceof Player p)||args.length<2){sender.sendMessage("§e/smakenchant remove <ench|all>");return true;}ItemStack h=p.getInventory().getItemInMainHand();if(args[1].equalsIgnoreCase("all"))store.clearAll(h);else{CustomEnchantment ce=findCustom(args[1]);if(ce!=null)store.apply(h,ce,0);}p.sendMessage("§aСнято.");return true;}
            default->{help(sender);return true;}
        }
    }
    private boolean commandGive(CommandSender s,String[] a){
        if(a.length<2){s.sendMessage("§e/smakenchant give <ench> [lvl] [player]");return true;}CustomEnchantment ce=findCustom(a[1]);if(ce==null){s.sendMessage("§cНеизвестное кастомное зачарование.");return true;}
        int lvl=parseLevel(a,2,1,ce.maxLevel());Player p=a.length>=4?Bukkit.getPlayerExact(a[3]):s instanceof Player x?x:null;if(p==null){s.sendMessage("§cУкажите игрока.");return true;}
        ItemStack b=new ItemStack(Material.ENCHANTED_BOOK);applyCustom(b,ce,lvl);for(ItemStack x:p.getInventory().addItem(b).values())p.getWorld().dropItemNaturally(p.getLocation(),x);s.sendMessage("§aВыдано: "+ce.displayName()+" "+TextFx.roman(lvl));return true;
    }
    private boolean commandEnchant(CommandSender s,String[] a){
        if(!(s instanceof Player p)){s.sendMessage("§cТолько игрок.");return true;}if(a.length<2){s.sendMessage("§e/smakenchant enchant <ench> [lvl]");return true;}CustomEnchantment ce=findCustom(a[1]);if(ce==null){s.sendMessage("§cНеизвестное кастомное зачарование.");return true;}
        ItemStack h=p.getInventory().getItemInMainHand();if(h.getType().isAir()||!ce.appliesTo(h)){s.sendMessage("§cЗачарование не подходит предмету.");return true;}int lvl=parseLevel(a,2,1,ce.maxLevel());applyCustom(h,ce,lvl);p.sendMessage("§aНаложено: "+ce.displayName()+" "+TextFx.roman(lvl));return true;
    }
    private int parseLevel(String[] a,int i,int d,int max){if(a.length<=i)return d;try{return Math.max(1,Math.min(max,Integer.parseInt(a[i])));}catch(Exception e){return d;}}
    private void help(CommandSender s){s.sendMessage("§d==== Smakenchant v3.2 ====");s.sendMessage("§f/smakenchant give <ench> [lvl] [player]");s.sendMessage("§f/smakenchant enchant <ench> [lvl]");s.sendMessage("§f/smakenchant remove <ench|all>");s.sendMessage("§f/smakenchant reload §7| §fdebug");
        for(String section:List.of("melee","ranged","tools","armor","boots","shield")){List<String> ids=custom.values().stream().filter(e->e.palette().equals(section)).map(CustomEnchantment::id).toList();if(!ids.isEmpty())s.sendMessage("§7"+section+": §f"+String.join(", ",ids));}}

    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){
        if(a.length==1)return filter(List.of("reload","give","enchant","remove","debug"),a[0]);
        if(a.length==2&&List.of("give","enchant","remove").contains(a[0].toLowerCase(Locale.ROOT))){List<String>x=new ArrayList<>(custom.keySet());if(a[0].equalsIgnoreCase("remove"))x.add("all");return filter(x,a[1]);}
        if(a.length==3&&(a[0].equalsIgnoreCase("give")||a[0].equalsIgnoreCase("enchant")))return filter(List.of("1","2","3","4"),a[2]);
        if(a.length==4&&a[0].equalsIgnoreCase("give")){List<String>x=new ArrayList<>();for(Player p:Bukkit.getOnlinePlayers())x.add(p.getName());return filter(x,a[3]);}return List.of();
    }
    private List<String> filter(Collection<String> src,String p){String q=p.toLowerCase(Locale.ROOT);return src.stream().filter(x->x.toLowerCase(Locale.ROOT).startsWith(q)).sorted().toList();}
}
