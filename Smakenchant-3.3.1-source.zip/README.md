# Smakenchant

Репозиторий содержит только один плагин — **Smakenchant** для Paper 26.2.

Исходники находятся в папке [`Smakenchant`](Smakenchant/).

## Сборка

```bash
cd Smakenchant
./gradlew clean build
```

Готовый JAR: `Smakenchant/build/libs/Smakenchant.jar`.
