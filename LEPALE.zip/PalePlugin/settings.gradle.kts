rootProject.name = "PalePlugin"
