package org.examplee.tactic;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/** Кейсы / лутбоксы. Игрокам — только display-name, без ярлыков типа. */
public final class LootBoxManager implements Listener {

    public enum BoxKind { CASE, LOOTBOX }
    public enum RollMode { WEIGHTED, INDEPENDENT }
    public enum UseMode { INFINITE, ONCE_PER_PLAYER, ONCE_GLOBAL, USES }
    public enum Rarity {
        COMMON(ChatColor.GRAY, 0xAAAAAA, "§7Обычный"),
        UNCOMMON(ChatColor.GREEN, 0x55FF55, "§aНеобычный"),
        RARE(ChatColor.AQUA, 0x55FFFF, "§bРедкий"),
        EPIC(ChatColor.LIGHT_PURPLE, 0xFF55FF, "§dЭпический"),
        LEGENDARY(ChatColor.GOLD, 0xFFAA00, "§6Легендарный");
        public final ChatColor color; public final int rgb; public final String label;
        Rarity(ChatColor c, int rgb, String label) { this.color = c; this.rgb = rgb; this.label = label; }
        static Rarity parse(String s) {
            if (s == null) return COMMON;
            try { return Rarity.valueOf(s.trim().toUpperCase(Locale.ROOT)); } catch (Exception e) { return COMMON; }
        }
    }

    public static final class DropEntry {
        public ItemStack item;
        public double chanceOrWeight = 10.0;
        public Rarity rarity = Rarity.COMMON;
        public int minAmount = 1, maxAmount = 1;
    }

    public static final class Template {
        public String id;
        public String displayName = "§6Сундук";
        public ItemStack baseItem = new ItemStack(Material.CHEST);
        public BoxKind kind = BoxKind.LOOTBOX;
        public RollMode rollMode = RollMode.WEIGHTED;
        public UseMode useMode = UseMode.ONCE_PER_PLAYER;
        public int maxUses = 1, cooldownSec = 0;
        public boolean hologram = true, animation = true, broadcastLegendary = true;
        /** Убрать мировой инстанс после открытия. Шаблон сам никогда не удаляется. */
        public boolean removeOnOpen = false;
        public Rarity shellRarity = Rarity.RARE;
        public final List<DropEntry> drops = new ArrayList<>();
        public double secondDropChance = 0.0;
        public boolean requireKey = false;
        public ItemStack keyItem = null;
        public int pityThreshold = 0;
        public double pityBonusPerFail = 0.0;
    }

    public static final class WorldInstance {
        public UUID uuid; public String templateId; public UUID worldId;
        public double x, y, z; public float yaw; public int usesLeft = -1;
        public final Set<UUID> openedBy = new HashSet<>();
        public transient UUID standUuid, displayUuid, holoUuid;
    }

    private final TacticPlugin plugin;
    private final NamespacedKey keyTemplateId, keyItemFlag, keyInst;
    private final Map<String, Template> templates = new LinkedHashMap<>();
    private final Map<UUID, WorldInstance> instances = new ConcurrentHashMap<>();
    private final Map<String, Integer> pityByKey = new ConcurrentHashMap<>();
    private final Map<String, Long> cdMap = new ConcurrentHashMap<>();
    private final Map<UUID, String> editTemplate = new HashMap<>();
    private final Map<UUID, Inventory> editMainInv = new HashMap<>();
    private final Map<UUID, Inventory> editDropsInv = new HashMap<>();
    private final Map<UUID, Inventory> editEntryInv = new HashMap<>();
    private final Map<UUID, Integer> editEntryIndex = new HashMap<>();
    private final Map<UUID, String> chatWait = new HashMap<>();
    private final Map<UUID, Boolean> openingAnim = new ConcurrentHashMap<>();
    private BukkitTask fxTask;
    private final File templatesFile, instancesFile;

    public LootBoxManager(TacticPlugin plugin) {
        this.plugin = plugin;
        keyTemplateId = new NamespacedKey(plugin, "lb_template");
        keyItemFlag = new NamespacedKey(plugin, "lb_place_item");
        keyInst = new NamespacedKey(plugin, "lb_instance");
        templatesFile = new File(plugin.getDataFolder(), "lootboxes.yml");
        instancesFile = new File(plugin.getDataFolder(), "lootbox-instances.yml");
    }

    public void enable() {
        loadTemplates();
        Bukkit.getScheduler().runTaskLater(plugin, this::loadAndSpawnInstances, 40L);
        fxTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickFx, 10L, 10L);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("[LootBox] templates=" + templates.size());
    }

    public void disable() {
        if (fxTask != null) fxTask.cancel();
        saveTemplates(); saveInstances();
        for (WorldInstance wi : instances.values()) despawnVisuals(wi, false);
        editTemplate.clear(); editMainInv.clear(); editDropsInv.clear(); editEntryInv.clear(); chatWait.clear();
    }

    private UseMode parseUseMode(String s) {
        if (s == null) return UseMode.ONCE_PER_PLAYER;
        return switch (s.toUpperCase(Locale.ROOT)) {
            case "INFINITE", "INF" -> UseMode.INFINITE;
            case "ONCE_GLOBAL", "ONE_SHOT", "GLOBAL" -> UseMode.ONCE_GLOBAL;
            case "USES", "LIMITED" -> UseMode.USES;
            default -> UseMode.ONCE_PER_PLAYER;
        };
    }

    private String toBase64(ItemStack item) {
        if (item == null) return null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (BukkitObjectOutputStream oos = new BukkitObjectOutputStream(baos)) { oos.writeObject(item); }
            return Base64.getEncoder().encodeToString(baos.toByteArray());
        } catch (Exception e) { return null; }
    }
    private ItemStack fromBase64(String b64) {
        if (b64 == null || b64.isEmpty()) return null;
        try (BukkitObjectInputStream ois = new BukkitObjectInputStream(new ByteArrayInputStream(Base64.getDecoder().decode(b64)))) {
            Object o = ois.readObject(); return o instanceof ItemStack is ? is : null;
        } catch (Exception e) { return null; }
    }

    private void loadTemplates() {
        templates.clear();
        if (!templatesFile.exists()) { saveTemplates(); return; }
        FileConfiguration yml = YamlConfiguration.loadConfiguration(templatesFile);
        ConfigurationSection root = yml.getConfigurationSection("templates");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id); if (s == null) continue;
            Template t = new Template();
            t.id = id.toLowerCase(Locale.ROOT);
            t.displayName = ChatColor.translateAlternateColorCodes('&', s.getString("display-name", "§6Сундук"));
            t.kind = "CASE".equalsIgnoreCase(s.getString("kind", "LOOTBOX")) ? BoxKind.CASE : BoxKind.LOOTBOX;
            t.rollMode = "INDEPENDENT".equalsIgnoreCase(s.getString("roll-mode", "WEIGHTED")) ? RollMode.INDEPENDENT : RollMode.WEIGHTED;
            t.useMode = parseUseMode(s.getString("use-mode", "ONCE_PER_PLAYER"));
            t.maxUses = s.getInt("max-uses", 1); t.cooldownSec = s.getInt("cooldown-sec", 0);
            t.hologram = s.getBoolean("hologram", true); t.animation = s.getBoolean("animation", true);
            t.broadcastLegendary = s.getBoolean("broadcast-legendary", true);
            if (s.contains("remove-on-open")) t.removeOnOpen = s.getBoolean("remove-on-open");
            else t.removeOnOpen = (t.kind == BoxKind.CASE);
            t.shellRarity = Rarity.parse(s.getString("shell-rarity", "RARE"));
            t.secondDropChance = s.getDouble("second-drop-chance", 0.0);
            t.requireKey = s.getBoolean("require-key", false);
            t.pityThreshold = s.getInt("pity-threshold", 0); t.pityBonusPerFail = s.getDouble("pity-bonus", 0.0);
            ItemStack base = fromBase64(s.getString("base-item", null)); if (base != null) t.baseItem = base;
            t.keyItem = fromBase64(s.getString("key-item", null));
            List<?> list = s.getList("drops");
            if (list != null) for (Object o : list) {
                if (!(o instanceof Map<?,?> m)) continue;
                DropEntry d = new DropEntry();
                Object ib = m.get("item"); if (ib instanceof String str) d.item = fromBase64(str);
                Object ch = m.get("chance"); if (ch instanceof Number n) d.chanceOrWeight = n.doubleValue();
                Object rar = m.get("rarity");
                d.rarity = Rarity.parse(rar != null ? String.valueOf(rar) : "COMMON");
                Object mn = m.get("min"); if (mn instanceof Number n) d.minAmount = Math.max(1, n.intValue());
                Object mx = m.get("max"); if (mx instanceof Number n) d.maxAmount = Math.max(d.minAmount, n.intValue());
                if (d.item != null) t.drops.add(d);
            }
            templates.put(t.id, t);
        }
    }

    public void saveTemplates() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Template t : templates.values()) {
            String p = "templates." + t.id + ".";
            yml.set(p + "display-name", t.displayName.replace(ChatColor.COLOR_CHAR, '&'));
            yml.set(p + "kind", t.kind.name()); yml.set(p + "roll-mode", t.rollMode.name());
            yml.set(p + "use-mode", t.useMode.name()); yml.set(p + "max-uses", t.maxUses);
            yml.set(p + "cooldown-sec", t.cooldownSec); yml.set(p + "hologram", t.hologram);
            yml.set(p + "animation", t.animation); yml.set(p + "broadcast-legendary", t.broadcastLegendary);
            yml.set(p + "remove-on-open", t.removeOnOpen);
            yml.set(p + "shell-rarity", t.shellRarity.name()); yml.set(p + "second-drop-chance", t.secondDropChance);
            yml.set(p + "require-key", t.requireKey); yml.set(p + "pity-threshold", t.pityThreshold);
            yml.set(p + "pity-bonus", t.pityBonusPerFail); yml.set(p + "base-item", toBase64(t.baseItem));
            if (t.keyItem != null) yml.set(p + "key-item", toBase64(t.keyItem));
            List<Map<String,Object>> drops = new ArrayList<>();
            for (DropEntry d : t.drops) {
                Map<String,Object> m = new LinkedHashMap<>();
                m.put("item", toBase64(d.item)); m.put("chance", d.chanceOrWeight);
                m.put("rarity", d.rarity.name()); m.put("min", d.minAmount); m.put("max", d.maxAmount);
                drops.add(m);
            }
            yml.set(p + "drops", drops);
        }
        try { yml.save(templatesFile); } catch (Exception ex) { plugin.getLogger().warning("lootboxes save: " + ex.getMessage()); }
    }

    private void loadAndSpawnInstances() {
        instances.clear();
        if (!instancesFile.exists()) return;
        FileConfiguration yml = YamlConfiguration.loadConfiguration(instancesFile);
        ConfigurationSection root = yml.getConfigurationSection("instances"); if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key); if (s == null) continue;
            WorldInstance wi = new WorldInstance();
            try { wi.uuid = UUID.fromString(key); } catch (Exception e) { wi.uuid = UUID.randomUUID(); }
            wi.templateId = s.getString("template", "");
            try { wi.worldId = UUID.fromString(s.getString("world", "")); } catch (Exception e) { continue; }
            wi.x = s.getDouble("x"); wi.y = s.getDouble("y"); wi.z = s.getDouble("z");
            wi.yaw = (float) s.getDouble("yaw", 0); wi.usesLeft = s.getInt("uses-left", -1);
            for (String u : s.getStringList("opened-by")) try { wi.openedBy.add(UUID.fromString(u)); } catch (Exception ignored) {}
            if (!templates.containsKey(wi.templateId)) continue;
            instances.put(wi.uuid, wi); spawnVisuals(wi);
        }
    }

    private void saveInstances() {
        YamlConfiguration yml = new YamlConfiguration();
        for (WorldInstance wi : instances.values()) {
            String p = "instances." + wi.uuid + ".";
            yml.set(p + "template", wi.templateId); yml.set(p + "world", wi.worldId.toString());
            yml.set(p + "x", wi.x); yml.set(p + "y", wi.y); yml.set(p + "z", wi.z); yml.set(p + "yaw", wi.yaw);
            yml.set(p + "uses-left", wi.usesLeft);
            List<String> opened = new ArrayList<>(); for (UUID u : wi.openedBy) opened.add(u.toString());
            yml.set(p + "opened-by", opened);
        }
        try { yml.save(instancesFile); } catch (Exception ex) { plugin.getLogger().warning("instances save: " + ex.getMessage()); }
    }

    private String sanitizeId(String raw) {
        if (raw == null) return "";
        return raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_\\-]", "");
    }
    private Integer parseInt(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return null; } }
    private List<String> prefix(String p, String... opts) {
        List<String> out = new ArrayList<>(); String pl = p == null ? "" : p.toLowerCase(Locale.ROOT);
        for (String o : opts) if (o.toLowerCase(Locale.ROOT).startsWith(pl)) out.add(o); return out;
    }

    // ===== COMMAND =====
    public boolean handleCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("tactic.lootbox.admin")) {
            sender.sendMessage("§cНет прав (tactic.lootbox.admin)."); return true;
        }
        if (args.length < 1) { sendHelp(sender); return true; }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> {
                if (args.length < 2) { sender.sendMessage("§e/tactic lb create <id> [pumpkin|seasonal]"); return true; }
                String id = sanitizeId(args[1]);
                if (id.isEmpty()) { sender.sendMessage("§cНекорректный id."); return true; }
                if (templates.containsKey(id)) { sender.sendMessage("§cУже существует: " + id); return true; }
                Template t = new Template(); t.id = id; t.displayName = "§6" + id;
                boolean seasonal = args.length >= 3 && (args[2].equalsIgnoreCase("pumpkin")
                        || args[2].equalsIgnoreCase("seasonal") || args[2].equalsIgnoreCase("тыква")
                        || args[2].equalsIgnoreCase("halloween") || args[2].equalsIgnoreCase("хэллоуин"));
                if (seasonal) applyPumpkinSeasonalPreset(t);
                templates.put(id, t); saveTemplates();
                sender.sendMessage("§aШаблон §f" + id + " §aсоздан"
                        + (seasonal ? " §6(тыквенный seasonal)" : "") + "§a. Открываю редактор…");
                if (sender instanceof Player p) openMainEditor(p, id);
            }
            case "edit" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("§cТолько игрок."); return true; }
                if (args.length < 2) { sender.sendMessage("§e/tactic lb edit <id>"); return true; }
                String id = sanitizeId(args[1]);
                if (!templates.containsKey(id)) { sender.sendMessage("§cНет шаблона: " + id); return true; }
                openMainEditor(p, id);
            }
            case "list" -> {
                if (templates.isEmpty()) { sender.sendMessage("§7Шаблонов нет."); return true; }
                sender.sendMessage("§6§lЛутбоксы §7(" + templates.size() + "):");
                for (Template t : templates.values()) {
                    long cnt = instances.values().stream().filter(i -> t.id.equals(i.templateId)).count();
                    sender.sendMessage(" §e" + t.id + " §7— " + t.displayName + " §8[" + t.kind + "/" + t.useMode
                            + (t.removeOnOpen ? "/vanish" : "") + "] §7дропов:§f"
                            + t.drops.size() + " §7в мире:§f" + cnt);
                }
            }
            case "delete" -> {
                if (args.length < 2) { sender.sendMessage("§e/tactic lb delete <id>"); return true; }
                String id = sanitizeId(args[1]);
                Template rem = templates.remove(id);
                if (rem == null) { sender.sendMessage("§cНет шаблона: " + id); return true; }
                List<UUID> toKill = new ArrayList<>();
                for (WorldInstance wi : instances.values()) if (id.equals(wi.templateId)) toKill.add(wi.uuid);
                for (UUID u : toKill) { WorldInstance wi = instances.remove(u); if (wi != null) despawnVisuals(wi, true); }
                saveTemplates(); saveInstances();
                sender.sendMessage("§aУдалён §f" + id + " §7и §f" + toKill.size() + " §7инстансов.");
            }
            case "give" -> {
                if (args.length < 2) { sender.sendMessage("§e/tactic lb give <id> [игрок] [кол-во]"); return true; }
                String id = sanitizeId(args[1]); Template t = templates.get(id);
                if (t == null) { sender.sendMessage("§cНет шаблона: " + id); return true; }
                Player target; int amount = 1;
                if (args.length >= 3) {
                    target = Bukkit.getPlayerExact(args[2]);
                    if (target == null) { sender.sendMessage("§cИгрок не найден."); return true; }
                    if (args.length >= 4) { Integer a = parseInt(args[3]); if (a != null) amount = Math.max(1, Math.min(64, a)); }
                } else if (sender instanceof Player p) target = p;
                else { sender.sendMessage("§cУкажите игрока."); return true; }
                ItemStack place = createPlaceItem(t); place.setAmount(amount);
                target.getInventory().addItem(place);
                sender.sendMessage("§aВыдано §fx" + amount + " §aпредметов §f" + id + " §a→ §f" + target.getName());
                if (!target.equals(sender)) target.sendMessage("§aВы получили предмет размещения: " + t.displayName);
            }
            case "spawn" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("§cТолько игрок."); return true; }
                if (args.length < 2) { sender.sendMessage("§e/tactic lb spawn <id>"); return true; }
                String id = sanitizeId(args[1]); Template t = templates.get(id);
                if (t == null) { sender.sendMessage("§cНет шаблона: " + id); return true; }
                RayTraceResult rt = p.rayTraceBlocks(6.0);
                Location loc;
                if (rt != null && rt.getHitBlock() != null) {
                    Block b = rt.getHitBlock(); BlockFace face = rt.getHitBlockFace() != null ? rt.getHitBlockFace() : BlockFace.UP;
                    loc = b.getRelative(face).getLocation().add(0.5, 0.0, 0.5);
                } else loc = p.getLocation().getBlock().getLocation().add(0.5, 0.0, 0.5);
                loc.setYaw(p.getLocation().getYaw());
                WorldInstance wi = spawnInstance(t, loc);
                sender.sendMessage("§aИнстанс §f" + t.id + " §aустановлен §7(" + wi.uuid.toString().substring(0, 8) + "…)");
            }
            case "remove" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("§cТолько игрок."); return true; }
                WorldInstance near = findNearest(p.getLocation(), 4.0);
                if (near == null) { sender.sendMessage("§cРядом нет лутбокса (≤4 блоков)."); return true; }
                instances.remove(near.uuid); despawnVisuals(near, true); saveInstances();
                sender.sendMessage("§aУдалён инстанс §f" + near.templateId);
            }
            case "test" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("§cТолько игрок."); return true; }
                if (args.length < 2) { sender.sendMessage("§e/tactic lb test <id> [N]"); return true; }
                String id = sanitizeId(args[1]); Template t = templates.get(id);
                if (t == null) { sender.sendMessage("§cНет шаблона: " + id); return true; }
                int n = 1; if (args.length >= 3) { Integer a = parseInt(args[2]); if (a != null) n = Math.max(1, Math.min(100, a)); }
                Map<String, Integer> hist = new LinkedHashMap<>();
                int totalItems = 0;
                for (int i = 0; i < n; i++) {
                    List<ItemStack> got = rollDrops(t, p, true);
                    for (ItemStack it : got) {
                        String name = itemLabel(it); hist.merge(name + " x" + it.getAmount(), 1, Integer::sum); totalItems++;
                    }
                    if (got.isEmpty()) hist.merge("§8(пусто)", 1, Integer::sum);
                }
                p.sendMessage("§6§lТест §f" + t.id + " §7×" + n + " §8| предметов: " + totalItems);
                hist.entrySet().stream().sorted((a,b)->Integer.compare(b.getValue(), a.getValue())).limit(40)
                        .forEach(e -> p.sendMessage(" §7" + e.getValue() + "× §f" + e.getKey()));
            }
            case "reload" -> {
                for (WorldInstance wi : instances.values()) despawnVisuals(wi, false);
                loadTemplates();
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    loadAndSpawnInstances();
                    sender.sendMessage("§aЛутбоксы перезагружены. Шаблонов: §f" + templates.size() + "§a, инстансов: §f" + instances.size());
                }, 5L);
            }
            case "help", "?" -> sendHelp(sender);
            default -> { sender.sendMessage("§cНеизвестно: " + sub); sendHelp(sender); }
        }
        return true;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage("§6§l/tactic lb §7— лутбоксы / кейсы (админ)");
        s.sendMessage(" §ecreate <id> [pumpkin] §8| §eedit <id> §8| §elist §8| §edelete <id>");
        s.sendMessage(" §egive <id> [игрок] [n] §8| §espawn <id> §8| §eremove");
        s.sendMessage(" §etest <id> [N] §8| §ereload");
        s.sendMessage(" §7Размещение: Shift+ПКМ предметом или §f/tactic lb spawn");
        s.sendMessage(" §7Сбор инстанса: Shift+ПКМ (админ) по нему");
        s.sendMessage(" §7Тип CASE/LOOTBOX — только в настройках, игрокам не показывается");
        s.sendMessage(" §7Одноразовый: ONCE_* + «Убрать из мира»; шаблон при открытии не удаляется");
    }

    public List<String> tabComplete(CommandSender sender, String[] args) {
        if (!sender.hasPermission("tactic.lootbox.admin")) return List.of();
        if (args.length == 1) return prefix(args[0], "create","edit","list","delete","give","spawn","remove","test","reload","help");
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && List.of("edit","delete","give","spawn","test").contains(sub)) {
            return prefix(args[1], templates.keySet().toArray(new String[0]));
        }
        if (args.length == 2 && "create".equals(sub)) {
            return prefix(args[1], "pumpkin_crate", "halloween", "seasonal_box");
        }
        if (args.length == 3 && "create".equals(sub)) {
            return prefix(args[2], "pumpkin", "seasonal", "halloween", "тыква", "хэллоуин");
        }
        if (args.length == 3 && "give".equals(sub)) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return prefix(args[2], names.toArray(new String[0]));
        }
        if (args.length == 3 && "test".equals(sub)) return prefix(args[2], "1","5","10","25","50","100");
        if (args.length == 4 && "give".equals(sub)) return prefix(args[3], "1","8","16","32","64");
        return List.of();
    }

    private String itemLabel(ItemStack it) {
        if (it == null) return "?";
        ItemMeta m = it.getItemMeta();
        if (m != null && m.hasDisplayName()) return m.getDisplayName();
        return it.getType().name().toLowerCase(Locale.ROOT);
    }

    /** Сезонный тыквенный лутбокс: оранжевая оболочка, weighted, once_per_player, сезонные дропы. */
    private void applyPumpkinSeasonalPreset(Template t) {
        t.displayName = "§6§l🎃 Тыквенный сундук";
        t.baseItem = new ItemStack(Material.JACK_O_LANTERN);
        t.kind = BoxKind.CASE;
        t.rollMode = RollMode.WEIGHTED;
        t.useMode = UseMode.ONCE_PER_PLAYER;
        t.removeOnOpen = true;
        t.hologram = true;
        t.animation = true;
        t.broadcastLegendary = true;
        t.shellRarity = Rarity.LEGENDARY;
        t.secondDropChance = 12.0;
        t.drops.clear();
        // seasonal table
        t.drops.add(dropOf(Material.PUMPKIN_PIE, 28, Rarity.COMMON, 1, 2));
        t.drops.add(dropOf(Material.CANDLE, 18, Rarity.COMMON, 2, 4));
        t.drops.add(dropOf(Material.JACK_O_LANTERN, 14, Rarity.UNCOMMON, 1, 1));
        t.drops.add(dropOf(Material.COPPER_NUGGET, 12, Rarity.UNCOMMON, 2, 5)); // «конфеты»
        t.drops.add(dropOf(Material.GOLDEN_CARROT, 10, Rarity.UNCOMMON, 1, 3));
        t.drops.add(dropOf(Material.EXPERIENCE_BOTTLE, 8, Rarity.RARE, 2, 6));
        t.drops.add(dropOf(Material.GOLDEN_APPLE, 5, Rarity.RARE, 1, 1));
        t.drops.add(dropOf(Material.ENDER_PEARL, 4, Rarity.EPIC, 1, 2));
        ItemStack spooky = new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 1);
        DropEntry leg = new DropEntry();
        leg.item = spooky; leg.chanceOrWeight = 1.5; leg.rarity = Rarity.LEGENDARY;
        leg.minAmount = 1; leg.maxAmount = 1;
        t.drops.add(leg);
    }

    private DropEntry dropOf(Material mat, double w, Rarity r, int min, int max) {
        DropEntry d = new DropEntry();
        d.item = new ItemStack(mat);
        d.chanceOrWeight = w;
        d.rarity = r;
        d.minAmount = min;
        d.maxAmount = max;
        return d;
    }

    public ItemStack createPlaceItem(Template t) {
        ItemStack stack = t.baseItem == null ? new ItemStack(Material.CHEST) : t.baseItem.clone();
        stack.setAmount(1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(t.displayName);
            List<String> lore = new ArrayList<>();
            lore.add("§8Предмет размещения");
            lore.add("§7Shift + ПКМ по блоку — установить");
            lore.add("§8ID: §7" + t.id);
            meta.setLore(lore);
            meta.getPersistentDataContainer().set(keyTemplateId, PersistentDataType.STRING, t.id);
            meta.getPersistentDataContainer().set(keyItemFlag, PersistentDataType.BYTE, (byte) 1);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private WorldInstance spawnInstance(Template t, Location loc) {
        WorldInstance wi = new WorldInstance();
        wi.uuid = UUID.randomUUID(); wi.templateId = t.id;
        wi.worldId = loc.getWorld().getUID(); wi.x = loc.getX(); wi.y = loc.getY(); wi.z = loc.getZ(); wi.yaw = loc.getYaw();
        wi.usesLeft = t.useMode == UseMode.USES ? t.maxUses : -1;
        instances.put(wi.uuid, wi); spawnVisuals(wi); saveInstances(); return wi;
    }

    private Location instLoc(WorldInstance wi) {
        World w = Bukkit.getWorld(wi.worldId); if (w == null) return null;
        Location l = new Location(w, wi.x, wi.y, wi.z); l.setYaw(wi.yaw); return l;
    }

    private void spawnVisuals(WorldInstance wi) {
        despawnVisuals(wi, false);
        Template t = templates.get(wi.templateId); if (t == null) return;
        Location loc = instLoc(wi); if (loc == null || loc.getWorld() == null) return;
        Location standLoc = loc.clone();
        ArmorStand stand = loc.getWorld().spawn(standLoc, ArmorStand.class, as -> {
            as.setVisible(false); as.setGravity(false); as.setMarker(false); as.setSmall(true);
            as.setBasePlate(false); as.setArms(false); as.setInvulnerable(true); as.setSilent(true);
            as.setCustomNameVisible(false); as.setCollidable(false);
            as.getPersistentDataContainer().set(keyInst, PersistentDataType.STRING, wi.uuid.toString());
        });
        wi.standUuid = stand.getUniqueId();
        // модель смотрит в сторону yaw постановки (лицо к поставившему, если spawn от игрока)
        Location dispLoc = loc.clone().add(0, 0.55, 0);
        dispLoc.setYaw(wi.yaw);
        dispLoc.setPitch(0f);
        ItemStack show = t.baseItem == null ? new ItemStack(Material.CHEST) : t.baseItem.clone();
        show.setAmount(1);
        float yawRad = (float) Math.toRadians(wi.yaw);
        // ItemDisplay local +Z often needs 180 offset so "front" faces placer
        AxisAngle4f rotY = new AxisAngle4f(yawRad + (float) Math.PI, 0f, 1f, 0f);
        ItemDisplay disp = loc.getWorld().spawn(dispLoc, ItemDisplay.class, d -> {
            d.setItemStack(show);
            d.setBillboard(ItemDisplay.Billboard.FIXED);
            d.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    rotY,
                    new Vector3f(1.05f, 1.05f, 1.05f),
                    new AxisAngle4f(0f, 0f, 1f, 0f)));
            d.setInterpolationDuration(0); d.setTeleportDuration(2);
            d.setBrightness(new ItemDisplay.Brightness(12, 12));
            d.getPersistentDataContainer().set(keyInst, PersistentDataType.STRING, wi.uuid.toString());
        });
        wi.displayUuid = disp.getUniqueId();
        if (t.hologram) {
            Location hLoc = loc.clone().add(0, 1.45, 0);
            ArmorStand holo = loc.getWorld().spawn(hLoc, ArmorStand.class, as -> {
                as.setVisible(false); as.setGravity(false); as.setMarker(true); as.setSmall(true);
                as.setBasePlate(false); as.setInvulnerable(true); as.setSilent(true);
                as.setCustomName(prettyHolo(t)); as.setCustomNameVisible(true); as.setCollidable(false);
                as.getPersistentDataContainer().set(keyInst, PersistentDataType.STRING, wi.uuid.toString());
            });
            wi.holoUuid = holo.getUniqueId();
        }
        // мягкий place-burst
        try {
            spawnOpenBurst(loc.getWorld(), loc.clone().add(0, 0.6, 0), t.shellRarity, 0.6f);
        } catch (Throwable ignored) {}
    }

    private String prettyHolo(Template t) {
        return t.shellRarity.color + "✦ " + t.displayName + t.shellRarity.color + " ✦";
    }

    private void despawnVisuals(WorldInstance wi, boolean removeEntity) {
        for (UUID u : new UUID[]{wi.standUuid, wi.displayUuid, wi.holoUuid}) {
            if (u == null) continue;
            Entity e = Bukkit.getEntity(u); if (e != null) e.remove();
        }
        wi.standUuid = wi.displayUuid = wi.holoUuid = null;
        if (removeEntity) {
            // also scavenge by PDC in chunk
            Location loc = instLoc(wi);
            if (loc != null && loc.getWorld() != null) {
                for (Entity e : loc.getWorld().getNearbyEntities(loc, 2.5, 3.0, 2.5)) {
                    String id = e.getPersistentDataContainer().get(keyInst, PersistentDataType.STRING);
                    if (wi.uuid.toString().equals(id)) e.remove();
                }
            }
        }
    }

    private WorldInstance findNearest(Location loc, double r) {
        WorldInstance best = null; double bestD = r * r;
        for (WorldInstance wi : instances.values()) {
            if (!wi.worldId.equals(loc.getWorld().getUID())) continue;
            double dx = wi.x - loc.getX(), dy = wi.y - loc.getY(), dz = wi.z - loc.getZ();
            double d = dx*dx + dy*dy + dz*dz;
            if (d <= bestD) { bestD = d; best = wi; }
        }
        return best;
    }

    private WorldInstance byEntity(Entity e) {
        String id = e.getPersistentDataContainer().get(keyInst, PersistentDataType.STRING);
        if (id == null) return null;
        try { return instances.get(UUID.fromString(id)); } catch (Exception ex) { return null; }
    }

    // ===== ROLL =====
    private List<ItemStack> rollDrops(Template t, Player p, boolean test) {
        List<ItemStack> out = new ArrayList<>();
        if (t.drops.isEmpty()) return out;
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        if (t.rollMode == RollMode.WEIGHTED) {
            DropEntry pick = pickWeighted(t, p, rng);
            if (pick != null) {
                out.add(amounted(pick, rng));
                maybeBroadcast(t, p, pick, test);
                if (!test) bumpPity(p, t, pick);
            }
            if (t.secondDropChance > 0 && rng.nextDouble() * 100.0 < t.secondDropChance) {
                DropEntry pick2 = pickWeighted(t, p, rng);
                if (pick2 != null) {
                    out.add(amounted(pick2, rng));
                    maybeBroadcast(t, p, pick2, test);
                }
            }
        } else {
            double pityBonus = 0;
            if (!test && t.pityThreshold > 0) {
                int fails = pityByKey.getOrDefault(pityStr(p, t), 0);
                if (fails >= t.pityThreshold) pityBonus = t.pityBonusPerFail * (fails - t.pityThreshold + 1);
            }
            boolean anyHigh = false;
            for (DropEntry d : t.drops) {
                double chance = d.chanceOrWeight + (d.rarity.ordinal() >= Rarity.EPIC.ordinal() ? pityBonus : 0);
                if (rng.nextDouble() * 100.0 < chance) {
                    out.add(amounted(d, rng));
                    maybeBroadcast(t, p, d, test);
                    if (d.rarity == Rarity.LEGENDARY || d.rarity == Rarity.EPIC) anyHigh = true;
                }
            }
            if (!test) {
                if (anyHigh) pityByKey.remove(pityStr(p, t));
                else pityByKey.merge(pityStr(p, t), 1, Integer::sum);
            }
        }
        return out;
    }


    private String pityStr(Player p, Template t) { return p.getUniqueId() + ":" + t.id; }
    private void bumpPity(Player p, Template t, DropEntry pick) {
        if (t.pityThreshold <= 0) return;
        if (pick.rarity == Rarity.LEGENDARY || pick.rarity == Rarity.EPIC) pityByKey.remove(pityStr(p, t));
        else pityByKey.merge(pityStr(p, t), 1, Integer::sum);
    }

    private DropEntry pickWeighted(Template t, Player p, ThreadLocalRandom rng) {
        double pityBonus = 0;
        if (t.pityThreshold > 0) {
            int fails = pityByKey.getOrDefault(pityStr(p, t), 0);
            if (fails >= t.pityThreshold) pityBonus = t.pityBonusPerFail * (fails - t.pityThreshold + 1);
        }
        double total = 0;
        double[] weights = new double[t.drops.size()];
        for (int i = 0; i < t.drops.size(); i++) {
            DropEntry d = t.drops.get(i);
            double w = Math.max(0.0001, d.chanceOrWeight);
            if (d.rarity.ordinal() >= Rarity.EPIC.ordinal()) w += pityBonus;
            weights[i] = w; total += w;
        }
        if (total <= 0) return null;
        double r = rng.nextDouble() * total, acc = 0;
        for (int i = 0; i < weights.length; i++) {
            acc += weights[i];
            if (r <= acc) return t.drops.get(i);
        }
        return t.drops.get(t.drops.size() - 1);
    }

    private ItemStack amounted(DropEntry d, ThreadLocalRandom rng) {
        ItemStack it = d.item.clone();
        int min = Math.max(1, d.minAmount), max = Math.max(min, d.maxAmount);
        it.setAmount(min == max ? min : rng.nextInt(min, max + 1));
        return it;
    }

    private void maybeBroadcast(Template t, Player p, DropEntry d, boolean test) {
        if (test || !t.broadcastLegendary || d.rarity != Rarity.LEGENDARY) return;
        String name = itemLabel(d.item);
        Bukkit.broadcastMessage("§6§l✦ §e" + p.getName() + " §6выбил §e" + name + " §6из §r" + t.displayName + "§6!");
    }

    // ===== OPEN =====
    private void tryOpen(Player p, WorldInstance wi) {
        if (Boolean.TRUE.equals(openingAnim.get(p.getUniqueId()))) {
            p.sendMessage("§cПодождите окончания анимации."); return;
        }
        Template t = templates.get(wi.templateId);
        if (t == null) { p.sendMessage("§cШаблон удалён."); return; }

        if (p.isSneaking() && p.hasPermission("tactic.lootbox.admin")) {
            // admin pickup
            instances.remove(wi.uuid); despawnVisuals(wi, true); saveInstances();
            p.getInventory().addItem(createPlaceItem(t));
            p.sendMessage("§aИнстанс подобран: §f" + t.id);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1.2f);
            return;
        }

        // use limits
        switch (t.useMode) {
            case ONCE_PER_PLAYER -> {
                if (wi.openedBy.contains(p.getUniqueId())) {
                    p.sendMessage("§cВы уже открывали это."); return;
                }
            }
            case ONCE_GLOBAL -> {
                if (!wi.openedBy.isEmpty() || wi.usesLeft == 0) {
                    p.sendMessage("§cУже было открыто."); return;
                }
            }
            case USES -> {
                if (wi.usesLeft == 0) { p.sendMessage("§cЗаряды закончились."); return; }
            }
            case INFINITE -> { }
        }

        if (t.cooldownSec > 0) {
            String ck = p.getUniqueId() + ":" + t.id;
            Long u2 = cdMap.get(ck);
            long now = System.currentTimeMillis();
            if (u2 != null && u2 > now) {
                long sec = (u2 - now + 999) / 1000;
                p.sendMessage("§cКулдаун: §f" + sec + "с"); return;
            }
        }

        if (t.requireKey && t.keyItem != null) {
            if (!consumeKey(p, t.keyItem)) {
                p.sendMessage("§cНужен ключ."); return;
            }
        }

        // mark usage
        wi.openedBy.add(p.getUniqueId());
        if (t.useMode == UseMode.USES && wi.usesLeft > 0) wi.usesLeft--;
        if (t.useMode == UseMode.ONCE_GLOBAL) wi.usesLeft = 0;
        if (t.cooldownSec > 0) cdMap.put(p.getUniqueId() + ":" + t.id, System.currentTimeMillis() + t.cooldownSec * 1000L);
        saveInstances();

        List<ItemStack> rewards = rollDrops(t, p, false);
        if (t.animation) {
            openingAnim.put(p.getUniqueId(), true);
            playOpenAnimation(p, wi, t, rewards);
        } else {
            deliver(p, wi, t, rewards);
        }
    }

    private boolean consumeKey(Player p, ItemStack key) {
        ItemStack[] cont = p.getInventory().getContents();
        for (int i = 0; i < cont.length; i++) {
            ItemStack it = cont[i];
            if (it == null) continue;
            if (it.isSimilar(key)) {
                int am = it.getAmount();
                if (am <= 1) p.getInventory().setItem(i, null);
                else it.setAmount(am - 1);
                return true;
            }
        }
        return false;
    }

    private void deliver(Player p, WorldInstance wi, Template t, List<ItemStack> rewards) {
        Location loc = instLoc(wi);
        if (rewards.isEmpty()) {
            p.sendMessage("§8✦ §7Пусто... в этот раз фортуна молчит.");
            if (loc != null) p.playSound(loc, Sound.BLOCK_CHEST_CLOSE, 1f, 0.8f);
        } else {
            p.sendMessage("§6§l✦ §eДобыча из §r" + t.displayName + "§e:");
            for (ItemStack it : rewards) {
                p.sendMessage(" §6› §f" + itemLabel(it) + " §7×§e" + it.getAmount());
                Map<Integer, ItemStack> overflow = p.getInventory().addItem(it);
                if (loc != null) for (ItemStack left : overflow.values()) loc.getWorld().dropItemNaturally(loc.clone().add(0, 1, 0), left);
            }
            if (loc != null) {
                p.playSound(loc, Sound.BLOCK_CHEST_OPEN, 1f, 1.1f);
                p.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
            }
            p.sendActionBar("§6✦ §e" + t.displayName + " §7· §f" + rewards.size() + " §7предмет(ов)");
        }
        // Шаблон НИКОГДА не удаляется при открытии — только мировой инстанс по флагу removeOnOpen.
        if (shouldRemoveInstance(t, wi)) {
            instances.remove(wi.uuid);
            despawnVisuals(wi, true);
            saveInstances();
        } else if (isInstanceGloballySpent(t, wi)) {
            refreshHologram(wi, t, true);
            saveInstances();
        }
        openingAnim.remove(p.getUniqueId());
    }

    private boolean isInstanceGloballySpent(Template t, WorldInstance wi) {
        return switch (t.useMode) {
            case ONCE_GLOBAL -> true;
            case USES -> wi.usesLeft == 0;
            default -> false;
        };
    }

    /** Убрать инстанс из мира. templates / lootboxes.yml не трогаем. */
    private boolean shouldRemoveInstance(Template t, WorldInstance wi) {
        if (!t.removeOnOpen) return false;
        return switch (t.useMode) {
            case ONCE_GLOBAL, ONCE_PER_PLAYER, INFINITE -> true;
            case USES -> wi.usesLeft == 0;
        };
    }

    private void refreshHologram(WorldInstance wi, Template t, boolean spent) {
        if (wi.holoUuid == null) return;
        Entity e = Bukkit.getEntity(wi.holoUuid);
        if (!(e instanceof ArmorStand as)) return;
        if (spent) as.setCustomName("§8§m" + ChatColor.stripColor(t.displayName) + " §7· открыто");
        else as.setCustomName(prettyHolo(t));
        as.setCustomNameVisible(true);
    }

    private void playOpenAnimation(Player p, WorldInstance wi, Template t, List<ItemStack> rewards) {
        Location loc = instLoc(wi);
        if (loc == null) { deliver(p, wi, t, rewards); return; }
        World w = loc.getWorld();
        Rarity shell = t.shellRarity;
        Location center = loc.clone().add(0, 0.7, 0);
        w.playSound(loc, Sound.BLOCK_CHEST_OPEN, 0.9f, 0.85f);
        w.playSound(loc, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.55f, 1.25f);
        // спираль + кольца
        for (int i = 0; i < 16; i++) {
            final int step = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline()) return;
                double ang = step * (Math.PI / 8.0);
                double rr = 0.35 + step * 0.07;
                double y = 0.25 + step * 0.07;
                Location pl = loc.clone().add(Math.cos(ang) * rr, y, Math.sin(ang) * rr);
                spawnRarityParticle(w, pl, shell, 4);
                spawnOrangeSpark(w, pl, 2);
                if (step % 2 == 0) {
                    Location pl2 = loc.clone().add(Math.cos(ang + Math.PI) * rr * 0.7, y * 0.9, Math.sin(ang + Math.PI) * rr * 0.7);
                    spawnOrangeSpark(w, pl2, 2);
                }
                if (step % 4 == 0) w.playSound(loc, Sound.BLOCK_NOTE_BLOCK_CHIME, 0.45f, 0.85f + step * 0.04f);
                if (step == 15) {
                    spawnOpenBurst(w, center, shell, 1.25f);
                    w.playSound(loc, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.95f, 1.05f);
                    w.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 0.55f, 1.35f);
                    try {
                        w.spawnParticle(Particle.FLASH, center, 1, 0, 0, 0, 0);
                    } catch (Throwable ignored) {}
                    deliver(p, wi, t, rewards);
                }
            }, i * 2L);
        }
    }

    private void spawnOpenBurst(World w, Location center, Rarity r, float power) {
        if (w == null || center == null) return;
        int n = (int) (48 * power);
        for (int i = 0; i < n; i++) {
            double yaw = ThreadLocalRandom.current().nextDouble() * Math.PI * 2;
            double pitch = ThreadLocalRandom.current().nextDouble() * Math.PI - Math.PI / 2;
            double speed = 0.12 * power + ThreadLocalRandom.current().nextDouble() * 0.38 * power;
            double vx = Math.cos(pitch) * Math.cos(yaw) * speed;
            double vy = Math.sin(pitch) * speed * 0.9 + 0.06;
            double vz = Math.cos(pitch) * Math.sin(yaw) * speed;
            // rarity dust
            Color rc = Color.fromRGB((r.rgb >> 16) & 0xFF, (r.rgb >> 8) & 0xFF, r.rgb & 0xFF);
            try {
                w.spawnParticle(Particle.DUST, center, 0, vx, vy, vz, 1.0, new Particle.DustOptions(rc, 1.1f + ThreadLocalRandom.current().nextFloat() * 0.6f));
            } catch (Throwable ignored) {}
            // pumpkin orange always
            spawnOrangeSparkVel(w, center, vx * 0.9, vy * 0.9, vz * 0.9);
        }
        // core clouds
        try {
            var core = new Particle.DustOptions(Color.fromRGB(255, 145, 25), 1.4f);
            var rim = new Particle.DustOptions(Color.fromRGB(255, 190, 60), 1.15f);
            w.spawnParticle(Particle.DUST, center, (int)(36 * power), 0.35, 0.35, 0.35, 0.01, core);
            w.spawnParticle(Particle.DUST, center, (int)(24 * power), 0.55, 0.45, 0.55, 0.01, rim);
        } catch (Throwable ignored) {}
        try { w.spawnParticle(Particle.FLAME, center, (int)(16 * power), 0.3, 0.25, 0.3, 0.02); } catch (Throwable ignored) {}
        try { w.spawnParticle(Particle.LAVA, center, (int)(5 * power), 0.2, 0.15, 0.2, 0); } catch (Throwable ignored) {}
        try { w.spawnParticle(Particle.FIREWORK, center, (int)(25 * power), 0.35, 0.4, 0.35, 0.05); } catch (Throwable ignored) {}
        switch (r) {
            case LEGENDARY -> {
                try { w.spawnParticle(Particle.TOTEM_OF_UNDYING, center, 18, 0.4, 0.5, 0.4, 0.08); } catch (Throwable ignored) {}
                try { w.spawnParticle(Particle.END_ROD, center, 12, 0.3, 0.4, 0.3, 0.02); } catch (Throwable ignored) {}
            }
            case EPIC -> { try { w.spawnParticle(Particle.PORTAL, center, 30, 0.4, 0.5, 0.4, 0.4); } catch (Throwable ignored) {} }
            case RARE -> { try { w.spawnParticle(Particle.ENCHANT, center, 25, 0.4, 0.5, 0.4, 0.5); } catch (Throwable ignored) {} }
            default -> { }
        }
    }

    private void spawnOrangeSpark(World w, Location loc, int count) {
        if (w == null || loc == null) return;
        Color[] palette = new Color[] {
                Color.fromRGB(255, 110, 0), Color.fromRGB(255, 140, 20), Color.fromRGB(255, 165, 0),
                Color.fromRGB(255, 185, 45), Color.fromRGB(255, 200, 70), Color.fromRGB(230, 90, 0)
        };
        for (int i = 0; i < count; i++) {
            Color c = palette[ThreadLocalRandom.current().nextInt(palette.length)];
            try {
                w.spawnParticle(Particle.DUST, loc, 2, 0.06, 0.06, 0.06, 0.0, new Particle.DustOptions(c, 1.0f + ThreadLocalRandom.current().nextFloat() * 0.5f));
            } catch (Throwable ignored) {}
        }
    }

    private void spawnOrangeSparkVel(World w, Location center, double vx, double vy, double vz) {
        Color[] palette = new Color[] {
                Color.fromRGB(255, 120, 0), Color.fromRGB(255, 150, 25), Color.fromRGB(255, 175, 40), Color.fromRGB(255, 200, 70)
        };
        Color c = palette[ThreadLocalRandom.current().nextInt(palette.length)];
        try {
            w.spawnParticle(Particle.DUST, center, 0, vx, vy, vz, 1.0, new Particle.DustOptions(c, 1.15f + ThreadLocalRandom.current().nextFloat() * 0.55f));
        } catch (Throwable ignored) {}
    }

    private void spawnRarityParticle(World w, Location loc, Rarity r, int count) {
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB((r.rgb >> 16) & 0xFF, (r.rgb >> 8) & 0xFF, r.rgb & 0xFF), 1.2f);
        w.spawnParticle(Particle.DUST, loc, count, 0.05, 0.05, 0.05, 0, dust);
        spawnOrangeSpark(w, loc, Math.max(1, count / 2));
        switch (r) {
            case LEGENDARY -> w.spawnParticle(Particle.FLAME, loc, 2, 0.1, 0.1, 0.1, 0.01);
            case EPIC -> w.spawnParticle(Particle.PORTAL, loc, 4, 0.15, 0.15, 0.15, 0.1);
            case RARE -> w.spawnParticle(Particle.ENCHANT, loc, 3, 0.2, 0.2, 0.2, 0.3);
            case UNCOMMON -> w.spawnParticle(Particle.HAPPY_VILLAGER, loc, 2, 0.1, 0.1, 0.1, 0);
            default -> w.spawnParticle(Particle.CRIT, loc, 1, 0.05, 0.05, 0.05, 0);
        }
    }

    private void tickFx() {
        long tick = System.currentTimeMillis() / 50;
        for (WorldInstance wi : instances.values()) {
            Template t = templates.get(wi.templateId); if (t == null) continue;
            Location loc = instLoc(wi); if (loc == null || loc.getWorld() == null) continue;
            if (loc.getWorld().getPlayers().stream().noneMatch(p -> p.getLocation().distanceSquared(loc) < 28 * 28)) continue;
            // idle: double orbit + soft bob (без вращения модели — сохраняем взгляд на создателя)
            double ang = (tick % 50) / 50.0 * Math.PI * 2;
            double bob = Math.sin(tick / 10.0) * 0.06;
            Location pl = loc.clone().add(Math.cos(ang) * 0.62, 0.78 + bob, Math.sin(ang) * 0.62);
            spawnRarityParticle(loc.getWorld(), pl, t.shellRarity, 1);
            if (tick % 2 == 0) {
                Location pl2 = loc.clone().add(Math.cos(ang + Math.PI) * 0.45, 0.55 + bob * 0.5, Math.sin(ang + Math.PI) * 0.45);
                spawnOrangeSpark(loc.getWorld(), pl2, 1);
            }
            // лёгкий «огонёк» сверху
            if (tick % 5 == 0) {
                try {
                    loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 1.05 + bob, 0), 1, 0.02, 0.02, 0.02, 0.0);
                } catch (Throwable ignored) {}
            }
        }
    }

    // ===== EVENTS =====
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        WorldInstance wi = byEntity(e.getRightClicked());
        if (wi == null) return;
        e.setCancelled(true);
        tryOpen(e.getPlayer(), wi);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractAtEntity(PlayerInteractAtEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        WorldInstance wi = byEntity(e.getRightClicked());
        if (wi == null) return;
        e.setCancelled(true);
        tryOpen(e.getPlayer(), wi);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK
                && e.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR) return;
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand == null || !hand.hasItemMeta()) return;
        ItemMeta meta = hand.getItemMeta();
        Byte flag = meta.getPersistentDataContainer().get(keyItemFlag, PersistentDataType.BYTE);
        if (flag == null || flag != (byte) 1) return;
        String tid = meta.getPersistentDataContainer().get(keyTemplateId, PersistentDataType.STRING);
        if (tid == null) return;
        if (!p.hasPermission("tactic.lootbox.admin")) {
            p.sendMessage("§cТолько администратор может устанавливать.");
            e.setCancelled(true); return;
        }
        if (!p.isSneaking()) {
            p.sendMessage("§eЗажмите Shift + ПКМ, чтобы установить.");
            e.setCancelled(true); return;
        }
        Template t = templates.get(tid);
        if (t == null) { p.sendMessage("§cШаблон не найден: " + tid); e.setCancelled(true); return; }
        e.setCancelled(true);
        Location loc;
        if (e.getClickedBlock() != null) {
            BlockFace face = e.getBlockFace() != null ? e.getBlockFace() : BlockFace.UP;
            loc = e.getClickedBlock().getRelative(face).getLocation().add(0.5, 0.0, 0.5);
        } else {
            loc = p.getLocation().getBlock().getLocation().add(0.5, 0.0, 0.5);
        }
        loc.setYaw(p.getLocation().getYaw());
        spawnInstance(t, loc);
        // consume one
        int am = hand.getAmount();
        if (am <= 1) p.getInventory().setItemInMainHand(null);
        else hand.setAmount(am - 1);
        p.sendMessage("§aУстановлен: §r" + t.displayName);
        p.playSound(loc, Sound.BLOCK_WOOD_PLACE, 1f, 1.1f);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID u = e.getPlayer().getUniqueId();
        editTemplate.remove(u); editMainInv.remove(u); editDropsInv.remove(u); editEntryInv.remove(u);
        editEntryIndex.remove(u); chatWait.remove(u); openingAnim.remove(u);
    }

    // ===== GUI =====
    private static final String TITLE_MAIN = "§8§lЛутбокс §7— настройки";
    private static final String TITLE_DROPS = "§8§lЛутбокс §7— дропы";
    private static final String TITLE_ENTRY = "§8§lЛутбокс §7— дроп";

    private ItemStack pane(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore.length > 0) meta.setLore(Arrays.asList(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            it.setItemMeta(meta);
        }
        return it;
    }

    private void openMainEditor(Player p, String id) {
        Template t = templates.get(id); if (t == null) return;
        editTemplate.put(p.getUniqueId(), id);
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_MAIN);
        ItemStack glass = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);

        // slot 13 — base item
        ItemStack base = t.baseItem == null ? new ItemStack(Material.CHEST) : t.baseItem.clone();
        ItemMeta bm = base.getItemMeta();
        if (bm != null) {
            List<String> lore = bm.hasLore() && bm.getLore() != null ? new ArrayList<>(bm.getLore()) : new ArrayList<>();
            lore.add("§8---");
            lore.add("§eЛКМ предметом на курсоре §7— назначить вид");
            lore.add("§eShift+ЛКМ из своего инвентаря §7— тоже");
            lore.add("§eПКМ §7— сбросить на сундук");
            lore.add("§8Определение: §7модель/предмет, который");
            lore.add("§7игроки видят в мире и как place-item.");
            bm.setLore(lore);
            if (!bm.hasDisplayName()) bm.setDisplayName(t.displayName);
            base.setItemMeta(bm);
        }
        inv.setItem(13, base);

        inv.setItem(11, pane(Material.NAME_TAG, "§eНазвание",
                "§7Сейчас: §r" + t.displayName,
                "§eЛКМ §7— ввести в чат (&-цвета)",
                "§8Определение: §7имя над голограммой",
                "§7и в сообщениях при открытии.",
                "§7Игрокам НЕ пишется «кейс/лутбокс»."));

        inv.setItem(15, pane(Material.GOLD_INGOT, "§eРедкость оболочки",
                "§7Сейчас: " + t.shellRarity.label,
                "§eЛКМ §7— следующая  §eПКМ §7— предыдущая",
                "§8Определение: §7цвет idle-частиц вокруг",
                "§7и вспышки при открытии. На дропы",
                "§7не влияет — только «оболочка» бокса."));

        inv.setItem(20, pane(Material.COMPARATOR, "§eРежим ролла",
                "§7Сейчас: §f" + t.rollMode.name(),
                "§eЛКМ §7— WEIGHTED ↔ INDEPENDENT",
                "§8Определение:",
                "§7WEIGHTED — ровно 1 предмет; чем",
                "§7больше «вес», тем чаще выпадает.",
                "§7INDEPENDENT — у каждой строки свой %;",
                "§7может выпасть 0, 1 или несколько."));

        inv.setItem(21, pane(Material.REPEATER, "§eРежим использования",
                "§7Сейчас: §f" + t.useMode.name(),
                "§eЛКМ §7— цикл режимов",
                "§8Определение (сколько раз откроют):",
                "§7INFINITE — безлимит для всех.",
                "§7ONCE_PER_PLAYER — §fодноразово на игрока§7",
                "§7  (другие игроки ещё могут открыть).",
                "§7ONCE_GLOBAL — §fодноразово на сервер§7",
                "§7  (после 1 открытия никто не откроет).",
                "§7USES — общий счётчик зарядов.",
                "§aШаблон от открытий НЕ удаляется."));

        inv.setItem(22, pane(Material.CLOCK, "§eКулдаун (сек)",
                "§7Сейчас: §f" + t.cooldownSec,
                "§eЛКМ §7— ввести  §eShift± §7— ±10",
                "§8Определение: §7пауза для одного игрока",
                "§7перед повторным открытием этого",
                "§7шаблона (0 = без кулдауна)."));

        inv.setItem(23, pane(Material.IRON_INGOT, "§eМакс. использований",
                "§7Сейчас: §f" + t.maxUses,
                "§8Только для режима USES",
                "§eЛКМ §7— ввести  §eShift± §7— ±1",
                "§8Определение: §7сколько раз инстанс",
                "§7можно открыть суммарно всеми."));

        inv.setItem(24, pane(t.kind == BoxKind.CASE ? Material.ENDER_CHEST : Material.CHEST, "§eТип (только админ)",
                "§7Сейчас: §f" + t.kind.name(),
                "§eЛКМ §7— CASE ↔ LOOTBOX",
                "§8Определение: §7метка для админов.",
                "§7Игрокам НЕ показывается.",
                "§7На шаблон и файл не влияет.",
                "§7Исчезновение бокса — кнопка справа."));

        inv.setItem(25, pane(t.removeOnOpen ? Material.TNT : Material.OBSIDIAN,
                t.removeOnOpen ? "§cУбрать из мира: §aВКЛ" : "§eУбрать из мира: §cВЫКЛ",
                "§eЛКМ §7— переключить",
                "§8Определение:",
                "§7ВКЛ — после открытия §fинстанс§7",
                "§7(бокс в мире) исчезает.",
                "§aШаблон §f" + t.id + " §aвсегда остаётся",
                "§7в list/edit — ставь снова через spawn.",
                "§7Одноразовый: ONCE_* + этот флаг ВКЛ."));

        inv.setItem(29, pane(t.hologram ? Material.LIME_DYE : Material.GRAY_DYE, "§eГолограмма",
                "§7Сейчас: " + (t.hologram ? "§aВКЛ" : "§cВЫКЛ"),
                "§eЛКМ §7— переключить",
                "§8Определение: §7имя над боксом",
                "§7(ArmorStand). Без неё — только модель."));

        inv.setItem(30, pane(t.animation ? Material.LIME_DYE : Material.GRAY_DYE, "§eАнимация открытия",
                "§7Сейчас: " + (t.animation ? "§aВКЛ" : "§cВЫКЛ"),
                "§eЛКМ §7— переключить",
                "§8Определение: §7короткая вспышка",
                "§7частиц перед выдачей лута."));

        inv.setItem(31, pane(t.broadcastLegendary ? Material.LIME_DYE : Material.GRAY_DYE, "§eBroadcast легендарки",
                "§7Сейчас: " + (t.broadcastLegendary ? "§aВКЛ" : "§cВЫКЛ"),
                "§eЛКМ §7— переключить",
                "§8Определение: §7глобальное сообщение",
                "§7в чат, если выпал LEGENDARY."));

        inv.setItem(32, pane(Material.EXPERIENCE_BOTTLE, "§eВторой дроп % (weighted)",
                "§7Сейчас: §f" + t.secondDropChance + "%",
                "§eЛКМ §7— ввести 0–100",
                "§8Определение: §7только WEIGHTED.",
                "§7Шанс выдать ещё один предмет",
                "§7поверх основного ролла."));

        ItemStack keyBtn;
        if (t.requireKey && t.keyItem != null) {
            keyBtn = t.keyItem.clone(); keyBtn.setAmount(1);
            ItemMeta km = keyBtn.getItemMeta();
            if (km != null) {
                List<String> kl = new ArrayList<>();
                kl.add("§aКлюч требуется");
                kl.add("§eЛКМ предметом на курсоре §7— заменить");
                kl.add("§eShift+ЛКМ из инвентаря §7— тоже");
                kl.add("§eПКМ §7— выключить");
                kl.add("§8Определение: §7для открытия нужно");
                kl.add("§7иметь isSimilar-предмет; 1 шт. спишется.");
                km.setLore(kl);
                if (!km.hasDisplayName()) km.setDisplayName("§eКлюч");
                keyBtn.setItemMeta(km);
            }
        } else {
            keyBtn = pane(Material.TRIPWIRE_HOOK, "§eКлюч",
                    "§7Сейчас: §cвыкл",
                    "§eЛКМ предметом §7— назначить и включить",
                    "§eShift+ЛКМ из инвентаря §7— тоже",
                    "§eПКМ §7— выкл",
                    "§8Определение: §7опциональный «ключ».",
                    "§7Без ключа открытие бесплатное.");
        }
        inv.setItem(33, keyBtn);

        inv.setItem(38, pane(Material.DIAMOND, "§ePity-порог",
                "§7Сейчас: §f" + t.pityThreshold,
                "§eЛКМ §7— ввести (0 = выкл)",
                "§8Определение: §7после N открытий без",
                "§7EPIC/LEGENDARY начинает копиться",
                "§7бонус к их шансу/весу."));

        inv.setItem(39, pane(Material.EMERALD, "§ePity-бонус за фейл",
                "§7Сейчас: §f" + t.pityBonusPerFail,
                "§eЛКМ §7— ввести",
                "§8Определение: §7сколько добавить к",
                "§7весу/% EPIC+ за каждое «пустое»",
                "§7открытие после порога."));

        inv.setItem(40, pane(Material.CHEST, "§a§lТаблица дропов",
                "§7Записей: §f" + t.drops.size(),
                "§eЛКМ §7— открыть редактор",
                "§8Определение: §7список наград,",
                "§7редкостей и шансов/весов."));

        inv.setItem(41, pane(Material.WRITABLE_BOOK, "§eТест ×10",
                "§7Симуляция 10 открытий → чат",
                "§8Определение: §7не тратит ключи/uses,",
                "§7предметы в инвентарь не выдаёт."));

        inv.setItem(42, pane(Material.ENDER_EYE, "§eВыдать place-item",
                "§7Себе ×1",
                "§8Определение: §7предмет установки.",
                "§7Shift+ПКМ по блоку — поставить."));

        inv.setItem(49, pane(Material.BARRIER, "§cЗакрыть",
                "§7Изменения уже в памяти;",
                "§7на диск — кнопка «Сохранить»."));
        inv.setItem(53, pane(Material.EMERALD_BLOCK, "§a§lСохранить",
                "§7Записать lootboxes.yml",
                "§8Определение: §7persist шаблонов на диск."));

        // hint row
        inv.setItem(4, pane(Material.BOOK, "§6§lСправка",
                "§7Нижний инвентарь §aсвободен§7:",
                "§7можете брать предметы оттуда.",
                "§7На слот вида/ключа/дропа:",
                "§eкурсор+ЛКМ §7или §eShift+ЛКМ§7."));

        editMainInv.put(p.getUniqueId(), inv);
        p.openInventory(inv);
    }

    private void openDropsEditor(Player p, String id) {
        Template t = templates.get(id); if (t == null) return;
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_DROPS);
        ItemStack glass = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        // top 45 free-ish, bottom bar glass
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);

        for (int i = 0; i < Math.min(45, t.drops.size()); i++) {
            DropEntry d = t.drops.get(i);
            ItemStack show = d.item == null ? new ItemStack(Material.BARRIER) : d.item.clone();
            ItemMeta m = show.getItemMeta();
            if (m != null) {
                List<String> lore = new ArrayList<>();
                lore.add("§8---");
                lore.add("§7#" + i + "  " + d.rarity.label);
                lore.add("§7Шанс/вес: §f" + d.chanceOrWeight
                        + (t.rollMode == RollMode.INDEPENDENT ? "%" : " (вес)"));
                lore.add("§7Кол-во: §f" + d.minAmount + "–" + d.maxAmount);
                lore.add("§eЛКМ §7— редактировать параметры");
                lore.add("§eЛКМ предметом §7— заменить предмет");
                lore.add("§cShift+ПКМ §7— удалить");
                lore.add("§8Определение: §7одна строка таблицы наград.");
                m.setLore(lore);
                show.setItemMeta(m);
            }
            inv.setItem(i, show);
        }
        // empty slots 0-44 beyond drops: clickable "add here"
        for (int i = t.drops.size(); i < 45; i++) {
            inv.setItem(i, pane(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "§7Пустой слот",
                    "§eЛКМ предметом на курсоре §7— добавить дроп",
                    "§eShift+ЛКМ из инвентаря §7— добавить дроп",
                    "§8Определение: §7новая строка таблицы."));
        }

        inv.setItem(45, pane(Material.LIME_CONCRETE, "§a§l+ Добавить дроп",
                "§eЛКМ с предметом на курсоре §7— добавить",
                "§eЛКМ без предмета §7— камень-заглушка",
                "§eShift+ЛКМ из низа §7на этот слот — тоже",
                "§8Определение: §7быстро добавить строку."));
        inv.setItem(48, pane(Material.BOOK, "§6Подсказка",
                "§7WEIGHTED: веса относительно друг друга",
                "§7(10 и 30 → 25% / 75%).",
                "§7INDEPENDENT: число = шанс % (0–100).",
                "§7Нижний инвентарь свободен."));
        inv.setItem(49, pane(Material.ARROW, "§e← Назад к настройкам"));
        inv.setItem(53, pane(Material.EMERALD_BLOCK, "§aСохранить", "§7lootboxes.yml"));

        editDropsInv.put(p.getUniqueId(), inv);
        p.openInventory(inv);
    }

    private void openEntryEditor(Player p, String id, int index) {
        Template t = templates.get(id); if (t == null) return;
        if (index < 0 || index >= t.drops.size()) return;
        DropEntry d = t.drops.get(index);
        editEntryIndex.put(p.getUniqueId(), index);
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_ENTRY);
        ItemStack glass = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);

        ItemStack show = d.item == null ? new ItemStack(Material.STONE) : d.item.clone();
        ItemMeta sm = show.getItemMeta();
        if (sm != null) {
            List<String> lore = new ArrayList<>();
            lore.add("§8---");
            lore.add("§eЛКМ предметом на курсоре §7— заменить");
            lore.add("§eShift+ЛКМ из инвентаря §7— заменить");
            lore.add("§8Определение: §7что выдаётся игроку.");
            sm.setLore(lore);
            show.setItemMeta(sm);
        }
        inv.setItem(11, show);

        inv.setItem(13, pane(Material.GOLD_NUGGET, "§eРедкость дропа",
                "§7" + d.rarity.label,
                "§eЛКМ §7— след.  §eПКМ §7— пред.",
                "§8Определение: §7метка качества.",
                "§7LEGENDARY → broadcast (если вкл).",
                "§7EPIC+ учитываются pity-системой."));

        inv.setItem(14, pane(Material.PAPER, "§eШанс / вес",
                "§7Сейчас: §f" + d.chanceOrWeight,
                "§7Режим шаблона: §f" + t.rollMode.name(),
                "§eЛКМ §7— ввести число",
                "§8Определение:",
                "§7WEIGHTED — относительный вес.",
                "§7INDEPENDENT — процент 0–100."));

        inv.setItem(15, pane(Material.IRON_NUGGET, "§eМин. кол-во",
                "§7Сейчас: §f" + d.minAmount,
                "§eЛКМ §7— ввести  §eShift± §7— ±1",
                "§8Определение: §7нижняя граница",
                "§7количества в стаке награды."));

        inv.setItem(16, pane(Material.GOLD_INGOT, "§eМакс. кол-во",
                "§7Сейчас: §f" + d.maxAmount,
                "§eЛКМ §7— ввести  §eShift± §7— ±1",
                "§8Определение: §7верхняя граница;",
                "§7ролл равномерный min..max."));

        inv.setItem(18, pane(Material.ARROW, "§e← К таблице дропов"));
        inv.setItem(22, pane(Material.RED_CONCRETE, "§cУдалить дроп",
                "§8Определение: §7убрать строку из таблицы."));
        inv.setItem(26, pane(Material.EMERALD_BLOCK, "§aГотово", "§7Вернуться к таблице"));

        editEntryInv.put(p.getUniqueId(), inv);
        p.openInventory(inv);
    }

    private boolean isOurInv(Inventory inv, UUID u) {
        return inv != null && (inv == editMainInv.get(u) || inv == editDropsInv.get(u) || inv == editEntryInv.get(u));
    }

    private ItemStack takeCursorOrNull(InventoryClickEvent e) {
        ItemStack cur = e.getCursor();
        if (cur != null && cur.getType() != Material.AIR) return cur.clone();
        return null;
    }


    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onInvClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        UUID u = p.getUniqueId();
        Inventory top = e.getView().getTopInventory();
        if (!isOurInv(top, u)) return;

        String id = editTemplate.get(u); if (id == null) return;
        Template t = templates.get(id); if (t == null) return;
        int raw = e.getRawSlot();
        int topSize = top.getSize();
        boolean topClick = raw >= 0 && raw < topSize;
        ClickType ct = e.getClick();

        // === BOTTOM (player) inventory ===
        if (!topClick) {
            // Allow normal pick up / move inside player inv
            if (ct == ClickType.SHIFT_LEFT || ct == ClickType.SHIFT_RIGHT) {
                // Shift into top: intercept as "place into editor"
                e.setCancelled(true);
                ItemStack src = e.getCurrentItem();
                if (src == null || src.getType() == Material.AIR) return;
                ItemStack one = src.clone(); one.setAmount(1);

                if (top == editMainInv.get(u)) {
                    // default: set base item
                    t.baseItem = one;
                    saveTemplates();
                    p.sendMessage("§aБазовый предмет: §f" + itemLabel(one));
                    openMainEditor(p, id);
                } else if (top == editDropsInv.get(u)) {
                    addDropFromItem(t, one);
                    saveTemplates();
                    p.sendMessage("§aДроп добавлен: §f" + itemLabel(one));
                    openDropsEditor(p, id);
                } else if (top == editEntryInv.get(u)) {
                    Integer idx = editEntryIndex.get(u);
                    if (idx != null && idx >= 0 && idx < t.drops.size()) {
                        t.drops.get(idx).item = one;
                        saveTemplates();
                        p.sendMessage("§aПредмет дропа заменён.");
                        openEntryEditor(p, id, idx);
                    }
                }
                return;
            }
            // non-shift bottom clicks: allow vanilla (pick stack to cursor)
            // do NOT cancel
            return;
        }

        // === TOP inventory clicks: always cancel vanilla, handle manually ===
        e.setCancelled(true);
        if (raw < 0) return;

        if (top == editMainInv.get(u)) {
            handleMainClick(p, t, id, raw, ct, e);
        } else if (top == editDropsInv.get(u)) {
            handleDropsClick(p, t, id, raw, ct, e);
        } else if (top == editEntryInv.get(u)) {
            handleEntryClick(p, t, id, raw, ct, e);
        }
    }

    private void addDropFromItem(Template t, ItemStack one) {
        DropEntry d = new DropEntry();
        d.item = one.clone(); d.item.setAmount(1);
        d.chanceOrWeight = 10.0;
        d.rarity = Rarity.COMMON;
        d.minAmount = 1; d.maxAmount = 1;
        t.drops.add(d);
    }

    private void handleMainClick(Player p, Template t, String id, int slot, ClickType ct, InventoryClickEvent e) {
        switch (slot) {
            case 13 -> {
                if (ct.isRightClick()) {
                    t.baseItem = new ItemStack(Material.CHEST);
                    saveTemplates(); openMainEditor(p, id); return;
                }
                ItemStack placed = takeCursorOrNull(e);
                if (placed != null) {
                    placed.setAmount(1);
                    t.baseItem = placed;
                    saveTemplates();
                    p.sendMessage("§aБазовый предмет обновлён.");
                    openMainEditor(p, id);
                } else {
                    p.sendMessage("§eВозьмите предмет из своего инвентаря на курсор, затем ЛКМ по этому слоту.");
                    p.sendMessage("§7Или §eShift+ЛКМ §7по предмету внизу.");
                }
            }
            case 11 -> {
                chatWait.put(p.getUniqueId(), "name:" + id); p.closeInventory();
                p.sendMessage("§eВведите название в чат (& для цвета). §7'cancel' — отмена");
            }
            case 15 -> {
                Rarity[] vals = Rarity.values();
                int idx = t.shellRarity.ordinal();
                idx = ct.isRightClick() ? (idx - 1 + vals.length) % vals.length : (idx + 1) % vals.length;
                t.shellRarity = vals[idx]; saveTemplates(); openMainEditor(p, id);
            }
            case 20 -> {
                t.rollMode = t.rollMode == RollMode.WEIGHTED ? RollMode.INDEPENDENT : RollMode.WEIGHTED;
                saveTemplates(); openMainEditor(p, id);
            }
            case 21 -> {
                UseMode[] um = UseMode.values();
                t.useMode = um[(t.useMode.ordinal() + 1) % um.length];
                saveTemplates(); openMainEditor(p, id);
            }
            case 22 -> {
                if (ct.isShiftClick()) {
                    t.cooldownSec = Math.max(0, t.cooldownSec + (ct.isRightClick() ? -10 : 10));
                    saveTemplates(); openMainEditor(p, id);
                } else {
                    chatWait.put(p.getUniqueId(), "cd:" + id); p.closeInventory();
                    p.sendMessage("§eКулдаун в секундах (число). §7'cancel' — отмена");
                }
            }
            case 23 -> {
                if (ct.isShiftClick()) {
                    t.maxUses = Math.max(1, t.maxUses + (ct.isRightClick() ? -1 : 1));
                    saveTemplates(); openMainEditor(p, id);
                } else {
                    chatWait.put(p.getUniqueId(), "uses:" + id); p.closeInventory();
                    p.sendMessage("§eМакс. использований (≥1). §7'cancel'");
                }
            }
            case 24 -> {
                t.kind = t.kind == BoxKind.CASE ? BoxKind.LOOTBOX : BoxKind.CASE;
                t.removeOnOpen = (t.kind == BoxKind.CASE);
                saveTemplates(); openMainEditor(p, id);
            }
            case 25 -> {
                t.removeOnOpen = !t.removeOnOpen;
                saveTemplates(); openMainEditor(p, id);
            }
            case 29 -> { t.hologram = !t.hologram; saveTemplates(); openMainEditor(p, id); }
            case 30 -> { t.animation = !t.animation; saveTemplates(); openMainEditor(p, id); }
            case 31 -> { t.broadcastLegendary = !t.broadcastLegendary; saveTemplates(); openMainEditor(p, id); }
            case 32 -> {
                chatWait.put(p.getUniqueId(), "second:" + id); p.closeInventory();
                p.sendMessage("§eШанс второго дропа 0–100. §7'cancel'");
            }
            case 33 -> {
                if (ct.isRightClick()) {
                    t.requireKey = false; t.keyItem = null; saveTemplates(); openMainEditor(p, id); return;
                }
                ItemStack placed = takeCursorOrNull(e);
                if (placed != null) {
                    placed.setAmount(1);
                    t.keyItem = placed; t.requireKey = true;
                    saveTemplates(); openMainEditor(p, id);
                } else {
                    t.requireKey = !t.requireKey;
                    if (t.requireKey && t.keyItem == null) {
                        p.sendMessage("§eКлюч вкл, но предмет не задан — положите предмет на курсор и ЛКМ.");
                    }
                    saveTemplates(); openMainEditor(p, id);
                }
            }
            case 38 -> {
                chatWait.put(p.getUniqueId(), "pityt:" + id); p.closeInventory();
                p.sendMessage("§ePity-порог (0=выкл). §7'cancel'");
            }
            case 39 -> {
                chatWait.put(p.getUniqueId(), "pityb:" + id); p.closeInventory();
                p.sendMessage("§ePity-бонус (дробное OK). §7'cancel'");
            }
            case 40 -> openDropsEditor(p, id);
            case 41 -> {
                p.closeInventory();
                handleCommand(p, new String[]{"test", id, "10"});
            }
            case 42 -> {
                p.getInventory().addItem(createPlaceItem(t));
                p.sendMessage("§aВыдан place-item.");
            }
            case 49 -> p.closeInventory();
            case 53 -> {
                saveTemplates();
                p.sendMessage("§aСохранено в lootboxes.yml");
                p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            }
            default -> { }
        }
    }

    private void handleDropsClick(Player p, Template t, String id, int slot, ClickType ct, InventoryClickEvent e) {
        if (slot < 45) {
            ItemStack placed = takeCursorOrNull(e);
            if (placed != null) {
                placed.setAmount(1);
                if (slot < t.drops.size()) {
                    t.drops.get(slot).item = placed;
                    p.sendMessage("§aПредмет дропа #" + slot + " заменён.");
                } else {
                    addDropFromItem(t, placed);
                    p.sendMessage("§aДроп добавлен: §f" + itemLabel(placed));
                }
                saveTemplates(); openDropsEditor(p, id); return;
            }
            if (slot >= t.drops.size()) {
                p.sendMessage("§eПоложите предмет на курсор и кликните пустой слот — или Shift+ЛКМ из низа.");
                return;
            }
            if (ct == ClickType.SHIFT_RIGHT) {
                t.drops.remove(slot); saveTemplates(); openDropsEditor(p, id); return;
            }
            openEntryEditor(p, id, slot);
            return;
        }
        if (slot == 45) {
            ItemStack placed = takeCursorOrNull(e);
            if (placed != null) {
                placed.setAmount(1);
                addDropFromItem(t, placed);
            } else {
                DropEntry d = new DropEntry();
                d.item = new ItemStack(Material.STONE);
                d.chanceOrWeight = 10.0; d.rarity = Rarity.COMMON;
                d.minAmount = 1; d.maxAmount = 1;
                t.drops.add(d);
            }
            saveTemplates(); openDropsEditor(p, id);
        } else if (slot == 49) {
            openMainEditor(p, id);
        } else if (slot == 53) {
            saveTemplates(); p.sendMessage("§aСохранено.");
        }
    }

    private void handleEntryClick(Player p, Template t, String id, int slot, ClickType ct, InventoryClickEvent e) {
        Integer idx = editEntryIndex.get(p.getUniqueId());
        if (idx == null || idx < 0 || idx >= t.drops.size()) { openDropsEditor(p, id); return; }
        DropEntry d = t.drops.get(idx);
        switch (slot) {
            case 11 -> {
                ItemStack placed = takeCursorOrNull(e);
                if (placed != null) {
                    placed.setAmount(1);
                    d.item = placed;
                    saveTemplates(); openEntryEditor(p, id, idx);
                } else {
                    p.sendMessage("§eПредмет на курсор + ЛКМ, или Shift+ЛКМ из низа.");
                }
            }
            case 13 -> {
                Rarity[] vals = Rarity.values();
                int i = d.rarity.ordinal();
                i = ct.isRightClick() ? (i - 1 + vals.length) % vals.length : (i + 1) % vals.length;
                d.rarity = vals[i]; saveTemplates(); openEntryEditor(p, id, idx);
            }
            case 14 -> {
                chatWait.put(p.getUniqueId(), "dchance:" + id + ":" + idx); p.closeInventory();
                p.sendMessage("§eШанс/вес (число). Режим: §f" + t.rollMode + "§e. §7'cancel'");
            }
            case 15 -> {
                if (ct.isShiftClick()) {
                    d.minAmount = Math.max(1, d.minAmount + (ct.isRightClick() ? -1 : 1));
                    if (d.maxAmount < d.minAmount) d.maxAmount = d.minAmount;
                    saveTemplates(); openEntryEditor(p, id, idx);
                } else {
                    chatWait.put(p.getUniqueId(), "dmin:" + id + ":" + idx); p.closeInventory();
                    p.sendMessage("§eМин. кол-во. §7'cancel'");
                }
            }
            case 16 -> {
                if (ct.isShiftClick()) {
                    d.maxAmount = Math.max(d.minAmount, d.maxAmount + (ct.isRightClick() ? -1 : 1));
                    saveTemplates(); openEntryEditor(p, id, idx);
                } else {
                    chatWait.put(p.getUniqueId(), "dmax:" + id + ":" + idx); p.closeInventory();
                    p.sendMessage("§eМакс. кол-во. §7'cancel'");
                }
            }
            case 18, 26 -> openDropsEditor(p, id);
            case 22 -> {
                t.drops.remove((int) idx); saveTemplates(); openDropsEditor(p, id);
            }
            default -> { }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory top = e.getView().getTopInventory();
        if (!isOurInv(top, p.getUniqueId())) return;
        // allow drag only fully within player inventory
        int topSize = top.getSize();
        for (int slot : e.getRawSlots()) {
            if (slot < topSize) {
                e.setCancelled(true);
                return;
            }
        }
        // pure bottom drag — allow
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        UUID u = p.getUniqueId();
        Inventory top = e.getInventory();
        if (top == editMainInv.get(u)) editMainInv.remove(u);
        if (top == editDropsInv.get(u)) editDropsInv.remove(u);
        if (top == editEntryInv.get(u)) editEntryInv.remove(u);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        String wait = chatWait.get(p.getUniqueId());
        if (wait == null) return;
        e.setCancelled(true);
        String msg = e.getMessage().trim();
        chatWait.remove(p.getUniqueId());
        Bukkit.getScheduler().runTask(plugin, () -> applyChatInput(p, wait, msg));
    }

    private void applyChatInput(Player p, String wait, String msg) {
        if ("cancel".equalsIgnoreCase(msg)) { p.sendMessage("§7Отменено."); return; }
        String[] parts = wait.split(":", 3);
        String kind = parts[0];
        String id = parts.length > 1 ? parts[1] : editTemplate.get(p.getUniqueId());
        Template t = id != null ? templates.get(id) : null;
        if (t == null) { p.sendMessage("§cШаблон потерян."); return; }
        try {
            switch (kind) {
                case "name" -> {
                    t.displayName = ChatColor.translateAlternateColorCodes('&', msg);
                    p.sendMessage("§aНазвание: §r" + t.displayName);
                }
                case "cd" -> {
                    t.cooldownSec = Math.max(0, Integer.parseInt(msg));
                    p.sendMessage("§aКулдаун: §f" + t.cooldownSec + "с");
                }
                case "uses" -> {
                    t.maxUses = Math.max(1, Integer.parseInt(msg));
                    p.sendMessage("§aМакс. uses: §f" + t.maxUses);
                }
                case "second" -> {
                    t.secondDropChance = Math.max(0, Math.min(100, Double.parseDouble(msg.replace(',', '.'))));
                    p.sendMessage("§aВторой дроп: §f" + t.secondDropChance + "%");
                }
                case "pityt" -> {
                    t.pityThreshold = Math.max(0, Integer.parseInt(msg));
                    p.sendMessage("§aPity-порог: §f" + t.pityThreshold);
                }
                case "pityb" -> {
                    t.pityBonusPerFail = Math.max(0, Double.parseDouble(msg.replace(',', '.')));
                    p.sendMessage("§aPity-бонус: §f" + t.pityBonusPerFail);
                }
                case "dchance" -> {
                    int idx = Integer.parseInt(parts[2]);
                    if (idx >= 0 && idx < t.drops.size()) {
                        t.drops.get(idx).chanceOrWeight = Math.max(0, Double.parseDouble(msg.replace(',', '.')));
                        p.sendMessage("§aШанс/вес: §f" + t.drops.get(idx).chanceOrWeight);
                        saveTemplates(); openEntryEditor(p, id, idx); return;
                    }
                }
                case "dmin" -> {
                    int idx = Integer.parseInt(parts[2]);
                    if (idx >= 0 && idx < t.drops.size()) {
                        DropEntry d = t.drops.get(idx);
                        d.minAmount = Math.max(1, Integer.parseInt(msg));
                        if (d.maxAmount < d.minAmount) d.maxAmount = d.minAmount;
                        saveTemplates(); openEntryEditor(p, id, idx); return;
                    }
                }
                case "dmax" -> {
                    int idx = Integer.parseInt(parts[2]);
                    if (idx >= 0 && idx < t.drops.size()) {
                        DropEntry d = t.drops.get(idx);
                        d.maxAmount = Math.max(d.minAmount, Integer.parseInt(msg));
                        saveTemplates(); openEntryEditor(p, id, idx); return;
                    }
                }
                default -> p.sendMessage("§cНеизвестный ввод.");
            }
            saveTemplates();
            openMainEditor(p, id);
        } catch (NumberFormatException ex) {
            p.sendMessage("§cНе число: " + msg);
            openMainEditor(p, id);
        }
    }
}
